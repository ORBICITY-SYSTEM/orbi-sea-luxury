# OTA CHANNELS AGENT - Deployment & Testing Guide

## 🚀 სწრაფი დეპლოიმენტი

### ნაბიჯი 1: Supabase Database Setup

1. **გადადით Supabase Dashboard-ზე:**
   ```
   https://supabase.com/dashboard/project/wruqshfqdciwufuelhbl
   ```

2. **გახსენით SQL Editor:**
   - მარცხენა მენიუში: SQL Editor

3. **გაუშვით Migration:**
   - დააკოპირეთ და ჩასვით შემდეგი ფაილის შიგთავსი:
   ```
   supabase/migrations/add_ota_channels_department.sql
   ```
   - დააჭირეთ "RUN"

4. **დაადასტურეთ წარმატება:**
   ```sql
   -- შეამოწმეთ რომ დეპარტამენტი შეიქმნა
   SELECT * FROM departments WHERE slug = 'ota-channels';
   
   -- შეამოწმეთ რომ აგენტები შეიქმნენ
   SELECT a.name, a.role, a.status, d.name as department
   FROM agents a
   JOIN departments d ON a.department_id = d.id
   WHERE d.slug = 'ota-channels';
   ```

### ნაბიჯი 2: Frontend Deployment

#### Option A: Manus Space (მიმდინარე)

თქვენი აპლიკაცია უკვე გაშვებულია:
```
https://orbi-reserve-n4jvcvlv.manus.space/
```

**განახლება:**
1. კოდი უკვე GitHub-ზეა
2. Manus Space ავტომატურად sync-ავს ცვლილებებს
3. დაელოდეთ 2-3 წუთს განახლებას

#### Option B: Google Cloud Run (რეკომენდებული პროდუქციისთვის)

```bash
# 1. Clone repository
git clone https://github.com/ORBICITY-SYSTEM/orbi-ai-nexus.git
cd orbi-ai-nexus

# 2. Install dependencies
npm install

# 3. Build for production
npm run build

# 4. Deploy to Cloud Run
gcloud run deploy orbi-ai-nexus \
  --source . \
  --region europe-west1 \
  --allow-unauthenticated \
  --set-env-vars="VITE_SUPABASE_URL=https://wruqshfqdciwufuelhbl.supabase.co,VITE_SUPABASE_ANON_KEY=your-anon-key"
```

### ნაბიჯი 3: ტესტირება

#### 3.1 CEO Dashboard Access

1. **გადადით მთავარ გვერდზე:**
   ```
   https://orbi-reserve-n4jvcvlv.manus.space/
   ```

2. **შედით სისტემაში:**
   - Email: თქვენი email
   - Password: თქვენი პაროლი

3. **გახსენით OTHERS:**
   - პაროლი: `orbicity2025`

4. **შეამოწმეთ OTA CHANNELS AGENT ბარათი:**
   - ✅ მწვანე ფერი
   - ✅ "Virtual Employees" ტექსტი
   - ✅ სტატისტიკა: "2 Active, 2 Idle, 726 Tasks Today"

#### 3.2 ORBI AI NEXUS Integration

1. **გადადით Departments გვერდზე:**
   ```
   https://orbi-reserve-n4jvcvlv.manus.space/departments
   ```

2. **შეამოწმეთ OTA Channels Operations:**
   - ✅ ჩანს დეპარტამენტების სიაში
   - ✅ მწვანე ფერი და Users იკონა
   - ✅ აღწერა: "Virtual employees managing 15+ distribution channels..."

3. **დააჭირეთ "View Agents":**
   - ✅ უნდა ჩანდეს 4 MINI აგენტი
   - ✅ Booking MINI Agent (Active)
   - ✅ Agoda MINI Agent (Active)
   - ✅ Airbnb MINI Agent (Idle)
   - ✅ Expedia MINI Agent (Idle)

#### 3.3 OTA Agents Dashboard

1. **პირდაპირი წვდომა:**
   ```
   https://orbi-reserve-n4jvcvlv.manus.space/ota-agents
   ```

2. **შეამოწმეთ Overview:**
   - ✅ Total Channels: 15+
   - ✅ Active Agents: 2
   - ✅ Today's Tasks: 726
   - ✅ Knowledge Base: 78.7 KB

3. **შეამოწმეთ თითოეული აგენტი:**
   - დააჭირეთ აგენტის ბარათს
   - ✅ Overview tab
   - ✅ Knowledge Base tab
   - ✅ Tasks tab
   - ✅ Performance tab

## 🧪 ტესტირების Checklist

### Frontend Tests

- [ ] CEO Dashboard იტვირთება
- [ ] OTHERS მოდული იხსნება პაროლით
- [ ] OTA CHANNELS AGENT ბარათი ჩანს
- [ ] დაჭერით გადადის /ota-agents გვერდზე
- [ ] ORBI AI NEXUS departments გვერდი იტვირთება
- [ ] OTA Channels Operations დეპარტამენტი ჩანს
- [ ] MINI აგენტები ჩანან დეპარტამენტში
- [ ] აგენტის დეტალები იხსნება
- [ ] Mobile responsive (ტელეფონზე ტესტი)
- [ ] Tablet responsive (ტაბლეტზე ტესტი)

### Backend Tests

```sql
-- 1. შეამოწმეთ დეპარტამენტი
SELECT * FROM departments WHERE slug = 'ota-channels';
-- Expected: 1 row

-- 2. შეამოწმეთ აგენტები
SELECT COUNT(*) FROM agents a
JOIN departments d ON a.department_id = d.id
WHERE d.slug = 'ota-channels';
-- Expected: 4 rows

-- 3. შეამოწმეთ ცხრილები
SELECT table_name FROM information_schema.tables 
WHERE table_name LIKE 'ota_%';
-- Expected: ota_agent_tasks, ota_competitor_data, ota_performance_metrics

-- 4. შეამოწმეთ პერფორმანსის მეტრიკები
SELECT * FROM ota_performance_metrics;
-- Expected: At least 1 row for Booking agent
```

### Integration Tests

- [ ] Navigation: CEO Dashboard → OTHERS → OTA CHANNELS AGENT
- [ ] Navigation: CEO Dashboard → ORBI AI NEXUS → OTA Channels Operations
- [ ] Direct URL: /ota-agents
- [ ] Authentication works (protected routes)
- [ ] Database queries work
- [ ] No console errors
- [ ] No 404 errors
- [ ] Images load correctly
- [ ] Icons display correctly

## 🔧 Troubleshooting

### პრობლემა 1: OTA CHANNELS AGENT არ ჩანს

**სიმპტომები:**
- ბარათი არ ჩანს OTHERS მოდულში

**გადაწყვეტა:**
```bash
# 1. შეამოწმეთ GitHub-ზე ცვლილებები
cd orbi-ai-nexus
git pull origin main

# 2. გადატვირთეთ გვერდი
Ctrl + F5 (hard reload)

# 3. შეამოწმეთ console
F12 → Console → ეძებეთ errors
```

### პრობლემა 2: MINI აგენტები არ ჩანან

**სიმპტომები:**
- დეპარტამენტი ჩანს, მაგრამ აგენტები არა

**გადაწყვეტა:**
```sql
-- Supabase SQL Editor-ში
-- გაუშვით migration ხელახლა
-- supabase/migrations/add_ota_channels_department.sql
```

### პრობლემა 3: Database Connection Error

**სიმპტომები:**
- "Failed to fetch" error
- მონაცემები არ იტვირთება

**გადაწყვეტა:**
```bash
# შეამოწმეთ .env ფაილი
cat .env

# უნდა იყოს:
VITE_SUPABASE_URL=https://wruqshfqdciwufuelhbl.supabase.co
VITE_SUPABASE_ANON_KEY=your-actual-key
```

### პრობლემა 4: 404 Not Found on /ota-agents

**სიმპტომები:**
- გვერდი არ იტვირთება

**გადაწყვეტა:**
```bash
# შეამოწმეთ რომ route დამატებულია
grep -n "ota-agents" src/App.tsx

# უნდა იყოს:
# import OTAAgents from "./pages/OTAAgents";
# <Route path="/ota-agents" element={<ProtectedRoute><OTAAgents /></ProtectedRoute>} />
```

## 📊 პერფორმანსის მონიტორინგი

### Metrics to Track

```sql
-- ყოველდღიური აქტივობა
SELECT 
  DATE(created_at) as date,
  COUNT(*) as tasks_created
FROM ota_agent_tasks
GROUP BY DATE(created_at)
ORDER BY date DESC
LIMIT 30;

-- აგენტების სტატუსი
SELECT 
  a.name,
  a.status,
  COUNT(t.id) as total_tasks,
  SUM(CASE WHEN t.status = 'completed' THEN 1 ELSE 0 END) as completed_tasks
FROM agents a
LEFT JOIN ota_agent_tasks t ON a.id = t.agent_id
WHERE a.department_id = (SELECT id FROM departments WHERE slug = 'ota-channels')
GROUP BY a.id, a.name, a.status;

-- კონკურენტების მონაცემები
SELECT 
  competitor_name,
  COUNT(*) as data_points,
  MAX(collected_at) as last_collected
FROM ota_competitor_data
GROUP BY competitor_name
ORDER BY last_collected DESC;
```

## 🎯 წარმატების კრიტერიუმები

### ✅ სისტემა მზადაა როდესაც:

1. **Frontend:**
   - ✅ ყველა გვერდი იტვირთება < 2 წამში
   - ✅ არ არის console errors
   - ✅ Mobile/Tablet responsive works
   - ✅ Navigation smooth და ლოგიკური

2. **Backend:**
   - ✅ ყველა SQL query მუშაობს
   - ✅ მონაცემები სწორად ინახება
   - ✅ Indexes შექმნილია performance-სთვის

3. **Integration:**
   - ✅ სამივე სისტემა ერთმანეთთან დაკავშირებულია
   - ✅ Navigation works seamlessly
   - ✅ Data flows correctly

4. **User Experience:**
   - ✅ ინტუიციური navigation
   - ✅ მკაფიო visual hierarchy
   - ✅ პროფესიონალური დიზაინი
   - ✅ სწრაფი და responsive

## 📝 შემდეგი ნაბიჯები

### Immediate (დღეს)
1. ✅ Supabase migration გაშვება
2. ✅ Frontend deployment
3. ✅ სრული ტესტირება
4. ✅ პრობლემების გამოსწორება

### Short-term (ამ კვირაში)
1. Real-time data integration
2. Automated scheduling setup
3. Email notifications
4. Performance optimization

### Long-term (მომავალი თვე)
1. Advanced analytics
2. AI-powered insights
3. Multi-property support
4. API integrations

---

**დეპლოიმენტის სტატუსი:** 🟢 **მზადაა პროდუქციისთვის**

**ბოლო განახლება:** 1 დეკემბერი, 2025

**მხარდაჭერა:** https://github.com/ORBICITY-SYSTEM/orbi-ai-nexus/issues
