# Booking.com Agent - Architecture Design

This document outlines the architecture for the automated Booking.com management agent.

## 1. Project Structure

The project will be organized as follows:

```
booking_agent/
├── src/
│   ├── __main__.py         # Main entry point for the agent
│   ├── browser.py          # Browser automation functions (login, navigation)
│   ├── scraper.py          # Data scraping functions (bookings, reviews, prices)
│   ├── analysis.py         # Data analysis and reporting functions
│   ├── actions.py          # Functions to perform actions (update prices, reply)
│   └── config.py           # Configuration (credentials, settings)
├── data/
│   └── reports/            # Directory for generated reports
├── DESIGN.md               # This architecture document
└── README.md               # Project overview and setup instructions
```

## 2. Core Components

### `browser.py`
- **Purpose**: Handles all browser interactions using Selenium/Playwright.
- **Functions**:
    - `login()`: Logs into the Booking.com extranet.
    - `navigate_to(page)`: Navigates to a specific section (e.g., 'Reservations', 'Guest Reviews').
    - `get_page_source()`: Returns the HTML of the current page.
    - `close()`: Closes the browser session.

### `scraper.py`
- **Purpose**: Extracts structured data from the extranet pages.
- **Functions**:
    - `get_new_bookings()`: Scrapes new reservation details.
    - `get_reviews()`: Scrapes guest reviews and ratings.
    - `get_competitor_prices()`: Scrapes prices of competitor properties.
    - `get_analytics_data()`: Scrapes performance metrics.

### `analysis.py`
- **Purpose**: Analyzes the scraped data and generates insights.
- **Functions**:
    - `generate_daily_report()`: Creates the daily performance summary.
    - `generate_weekly_report()`: Creates the weekly competitor and pricing analysis.
    - `generate_monthly_report()`: Creates the comprehensive monthly business review.
    - `analyze_competitor_pricing()`: Compares property prices with competitors and suggests adjustments.

### `actions.py`
- **Purpose**: Executes actions on the extranet based on analysis.
- **Functions**:
    - `update_prices(updates)`: Updates room rates for specific dates.
    - `reply_to_review(review_id, response_text)`: Posts a reply to a guest review.

### `config.py`
- **Purpose**: Stores all configuration variables.
- **Content**:
    - Booking.com credentials (to be securely managed).
    - Supabase connection details.
    - List of competitor property IDs.
    - Email settings for notifications.

## 3. Database Schema (Supabase)

We will use the Supabase MCP server to create and manage the database with the following tables:

- **`bookings`**: `(booking_id, guest_name, check_in, check_out, price, status, scraped_at)`
- **`reviews`**: `(review_id, guest_name, rating, comment, review_date, response_sent, scraped_at)`
- **`prices`**: `(date, room_type, price, scraped_at)`
- **`competitor_prices`**: `(competitor_id, date, room_type, price, scraped_at)`
- **`analytics`**: `(date, page_views, conversion_rate, revenue, scraped_at)`

## 4. Scheduled Tasks

We will use the `schedule` tool to run the agent's functions at specified intervals.

| Task Name                 | Schedule (Cron)         | Action                                       |
| ------------------------- | ----------------------- | -------------------------------------------- |
| **Daily Morning Check**   | `0 0 9 * * *`           | Run `main.py --task daily_morning`           |
| **Daily Evening Report**  | `0 0 18 * * *`          | Run `main.py --task daily_evening`           |
| **Weekly Analysis**       | `0 0 10 * * 1`          | Run `main.py --task weekly_analysis`         |
| **Monthly Report**        | `0 0 12 1 * *`          | Run `main.py --task monthly_report`          |

## 5. Notification System

We will use the `gmail` or `make` MCP tools to send email notifications and reports.

- **Daily Reports**: Emailed to the user every evening.
- **Weekly/Monthly Reports**: Emailed on schedule.
- **Alerts**: Immediate email for critical events (e.g., new negative review, booking cancellation).
