-- Booking.com Agent Database Schema
-- This schema defines tables for storing booking data, reviews, prices, and analytics

-- Table: bookings
-- Stores all booking information scraped from Booking.com
CREATE TABLE IF NOT EXISTS bookings (
    id SERIAL PRIMARY KEY,
    booking_id VARCHAR(50) UNIQUE NOT NULL,
    guest_name VARCHAR(255),
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    room_type VARCHAR(255),
    num_guests INTEGER,
    total_price DECIMAL(10, 2),
    currency VARCHAR(10) DEFAULT 'GEL',
    status VARCHAR(50),
    booking_date TIMESTAMP,
    scraped_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Table: reviews
-- Stores guest reviews and responses
CREATE TABLE IF NOT EXISTS reviews (
    id SERIAL PRIMARY KEY,
    review_id VARCHAR(50) UNIQUE NOT NULL,
    guest_name VARCHAR(255),
    rating DECIMAL(3, 1),
    comment TEXT,
    review_date DATE,
    response_text TEXT,
    response_sent BOOLEAN DEFAULT FALSE,
    response_date TIMESTAMP,
    scraped_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Table: prices
-- Stores property pricing data
CREATE TABLE IF NOT EXISTS booking_prices (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    room_type VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'GEL',
    availability INTEGER,
    scraped_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(date, room_type, scraped_at)
);

-- Table: competitor_prices
-- Stores competitor pricing data for comparison
CREATE TABLE IF NOT EXISTS competitor_prices (
    id SERIAL PRIMARY KEY,
    competitor_id VARCHAR(50) NOT NULL,
    competitor_name VARCHAR(255),
    date DATE NOT NULL,
    room_type VARCHAR(255),
    price DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(10) DEFAULT 'GEL',
    availability INTEGER,
    scraped_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(competitor_id, date, room_type, scraped_at)
);

-- Table: analytics
-- Stores daily analytics and performance metrics
CREATE TABLE IF NOT EXISTS analytics (
    id SERIAL PRIMARY KEY,
    date DATE UNIQUE NOT NULL,
    page_views INTEGER,
    search_impressions INTEGER,
    clicks INTEGER,
    conversion_rate DECIMAL(5, 2),
    revenue DECIMAL(10, 2),
    currency VARCHAR(10) DEFAULT 'GEL',
    occupancy_rate DECIMAL(5, 2),
    average_daily_rate DECIMAL(10, 2),
    scraped_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Table: agent_logs
-- Stores agent execution logs and errors
CREATE TABLE IF NOT EXISTS agent_logs (
    id SERIAL PRIMARY KEY,
    task_name VARCHAR(255) NOT NULL,
    task_type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    message TEXT,
    error_details TEXT,
    execution_time_seconds DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Table: price_adjustments
-- Stores automatic price adjustment history
CREATE TABLE IF NOT EXISTS price_adjustments (
    id SERIAL PRIMARY KEY,
    date DATE NOT NULL,
    room_type VARCHAR(255) NOT NULL,
    old_price DECIMAL(10, 2) NOT NULL,
    new_price DECIMAL(10, 2) NOT NULL,
    reason TEXT,
    applied BOOLEAN DEFAULT FALSE,
    applied_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_bookings_check_in ON bookings(check_in);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_reviews_review_date ON reviews(review_date);
CREATE INDEX IF NOT EXISTS idx_reviews_response_sent ON reviews(response_sent);
CREATE INDEX IF NOT EXISTS idx_prices_date ON booking_prices(date);
CREATE INDEX IF NOT EXISTS idx_competitor_prices_date ON competitor_prices(date);
CREATE INDEX IF NOT EXISTS idx_analytics_date ON analytics(date);
CREATE INDEX IF NOT EXISTS idx_agent_logs_created_at ON agent_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_price_adjustments_date ON price_adjustments(date);
