"""
Booking.com Agent Configuration
"""
import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
REPORTS_DIR = DATA_DIR / "reports"
DB_DIR = DATA_DIR / "database"

# Create directories if they don't exist
DATA_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)
DB_DIR.mkdir(exist_ok=True)

# Booking.com credentials (to be set by user)
BOOKING_USERNAME = os.getenv("BOOKING_USERNAME", "")
BOOKING_PASSWORD = os.getenv("BOOKING_PASSWORD", "")

# Property details
PROPERTY_ID = "10172179"
PROPERTY_NAME = "Orbi City - Sea View Aparthotel in Batumi"

# Booking.com URLs
BOOKING_LOGIN_URL = "https://account.booking.com/sign-in"
BOOKING_EXTRANET_BASE = "https://admin.booking.com/hotel/hoteladmin/extranet_ng/manage"
BOOKING_HOME_URL = f"{BOOKING_EXTRANET_BASE}/home.html?hotel_id={PROPERTY_ID}&lang=en"

# Competitor property IDs (to be populated by user)
COMPETITOR_IDS = [
    # Add competitor property IDs here
    # Example: "10172180", "10172181", etc.
]

# Email configuration (using Gmail MCP)
NOTIFICATION_EMAIL = os.getenv("NOTIFICATION_EMAIL", "")

# Browser settings
HEADLESS_MODE = os.getenv("HEADLESS_MODE", "false").lower() == "true"
BROWSER_TIMEOUT = 30  # seconds

# Supabase configuration
SUPABASE_PROJECT_ID = "wruqshfqdciwufuelhbl"
SUPABASE_URL = f"https://{SUPABASE_PROJECT_ID}.supabase.co"
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

# Scraping intervals (in seconds)
SCRAPE_DELAY_MIN = 2
SCRAPE_DELAY_MAX = 5

# Analysis settings
PRICE_ADJUSTMENT_THRESHOLD = 0.15  # 15% price difference triggers adjustment
MIN_PRICE_GEL = 50  # Minimum price per night
MAX_PRICE_GEL = 500  # Maximum price per night

# Report settings
DAILY_REPORT_TIME = "18:00"
WEEKLY_REPORT_DAY = "Monday"
MONTHLY_REPORT_DAY = 1
