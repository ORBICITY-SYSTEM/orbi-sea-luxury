"""
OTA CHANNELS AGENT Configuration
"""
import os
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
REPORTS_DIR = DATA_DIR / "reports"
DB_DIR = DATA_DIR / "database"

# Create directories
for dir_path in [DATA_DIR, REPORTS_DIR, DB_DIR]:
    dir_path.mkdir(exist_ok=True, parents=True)

# Property details
PROPERTY_NAME = "ORBI CITY - Sea View Aparthotel in Batumi"
PROPERTY_LOCATION = "Batumi, Georgia"

# Booking.com
BOOKING_USERNAME = os.getenv("BOOKING_USERNAME", "")
BOOKING_PASSWORD = os.getenv("BOOKING_PASSWORD", "")
BOOKING_PROPERTY_ID = "10172179"
BOOKING_EXTRANET_URL = f"https://admin.booking.com/hotel/hoteladmin/extranet_ng/manage/home.html?hotel_id={BOOKING_PROPERTY_ID}&lang=en"

# Airbnb
AIRBNB_USERNAME = os.getenv("AIRBNB_USERNAME", "")
AIRBNB_PASSWORD = os.getenv("AIRBNB_PASSWORD", "")
AIRBNB_PROPERTY_ID = "1455314718960040955"
AIRBNB_EXTRANET_URL = "https://www.airbnb.com/hosting"

# Expedia
EXPEDIA_USERNAME = os.getenv("EXPEDIA_USERNAME", "")
EXPEDIA_PASSWORD = os.getenv("EXPEDIA_PASSWORD", "")
EXPEDIA_EXTRANET_URL = "https://apps.expediapartnercentral.com/"

# Supabase
SUPABASE_URL = os.getenv("SUPABASE_URL", "https://wruqshfqdciwufuelhbl.supabase.co")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY", "")

# Email
NOTIFICATION_EMAIL = os.getenv("NOTIFICATION_EMAIL", "")

# Browser
HEADLESS_MODE = os.getenv("HEADLESS_MODE", "false").lower() == "true"
BROWSER_TIMEOUT = 30

# OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# Pricing
MIN_PRICE_GEL = 50
MAX_PRICE_GEL = 500
PRICE_ADJUSTMENT_THRESHOLD = 0.15

# Scheduling
DAILY_MORNING_TIME = "09:00"
DAILY_EVENING_TIME = "18:00"
WEEKLY_DAY = "Monday"
WEEKLY_TIME = "10:00"
MONTHLY_DAY = 1
MONTHLY_TIME = "12:00"
