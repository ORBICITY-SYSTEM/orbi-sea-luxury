"""
Competitor Monitoring System for OTA CHANNELS AGENT
Based on Agoda's competitive set analysis methodology
"""
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum

class CompetitorTier(Enum):
    """Competitor tier classification"""
    TIER_1_DIRECT = "Tier 1 - Direct Competitors"
    TIER_2_ALTERNATIVE = "Tier 2 - Alternative Options"
    TIER_3_BUDGET = "Tier 3 - Budget Alternatives"

@dataclass
class Competitor:
    """Competitor property data"""
    property_id: str
    name: str
    channel: str  # booking, agoda, airbnb, etc.
    tier: CompetitorTier
    distance_km: float
    star_rating: float
    review_score: float
    review_count: int
    base_price: float
    url: str
    last_checked: Optional[datetime] = None

@dataclass
class PricePoint:
    """Price data point"""
    date: datetime
    competitor_id: str
    price: float
    availability: bool
    room_type: str
    currency: str = "GEL"

class CompetitorMonitor:
    """
    Competitor monitoring system
    
    Implements comprehensive competitor tracking across all OTA channels
    following the methodology from Agoda analysis
    """
    
    def __init__(self):
        self.competitors: Dict[str, List[Competitor]] = {
            "booking": [],
            "agoda": [],
            "airbnb": [],
            "expedia": []
        }
        self.price_history: List[PricePoint] = []
        
    def add_competitor(self, competitor: Competitor):
        """Add competitor to monitoring list"""
        if competitor.channel in self.competitors:
            self.competitors[competitor.channel].append(competitor)
    
    def get_competitive_set(self, channel: str, tier: Optional[CompetitorTier] = None) -> List[Competitor]:
        """Get competitive set for a channel"""
        if channel not in self.competitors:
            return []
        
        competitors = self.competitors[channel]
        if tier:
            competitors = [c for c in competitors if c.tier == tier]
        
        return competitors
    
    def analyze_price_positioning(self, our_price: float, channel: str) -> Dict[str, Any]:
        """
        Analyze price positioning vs competitors
        
        Returns:
            - position: "below_market", "at_market", "above_market"
            - difference_pct: percentage difference from market average
            - recommendations: list of pricing recommendations
        """
        competitors = self.get_competitive_set(channel)
        if not competitors:
            return {
                "position": "unknown",
                "difference_pct": 0,
                "recommendations": ["Add competitors to enable price analysis"]
            }
        
        # Calculate market average
        competitor_prices = [c.base_price for c in competitors if c.base_price > 0]
        if not competitor_prices:
            return {
                "position": "unknown",
                "difference_pct": 0,
                "recommendations": ["Competitor price data not available"]
            }
        
        avg_price = sum(competitor_prices) / len(competitor_prices)
        difference_pct = ((our_price - avg_price) / avg_price) * 100
        
        # Determine position
        if difference_pct < -10:
            position = "below_market"
            recommendations = [
                "You are priced significantly below market",
                f"Consider increasing price by {abs(difference_pct):.1f}% to match market",
                "Opportunity to increase revenue without losing bookings"
            ]
        elif difference_pct > 10:
            position = "above_market"
            recommendations = [
                "You are priced above market average",
                f"Consider decreasing price by {difference_pct:.1f}% to be competitive",
                "Risk of losing bookings to cheaper alternatives"
            ]
        else:
            position = "at_market"
            recommendations = [
                "Your pricing is competitive",
                "Monitor competitors daily for any changes",
                "Consider dynamic pricing based on demand"
            ]
        
        return {
            "position": position,
            "our_price": our_price,
            "market_average": avg_price,
            "difference_pct": difference_pct,
            "competitor_count": len(competitor_prices),
            "price_range": {
                "min": min(competitor_prices),
                "max": max(competitor_prices)
            },
            "recommendations": recommendations
        }
    
    def get_monitoring_tasks(self) -> Dict[str, List[str]]:
        """
        Get daily/weekly monitoring tasks
        
        Based on Agoda's competitor monitoring strategy
        """
        return {
            "daily": [
                "Check prices of Tier 1 direct competitors",
                "Monitor availability changes",
                "Track review scores and new reviews",
                "Check for special offers/promotions",
                "Analyze search ranking position"
            ],
            "weekly": [
                "Full competitive set price analysis",
                "Review score trend analysis",
                "Amenity comparison update",
                "Photo quality assessment",
                "Description optimization check"
            ],
            "monthly": [
                "Comprehensive competitor audit",
                "Market positioning analysis",
                "New competitor identification",
                "Competitive advantage assessment",
                "Strategic pricing recommendations"
            ]
        }
    
    def generate_competitor_report(self, channel: str) -> str:
        """Generate competitor analysis report"""
        competitors = self.get_competitive_set(channel)
        
        if not competitors:
            return f"No competitors configured for {channel}"
        
        report = []
        report.append(f"COMPETITOR ANALYSIS REPORT - {channel.upper()}")
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("=" * 60)
        report.append("")
        
        # Group by tier
        for tier in CompetitorTier:
            tier_competitors = [c for c in competitors if c.tier == tier]
            if not tier_competitors:
                continue
            
            report.append(f"\n{tier.value}")
            report.append("-" * 60)
            
            for comp in tier_competitors:
                report.append(f"\n{comp.name}")
                report.append(f"  Rating: {comp.star_rating}⭐ | Review Score: {comp.review_score}/10 ({comp.review_count} reviews)")
                report.append(f"  Distance: {comp.distance_km}km | Base Price: {comp.base_price} GEL")
                report.append(f"  URL: {comp.url}")
        
        return "\n".join(report)

# Predefined competitive sets based on analysis
BOOKING_COMPETITORS = [
    Competitor(
        property_id="",
        name="Orbi Sea Towers",
        channel="booking",
        tier=CompetitorTier.TIER_1_DIRECT,
        distance_km=0.2,
        star_rating=4.5,
        review_score=8.5,
        review_count=500,
        base_price=120.0,
        url=""
    ),
    # Add more competitors here
]

AGODA_COMPETITORS = [
    # Will be populated from Agoda analysis
]

def initialize_competitors() -> CompetitorMonitor:
    """Initialize competitor monitor with predefined sets"""
    monitor = CompetitorMonitor()
    
    for comp in BOOKING_COMPETITORS:
        monitor.add_competitor(comp)
    
    for comp in AGODA_COMPETITORS:
        monitor.add_competitor(comp)
    
    return monitor
