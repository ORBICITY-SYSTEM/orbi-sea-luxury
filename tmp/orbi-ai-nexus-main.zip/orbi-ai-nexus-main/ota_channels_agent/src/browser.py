"""
Browser automation for OTA platforms
"""
import time
import random
from typing import Optional
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options
except ImportError:
    print("Warning: selenium not installed")

from . import config

class BrowserAutomation:
    """Browser automation handler"""
    
    def __init__(self, headless: bool = None):
        if headless is None:
            headless = config.HEADLESS_MODE
        
        self.options = Options()
        if headless:
            self.options.add_argument("--headless")
        self.options.add_argument("--no-sandbox")
        self.options.add_argument("--disable-dev-shm-usage")
        self.options.add_argument("--disable-blink-features=AutomationControlled")
        self.options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        
        self.driver: Optional[webdriver.Chrome] = None
    
    def start(self):
        """Start browser session"""
        try:
            self.driver = webdriver.Chrome(options=self.options)
            self.driver.set_page_load_timeout(config.BROWSER_TIMEOUT)
            return True
        except Exception as e:
            print(f"Error starting browser: {e}")
            return False
    
    def navigate(self, url: str) -> bool:
        """Navigate to URL"""
        if not self.driver:
            return False
        try:
            self.driver.get(url)
            time.sleep(random.uniform(2, 4))
            return True
        except Exception as e:
            print(f"Error navigating to {url}: {e}")
            return False
    
    def wait_for_element(self, by: By, value: str, timeout: int = 10):
        """Wait for element to be present"""
        if not self.driver:
            return None
        try:
            element = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, value))
            )
            return element
        except Exception as e:
            print(f"Element not found: {value}")
            return None
    
    def close(self):
        """Close browser session"""
        if self.driver:
            self.driver.quit()
            self.driver = None
