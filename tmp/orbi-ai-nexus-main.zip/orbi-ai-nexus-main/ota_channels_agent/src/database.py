"""
Database operations for OTA CHANNELS AGENT
"""
import os
from datetime import datetime
from typing import List, Dict, Any, Optional
try:
    from supabase import create_client, Client
except ImportError:
    print("Warning: supabase package not installed")
    Client = None

from . import config

class Database:
    """Database handler for OTA CHANNELS AGENT"""
    
    def __init__(self):
        if config.SUPABASE_URL and config.SUPABASE_ANON_KEY:
            try:
                self.client: Client = create_client(
                    config.SUPABASE_URL,
                    config.SUPABASE_ANON_KEY
                )
                self.connected = True
            except Exception as e:
                print(f"Database connection error: {e}")
                self.connected = False
        else:
            self.connected = False
            print("Warning: Supabase credentials not configured")
    
    def insert_booking(self, booking_data: Dict[str, Any]) -> bool:
        """Insert a new booking record"""
        if not self.connected:
            return False
        try:
            self.client.table("bookings").insert(booking_data).execute()
            return True
        except Exception as e:
            print(f"Error inserting booking: {e}")
            return False
    
    def insert_review(self, review_data: Dict[str, Any]) -> bool:
        """Insert a new review record"""
        if not self.connected:
            return False
        try:
            self.client.table("reviews").insert(review_data).execute()
            return True
        except Exception as e:
            print(f"Error inserting review: {e}")
            return False
    
    def insert_price(self, price_data: Dict[str, Any]) -> bool:
        """Insert price data"""
        if not self.connected:
            return False
        try:
            self.client.table("booking_prices").insert(price_data).execute()
            return True
        except Exception as e:
            print(f"Error inserting price: {e}")
            return False
    
    def insert_competitor_price(self, price_data: Dict[str, Any]) -> bool:
        """Insert competitor price data"""
        if not self.connected:
            return False
        try:
            self.client.table("competitor_prices").insert(price_data).execute()
            return True
        except Exception as e:
            print(f"Error inserting competitor price: {e}")
            return False
    
    def log_task(self, task_name: str, status: str, message: str = "", error_details: str = "", execution_time: float = 0):
        """Log agent task execution"""
        if not self.connected:
            print(f"[LOG] {task_name}: {status} - {message}")
            return
        
        log_data = {
            "task_name": task_name,
            "task_type": "automated",
            "status": status,
            "message": message,
            "error_details": error_details,
            "execution_time_seconds": execution_time
        }
        
        try:
            self.client.table("agent_logs").insert(log_data).execute()
        except Exception as e:
            print(f"Error logging task: {e}")
    
    def get_recent_bookings(self, days: int = 7) -> List[Dict]:
        """Get recent bookings"""
        if not self.connected:
            return []
        try:
            response = self.client.table("bookings")\
                .select("*")\
                .order("created_at", desc=True)\
                .limit(100)\
                .execute()
            return response.data
        except Exception as e:
            print(f"Error fetching bookings: {e}")
            return []
    
    def get_unanswered_reviews(self) -> List[Dict]:
        """Get reviews that need responses"""
        if not self.connected:
            return []
        try:
            response = self.client.table("reviews")\
                .select("*")\
                .eq("response_sent", False)\
                .order("review_date", desc=True)\
                .execute()
            return response.data
        except Exception as e:
            print(f"Error fetching reviews: {e}")
            return []
