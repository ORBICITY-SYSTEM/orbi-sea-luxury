"""
Base class for OTA channel automation
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Any

class BaseChannel(ABC):
    """Base class for all OTA channels"""
    
    def __init__(self, name: str, priority: str):
        self.name = name
        self.priority = priority
        self.authenticated = False
    
    @abstractmethod
    def login(self) -> bool:
        """Login to channel extranet"""
        pass
    
    @abstractmethod
    def get_bookings(self) -> List[Dict[str, Any]]:
        """Fetch recent bookings"""
        pass
    
    @abstractmethod
    def get_reviews(self) -> List[Dict[str, Any]]:
        """Fetch recent reviews"""
        pass
    
    @abstractmethod
    def update_prices(self, price_data: Dict[str, Any]) -> bool:
        """Update room prices"""
        pass
    
    @abstractmethod
    def get_analytics(self) -> Dict[str, Any]:
        """Get performance analytics"""
        pass
