"""
OTA CHANNELS AGENT - Main Entry Point
"""
import sys
import argparse
from datetime import datetime
from .channels.booking import BookingChannel
from .channels.airbnb import AirbnbChannel
from .channels.expedia import ExpediaChannel
from .database import Database
from .mini_agents import MiniAgentCoordinator
from .competitor_monitor import initialize_competitors
from . import config

def daily_morning_check():
    """Daily morning check - 9:00 AM"""
    print("\n" + "="*60)
    print(f"OTA CHANNELS AGENT - Daily Morning Check")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    
    db = Database()
    
    # Initialize MINI agents
    coordinator = MiniAgentCoordinator()
    coordinator.initialize_all()
    
    # Run daily checks
    results = coordinator.run_daily_checks()
    
    # Initialize competitor monitoring
    comp_monitor = initialize_competitors()
    
    # Generate summary
    print(coordinator.generate_summary_report())
    
    db.log_task("daily_morning_check", "SUCCESS", "Completed morning check with MINI agents")
    print("\n✅ Morning check completed!")

def daily_evening_report():
    """Daily evening report - 6:00 PM"""
    print("\n" + "="*60)
    print(f"OTA CHANNELS AGENT - Daily Evening Report")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    
    db = Database()
    
    # Generate daily report
    print("Generating daily report...")
    
    db.log_task("daily_evening_report", "SUCCESS", "Generated evening report")
    print("\n✅ Evening report completed!")

def weekly_analysis():
    """Weekly analysis - Monday 10:00 AM"""
    print("\n" + "="*60)
    print(f"OTA CHANNELS AGENT - Weekly Analysis")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    
    db = Database()
    
    print("Performing weekly analysis...")
    print("- Competitor price analysis")
    print("- Review sentiment analysis")
    print("- Channel performance comparison")
    
    db.log_task("weekly_analysis", "SUCCESS", "Completed weekly analysis")
    print("\n✅ Weekly analysis completed!")

def monthly_report():
    """Monthly report - 1st of month 12:00 PM"""
    print("\n" + "="*60)
    print(f"OTA CHANNELS AGENT - Monthly Report")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60 + "\n")
    
    db = Database()
    
    print("Generating monthly report...")
    print("- Revenue analysis")
    print("- Channel mix analysis")
    print("- Occupancy trends")
    print("- Strategic recommendations")
    
    db.log_task("monthly_report", "SUCCESS", "Generated monthly report")
    print("\n✅ Monthly report completed!")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="OTA CHANNELS AGENT")
    parser.add_argument("--task", choices=["daily_morning", "daily_evening", "weekly_analysis", "monthly_report"],
                       help="Task to execute")
    
    args = parser.parse_args()
    
    if args.task == "daily_morning":
        daily_morning_check()
    elif args.task == "daily_evening":
        daily_evening_report()
    elif args.task == "weekly_analysis":
        weekly_analysis()
    elif args.task == "monthly_report":
        monthly_report()
    else:
        print("OTA CHANNELS AGENT")
        print("Usage: python3 -m src --task [daily_morning|daily_evening|weekly_analysis|monthly_report]")

if __name__ == "__main__":
    main()
