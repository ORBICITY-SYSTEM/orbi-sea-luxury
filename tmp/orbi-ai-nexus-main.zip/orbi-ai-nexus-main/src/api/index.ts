import { createClient } from '@supabase/supabase-js';
import { validateApiKey, checkRateLimit, logApiRequest, triggerWebhook } from '../lib/api-auth';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL!,
  import.meta.env.VITE_SUPABASE_SERVICE_ROLE_KEY! // Service role for bypassing RLS
);

// Gemini API configuration
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY || '';
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent';

/**
 * API Response helper
 */
function apiResponse(success: boolean, data: any = null, error: string | null = null, status: number = 200) {
  return new Response(
    JSON.stringify({
      success,
      data,
      error,
      timestamp: new Date().toISOString(),
    }),
    {
      status,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-API-Key',
      },
    }
  );
}

/**
 * Authentication middleware
 */
async function authenticate(request: Request): Promise<{
  valid: boolean;
  userId?: string;
  keyId?: number;
  permissions?: string[];
  rateLimit?: number;
  error?: string;
}> {
  const apiKey = request.headers.get('X-API-Key') || request.headers.get('Authorization')?.replace('Bearer ', '');

  if (!apiKey) {
    return { valid: false, error: 'Missing API key' };
  }

  const auth = await validateApiKey(apiKey);
  
  if (!auth.valid) {
    return { valid: false, error: 'Invalid API key' };
  }

  // Check rate limit
  const withinLimit = await checkRateLimit(auth.keyId!, auth.rateLimit!);
  if (!withinLimit) {
    return { valid: false, error: 'Rate limit exceeded' };
  }

  return auth;
}

/**
 * Main API handler
 */
export async function handleApiRequest(request: Request): Promise<Response> {
  const startTime = Date.now();
  const url = new URL(request.url);
  const path = url.pathname.replace('/api/v1', '');
  const method = request.method;

  // Handle CORS preflight
  if (method === 'OPTIONS') {
    return apiResponse(true, null, null, 204);
  }

  // Authenticate
  const auth = await authenticate(request);
  if (!auth.valid) {
    return apiResponse(false, null, auth.error || 'Unauthorized', 401);
  }

  let response: Response;
  let statusCode = 200;

  try {
    // Route handling
    if (path === '/departments' && method === 'GET') {
      response = await getDepartments();
    } else if (path.match(/^\/departments\/[^/]+\/agents$/) && method === 'GET') {
      const slug = path.split('/')[2];
      response = await getDepartmentAgents(slug);
    } else if (path.match(/^\/agents\/[^/]+$/) && method === 'GET') {
      const slug = path.split('/')[2];
      response = await getAgent(slug);
    } else if (path.match(/^\/agents\/[^/]+\/chat$/) && method === 'POST') {
      const slug = path.split('/')[2];
      const body = await request.json();
      response = await chatWithAgent(slug, body.message, auth.userId!);
      
      // Trigger webhook
      await triggerWebhook(auth.userId!, 'agent.message.sent', {
        agent_slug: slug,
        message: body.message,
      });
    } else if (path.match(/^\/agents\/[^/]+\/conversations$/) && method === 'GET') {
      const slug = path.split('/')[2];
      response = await getConversations(slug, auth.userId!);
    } else if (path.match(/^\/agents\/[^/]+\/tasks$/) && method === 'GET') {
      const slug = path.split('/')[2];
      response = await getTasks(slug, auth.userId!);
    } else if (path.match(/^\/agents\/[^/]+\/tasks$/) && method === 'POST') {
      const slug = path.split('/')[2];
      const body = await request.json();
      response = await createTask(slug, body, auth.userId!);
    } else if (path.match(/^\/agents\/[^/]+\/files$/) && method === 'POST') {
      const slug = path.split('/')[2];
      const formData = await request.formData();
      response = await uploadFile(slug, formData, auth.userId!);
    } else {
      response = apiResponse(false, null, 'Endpoint not found', 404);
      statusCode = 404;
    }

    statusCode = response.status;
  } catch (error) {
    console.error('API Error:', error);
    response = apiResponse(false, null, error instanceof Error ? error.message : 'Internal server error', 500);
    statusCode = 500;
  }

  // Log request
  const responseTime = Date.now() - startTime;
  await logApiRequest(auth.keyId!, path, method, statusCode, responseTime);

  return response;
}

/**
 * GET /departments
 */
async function getDepartments(): Promise<Response> {
  const { data, error } = await supabase
    .from('departments')
    .select('*')
    .order('name');

  if (error) {
    return apiResponse(false, null, error.message, 500);
  }

  return apiResponse(true, data);
}

/**
 * GET /departments/:slug/agents
 */
async function getDepartmentAgents(departmentSlug: string): Promise<Response> {
  const { data: department } = await supabase
    .from('departments')
    .select('id')
    .eq('slug', departmentSlug)
    .single();

  if (!department) {
    return apiResponse(false, null, 'Department not found', 404);
  }

  const { data, error } = await supabase
    .from('agents')
    .select('*')
    .eq('department_id', department.id)
    .eq('status', 'active')
    .order('name');

  if (error) {
    return apiResponse(false, null, error.message, 500);
  }

  return apiResponse(true, data);
}

/**
 * GET /agents/:slug
 */
async function getAgent(agentSlug: string): Promise<Response> {
  const { data, error } = await supabase
    .from('agents')
    .select('*, departments(*)')
    .eq('slug', agentSlug)
    .single();

  if (error || !data) {
    return apiResponse(false, null, 'Agent not found', 404);
  }

  return apiResponse(true, data);
}

/**
 * POST /agents/:slug/chat
 */
async function chatWithAgent(agentSlug: string, message: string, userId: string): Promise<Response> {
  // Get agent
  const { data: agent } = await supabase
    .from('agents')
    .select('*')
    .eq('slug', agentSlug)
    .single();

  if (!agent) {
    return apiResponse(false, null, 'Agent not found', 404);
  }

  // Get conversation history
  const { data: history } = await supabase
    .from('agent_conversations')
    .select('*')
    .eq('agent_id', agent.id)
    .eq('user_id', userId)
    .order('created_at', { ascending: true })
    .limit(10);

  // Build messages for Gemini
  const messages = [
    { role: 'user', parts: [{ text: agent.system_prompt }] },
    ...(history || []).map((msg: any) => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }],
    })),
    { role: 'user', parts: [{ text: message }] },
  ];

  // Call Gemini API
  const geminiResponse = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents: messages }),
  });

  if (!geminiResponse.ok) {
    return apiResponse(false, null, 'AI service error', 500);
  }

  const geminiData = await geminiResponse.json();
  const aiResponse = geminiData.candidates?.[0]?.content?.parts?.[0]?.text || 'No response';

  // Save conversation
  await supabase.from('agent_conversations').insert([
    { agent_id: agent.id, user_id: userId, role: 'user', content: message },
    { agent_id: agent.id, user_id: userId, role: 'assistant', content: aiResponse },
  ]);

  return apiResponse(true, {
    message: aiResponse,
    agent: {
      name: agent.name,
      slug: agent.slug,
    },
  });
}

/**
 * GET /agents/:slug/conversations
 */
async function getConversations(agentSlug: string, userId: string): Promise<Response> {
  const { data: agent } = await supabase
    .from('agents')
    .select('id')
    .eq('slug', agentSlug)
    .single();

  if (!agent) {
    return apiResponse(false, null, 'Agent not found', 404);
  }

  const { data, error } = await supabase
    .from('agent_conversations')
    .select('*')
    .eq('agent_id', agent.id)
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) {
    return apiResponse(false, null, error.message, 500);
  }

  return apiResponse(true, data);
}

/**
 * GET /agents/:slug/tasks
 */
async function getTasks(agentSlug: string, userId: string): Promise<Response> {
  const { data: agent } = await supabase
    .from('agents')
    .select('id')
    .eq('slug', agentSlug)
    .single();

  if (!agent) {
    return apiResponse(false, null, 'Agent not found', 404);
  }

  const { data, error } = await supabase
    .from('agent_tasks')
    .select('*')
    .eq('agent_id', agent.id)
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) {
    return apiResponse(false, null, error.message, 500);
  }

  return apiResponse(true, data);
}

/**
 * POST /agents/:slug/tasks
 */
async function createTask(agentSlug: string, taskData: any, userId: string): Promise<Response> {
  const { data: agent } = await supabase
    .from('agents')
    .select('id')
    .eq('slug', agentSlug)
    .single();

  if (!agent) {
    return apiResponse(false, null, 'Agent not found', 404);
  }

  const { data, error } = await supabase
    .from('agent_tasks')
    .insert({
      agent_id: agent.id,
      user_id: userId,
      title: taskData.title,
      description: taskData.description,
      priority: taskData.priority || 'medium',
      due_date: taskData.due_date,
    })
    .select()
    .single();

  if (error) {
    return apiResponse(false, null, error.message, 500);
  }

  return apiResponse(true, data, null, 201);
}

/**
 * POST /agents/:slug/files
 */
async function uploadFile(agentSlug: string, formData: FormData, userId: string): Promise<Response> {
  const { data: agent } = await supabase
    .from('agents')
    .select('id')
    .eq('slug', agentSlug)
    .single();

  if (!agent) {
    return apiResponse(false, null, 'Agent not found', 404);
  }

  const file = formData.get('file') as File;
  if (!file) {
    return apiResponse(false, null, 'No file provided', 400);
  }

  // Upload to Supabase Storage
  const fileName = `${userId}/${agent.id}/${Date.now()}_${file.name}`;
  const { data: uploadData, error: uploadError } = await supabase.storage
    .from('agent-files')
    .upload(fileName, file);

  if (uploadError) {
    return apiResponse(false, null, uploadError.message, 500);
  }

  // Save file metadata
  const { data, error } = await supabase
    .from('agent_files')
    .insert({
      agent_id: agent.id,
      user_id: userId,
      filename: file.name,
      file_path: uploadData.path,
      file_size: file.size,
      mime_type: file.type,
    })
    .select()
    .single();

  if (error) {
    return apiResponse(false, null, error.message, 500);
  }

  return apiResponse(true, data, null, 201);
}
