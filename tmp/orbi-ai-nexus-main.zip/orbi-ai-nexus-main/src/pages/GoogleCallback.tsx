import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const GoogleCallback = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");

  useEffect(() => {
    const handleCallback = async () => {
      const code = searchParams.get("code");
      const error = searchParams.get("error");

      if (error) {
        setStatus("error");
        toast({
          title: "დაკავშირება ვერ მოხერხდა",
          description: `Google OAuth შეცდომა: ${error}`,
          variant: "destructive",
        });
        setTimeout(() => navigate("/"), 3000);
        return;
      }

      if (!code) {
        setStatus("error");
        toast({
          title: "შეცდომა",
          description: "Authorization code არ მოიძებნა",
          variant: "destructive",
        });
        setTimeout(() => navigate("/"), 3000);
        return;
      }

      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          throw new Error("არ ხართ ავტორიზებული");
        }

        // Pass the redirect_uri to backend for consistency
        const redirectUri = `${window.location.origin}/google-callback`;
        
        const { data, error: functionError } = await supabase.functions.invoke(
          "google-auth",
          {
            body: { 
              code,
              redirect_uri: redirectUri 
            },
          }
        );

        if (functionError) throw functionError;

        setStatus("success");
        toast({
          title: "Gmail დაკავშირდა წარმატებით! ✓",
          description: "orbi.apartments1@gmail.com დაკავშირებულია სისტემასთან",
        });

        setTimeout(() => navigate("/"), 2000);
      } catch (error) {
        console.error("OAuth callback error:", error);
        setStatus("error");
        toast({
          title: "დაკავშირება ვერ მოხერხდა",
          description: error instanceof Error ? error.message : "დაფიქსირდა შეცდომა",
          variant: "destructive",
        });
        setTimeout(() => navigate("/"), 3000);
      }
    };

    handleCallback();
  }, [searchParams, navigate, toast]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-primary/5">
      <div className="text-center space-y-4">
        {status === "loading" && (
          <>
            <Loader2 className="h-12 w-12 animate-spin mx-auto text-primary" />
            <h2 className="text-xl font-semibold">Gmail-ის დაკავშირება...</h2>
            <p className="text-muted-foreground">გთხოვთ დაელოდოთ</p>
          </>
        )}
        {status === "success" && (
          <>
            <div className="h-12 w-12 mx-auto rounded-full bg-success/20 flex items-center justify-center">
              <svg className="h-6 w-6 text-success" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-success">წარმატებული დაკავშირება!</h2>
            <p className="text-muted-foreground">გადამისამართება მთავარ გვერდზე...</p>
          </>
        )}
        {status === "error" && (
          <>
            <div className="h-12 w-12 mx-auto rounded-full bg-destructive/20 flex items-center justify-center">
              <svg className="h-6 w-6 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentPage">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-destructive">დაკავშირება ვერ მოხერხდა</h2>
            <p className="text-muted-foreground">გადამისამართება მთავარ გვერდზე...</p>
          </>
        )}
      </div>
    </div>
  );
};

export default GoogleCallback;
