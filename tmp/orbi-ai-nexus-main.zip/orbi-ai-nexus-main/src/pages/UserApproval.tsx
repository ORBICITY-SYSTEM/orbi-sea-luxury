import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, XCircle, Clock } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface PendingUser {
  id: string;
  email: string;
  full_name: string;
  requested_role: string;
  status: string;
  created_at: string;
}

export default function UserApproval() {
  const [pendingUsers, setPendingUsers] = useState<PendingUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    checkAdminAccess();
    fetchPendingUsers();
  }, []);

  const checkAdminAccess = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id);

    const isAdmin = roles?.some((r) => r.role === "admin");
    if (!isAdmin) {
      toast({
        title: "წვდომა აკრძალულია",
        description: "მხოლოდ ადმინისტრატორს აქვს წვდომა ამ გვერდზე.",
        variant: "destructive",
      });
      navigate("/");
    }
  };

  const fetchPendingUsers = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("pending_users")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast({
        title: "შეცდომა",
        description: "ვერ მოხერხდა მონაცემების ჩატვირთვა",
        variant: "destructive",
      });
    } else {
      setPendingUsers(data || []);
    }
    setLoading(false);
  };

  const approveUser = async (pendingUser: PendingUser, assignedRole: string) => {
    setProcessingId(pendingUser.id);
    
    try {
      // Create user account via edge function
      const { data, error: createError } = await supabase.functions.invoke('create-user', {
        body: {
          email: pendingUser.email,
          fullName: pendingUser.full_name,
          role: assignedRole
        }
      });

      if (createError) throw createError;

      // Update pending user status
      const { error: updateError } = await supabase
        .from("pending_users")
        .update({
          status: "approved",
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id
        })
        .eq("id", pendingUser.id);

      if (updateError) throw updateError;

      toast({
        title: "მომხმარებელი დამტკიცებულია!",
        description: `${pendingUser.email} - როლი: ${assignedRole}`,
      });

      fetchPendingUsers();
    } catch (error: any) {
      toast({
        title: "შეცდომა",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setProcessingId(null);
    }
  };

  const rejectUser = async (userId: string) => {
    setProcessingId(userId);
    
    try {
      const { error } = await supabase
        .from("pending_users")
        .update({
          status: "rejected",
          reviewed_at: new Date().toISOString(),
          reviewed_by: (await supabase.auth.getUser()).data.user?.id
        })
        .eq("id", userId);

      if (error) throw error;

      toast({
        title: "მომხმარებელი უარყოფილია",
      });

      fetchPendingUsers();
    } catch (error: any) {
      toast({
        title: "შეცდომა",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">მომხმარებლების დამტკიცება</h1>
          <p className="text-muted-foreground">განიხილეთ და დაამტკიცეთ რეგისტრაციის მოთხოვნები</p>
        </div>

        <div className="grid gap-4">
          {pendingUsers.filter(u => u.status === 'pending').length === 0 && (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                ახალი რეგისტრაციის მოთხოვნები არ არის
              </CardContent>
            </Card>
          )}

          {pendingUsers.map((user) => (
            <Card key={user.id} className={user.status !== 'pending' ? 'opacity-60' : ''}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{user.full_name}</CardTitle>
                    <CardDescription>{user.email}</CardDescription>
                  </div>
                  <Badge variant={
                    user.status === 'approved' ? 'default' :
                    user.status === 'rejected' ? 'destructive' : 'secondary'
                  }>
                    {user.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                    {user.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                    {user.status === 'rejected' && <XCircle className="w-3 h-3 mr-1" />}
                    {user.status === 'pending' ? 'მოლოდინში' : 
                     user.status === 'approved' ? 'დამტკიცებული' : 'უარყოფილი'}
                  </Badge>
                </div>
              </CardHeader>

              {user.status === 'pending' && (
                <CardContent>
                  <div className="flex items-center gap-4">
                    <Select
                      defaultValue={user.requested_role}
                      onValueChange={(role) => {
                        const updatedUsers = [...pendingUsers];
                        const index = updatedUsers.findIndex(u => u.id === user.id);
                        updatedUsers[index].requested_role = role;
                        setPendingUsers(updatedUsers);
                      }}
                    >
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="აირჩიეთ როლი" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">მომხმარებელი</SelectItem>
                        <SelectItem value="finance">ფინანსები</SelectItem>
                        <SelectItem value="marketing">მარკეტინგი</SelectItem>
                        <SelectItem value="logistics">ლოჯისტიკა</SelectItem>
                        <SelectItem value="customer_service">სტუმარ მომსახურება</SelectItem>
                        <SelectItem value="manager">მენეჯერი</SelectItem>
                        <SelectItem value="admin">ადმინისტრატორი</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button
                      onClick={() => approveUser(user, user.requested_role)}
                      disabled={processingId === user.id}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      {processingId === user.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <CheckCircle className="h-4 w-4 mr-2" />
                      )}
                      დამტკიცება
                    </Button>

                    <Button
                      onClick={() => rejectUser(user.id)}
                      disabled={processingId === user.id}
                      variant="destructive"
                    >
                      {processingId === user.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <XCircle className="h-4 w-4 mr-2" />
                      )}
                      უარყოფა
                    </Button>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
