import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Calendar, Sparkles, Loader2, Download, FileSpreadsheet, Clock, BookOpen, Edit, Trash2, Save, X, FileText, History, RotateCcw, Eye, TrendingUp, Receipt, DollarSign } from "lucide-react";
import jsPDF from "jspdf";
import { useNavigate, useParams } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import * as XLSX from 'xlsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { analyzeExcelFileForMonth, exportFilteredDataToExcel } from "@/utils/excelAnalyzerMonthly";
import { RevenueModuleDetail } from "@/components/finance/RevenueModuleDetail";
import { ExpensesModuleDetail } from "@/components/finance/ExpensesModuleDetail";
import { ProfitModuleDetail } from "@/components/finance/ProfitModuleDetail";

const months = [
  { value: "1", label: "იანვარი" },
  { value: "2", label: "თებერვალი" },
  { value: "3", label: "მარტი" },
  { value: "4", label: "აპრილი" },
  { value: "5", label: "მაისი" },
  { value: "6", label: "ივნისი" },
  { value: "7", label: "ივლისი" },
  { value: "8", label: "აგვისტო" },
  { value: "9", label: "სექტემბერი" },
  { value: "10", label: "ოქტომბერი" },
  { value: "11", label: "ნოემბერი" },
  { value: "12", label: "დეკემბერი" },
];

const FinanceMonthlyAnalysisDetail = () => {
  const navigate = useNavigate();
  const { year, month } = useParams();
  const { toast } = useToast();
  const [generatingAI, setGeneratingAI] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const [editingInstruction, setEditingInstruction] = useState<string | null>(null);
  const [newInstruction, setNewInstruction] = useState({ title: "", text: "", category: "general" });
  const [editingAnalysis, setEditingAnalysis] = useState(false);
  const [editedAnalysis, setEditedAnalysis] = useState({ summary: "", recommendations: "" });
  const [showVersions, setShowVersions] = useState(false);
  const [excelData, setExcelData] = useState<any[][]>([]);
  const [showExcelViewer, setShowExcelViewer] = useState(false);
  const [loadingExcel, setLoadingExcel] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedColumn, setSelectedColumn] = useState<string>("all");

  const { data: upload, isLoading, refetch } = useQuery({
    queryKey: ['monthly-analysis-detail', year, month],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from('monthly_analysis_uploads')
        .select('*')
        .eq('user_id', user.id)
        .eq('year', parseInt(year!))
        .eq('month', parseInt(month!))
        .single();

      if (error) throw error;
      return data;
    },
  });

  const { data: instructions, refetch: refetchInstructions } = useQuery({
    queryKey: ['finance-analysis-instructions'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase
        .from('finance_analysis_instructions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const { data: versions, refetch: refetchVersions } = useQuery({
    queryKey: ['analysis-versions', upload?.id],
    queryFn: async () => {
      if (!upload?.id) return [];

      const { data, error } = await supabase
        .from('monthly_analysis_versions')
        .select('*')
        .eq('upload_id', upload.id)
        .order('version_number', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!upload?.id,
  });

  const handleViewExcelFile = async (filePath: string) => {
    setLoadingExcel(true);
    try {
      const { data, error } = await supabase.storage
        .from('monthly-analysis')
        .download(filePath);

      if (error) throw error;

      const arrayBuffer = await data.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
      
      setExcelData(jsonData as any[][]);
      setShowExcelViewer(true);

      toast({
        title: "✅ ფაილი ჩაიტვირთა",
        description: "Excel ფაილი წარმატებით გაიხსნა",
      });
    } catch (error) {
      console.error('View Excel error:', error);
      toast({
        title: "შეცდომა",
        description: "ფაილის ჩატვირთვისას მოხდა შეცდომა",
        variant: "destructive",
      });
    } finally {
      setLoadingExcel(false);
    }
  };

  const handleDownloadExcelFile = async (filePath: string, fileName: string) => {
    try {
      const { data, error } = await supabase.storage
        .from('monthly-analysis')
        .download(filePath);

      if (error) throw error;

      const url = window.URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      toast({
        title: "✅ ფაილი ჩამოიტვირთა",
        description: "Excel ფაილი წარმატებით ჩამოიტვირთა",
      });
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "შეცდომა",
        description: "ფაილის ჩამოტვირთვისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleExportFilteredExcel = async () => {
    if (!upload) return;
    
    try {
      toast({
        title: "📊 მოიწყობა ექსპორტი...",
        description: "Excel ფაილი იქმნება სტატისტიკით",
      });

      const { data, error } = await supabase.storage
        .from('monthly-analysis')
        .download(upload.file_path);

      if (error) throw error;

      const file = new File([data], upload.file_name);
      const analysisResult = await analyzeExcelFileForMonth(file, parseInt(year!), parseInt(month!));
      
      exportFilteredDataToExcel(analysisResult, parseInt(year!), parseInt(month!));

      toast({
        title: "✅ წარმატება",
        description: "Excel ფაილი ჩამოიტვირთა ყველა სტატისტიკით",
      });
    } catch (error) {
      console.error('Export error:', error);
      toast({
        title: "შეცდომა",
        description: "ექსპორტისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleDownloadAIPDF = (uploadData: any) => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      const maxWidth = pageWidth - (margin * 2);
      
      doc.setFillColor(16, 185, 129);
      doc.rect(0, 0, pageWidth, 40, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(24);
      doc.text('AI ფინანსური ანალიზი', margin, 25);
      
      doc.setFontSize(12);
      const monthName = months.find(m => m.value === uploadData.month.toString())?.label || '';
      doc.text(`${monthName} ${uploadData.year}`, margin, 35);
      
      doc.setTextColor(0, 0, 0);
      let yPosition = 55;
      
      doc.setFontSize(16);
      doc.setFont(undefined, 'bold');
      doc.text('მთავარი მეტრიკები', margin, yPosition);
      yPosition += 10;
      
      doc.setFontSize(11);
      doc.setFont(undefined, 'normal');
      
      const metrics = [
        { label: 'სულ შემოსავალი:', value: `₾${uploadData.total_revenue?.toLocaleString()}` },
        { label: 'დაკავება:', value: `${uploadData.occupancy_rate?.toFixed(1)}%` },
        { label: 'ADR (საშუალო ღამის ფასი):', value: `₾${uploadData.adr?.toFixed(0)}` },
        { label: 'RevPAR:', value: `₾${uploadData.revpar?.toFixed(2)}` },
        { label: 'სულ ღამეები:', value: uploadData.total_nights?.toLocaleString() },
        { label: 'სულ ბრონირებები:', value: uploadData.total_bookings?.toLocaleString() },
        { label: 'ოთახების რაოდენობა:', value: uploadData.total_rooms },
      ];
      
      metrics.forEach(metric => {
        doc.text(`${metric.label} ${metric.value}`, margin, yPosition);
        yPosition += 7;
      });
      
      yPosition += 5;
      
      if (uploadData.ai_summary_ka) {
        doc.setFontSize(16);
        doc.setFont(undefined, 'bold');
        doc.text('AI ანალიზი და რეკომენდაციები', margin, yPosition);
        yPosition += 10;
        
        doc.setFontSize(10);
        doc.setFont(undefined, 'normal');
        
        const lines = doc.splitTextToSize(uploadData.ai_summary_ka, maxWidth);
        
        lines.forEach((line: string) => {
          if (yPosition > pageHeight - margin) {
            doc.addPage();
            yPosition = margin;
          }
          doc.text(line, margin, yPosition);
          yPosition += 6;
        });
      }
      
      const footerY = pageHeight - 15;
      doc.setFontSize(8);
      doc.setTextColor(128, 128, 128);
      doc.text(`გენერირებულია: ${new Date().toLocaleString('ka-GE')}`, margin, footerY);
      doc.text('Orbi City - AI Financial Analysis', pageWidth - margin, footerY, { align: 'right' });
      
      const fileName = `AI_Analysis_${monthName}_${uploadData.year}.pdf`;
      doc.save(fileName);
      
      toast({
        title: "✅ PDF ჩამოიტვირთა",
        description: `${fileName} წარმატებით შეიქმნა`,
      });
    } catch (error) {
      console.error('PDF generation error:', error);
      toast({
        title: "შეცდომა",
        description: "PDF-ის გენერირებისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleGenerateAISummary = async () => {
    if (!upload) return;
    
    setGeneratingAI(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-finance-summary', {
        body: { uploadId: upload.id },
      });

      if (error) throw error;

      toast({
        title: "✨ AI ანალიზი დასრულდა",
        description: "თვიური რეპორტი წარმატებით გენერირდა",
      });

      refetch();
    } catch (error: any) {
      console.error('AI generation error:', error);
      toast({
        title: "შეცდომა",
        description: error.message || "AI ანალიზის გენერირებისას მოხდა შეცდომა",
        variant: "destructive",
      });
    } finally {
      setGeneratingAI(false);
    }
  };

  const handleSaveInstruction = async () => {
    if (!newInstruction.title || !newInstruction.text) {
      toast({
        title: "შეცდომა",
        description: "გთხოვთ შეავსოთ სათაური და ტექსტი",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      if (editingInstruction) {
        const { error } = await supabase
          .from('finance_analysis_instructions')
          .update({
            title: newInstruction.title,
            instruction_text: newInstruction.text,
            category: newInstruction.category,
          })
          .eq('id', editingInstruction);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('finance_analysis_instructions')
          .insert({
            user_id: user.id,
            title: newInstruction.title,
            instruction_text: newInstruction.text,
            category: newInstruction.category,
          });

        if (error) throw error;
      }

      toast({
        title: "✅ წარმატება",
        description: editingInstruction ? "ინსტრუქცია განახლდა" : "ინსტრუქცია დაემატა",
      });

      setNewInstruction({ title: "", text: "", category: "general" });
      setEditingInstruction(null);
      refetchInstructions();
    } catch (error) {
      console.error('Save instruction error:', error);
      toast({
        title: "შეცდომა",
        description: "ინსტრუქციის შენახვისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleDeleteInstruction = async (id: string) => {
    try {
      const { error } = await supabase
        .from('finance_analysis_instructions')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "✅ წაიშალა",
        description: "ინსტრუქცია წარმატებით წაიშალა",
      });

      refetchInstructions();
    } catch (error) {
      console.error('Delete instruction error:', error);
      toast({
        title: "შეცდომა",
        description: "ინსტრუქციის წაშლისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleToggleActive = async (id: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('finance_analysis_instructions')
        .update({ is_active: !isActive })
        .eq('id', id);

      if (error) throw error;

      refetchInstructions();
    } catch (error) {
      console.error('Toggle active error:', error);
    }
  };

  const handleStartEditAnalysis = () => {
    if (upload) {
      setEditedAnalysis({
        summary: upload.ai_summary_ka || "",
        recommendations: upload.ai_recommendations || "",
      });
      setEditingAnalysis(true);
    }
  };

  const handleSaveAnalysis = async () => {
    if (!upload) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Save current version before updating
      const currentVersionNumber = (versions?.length || 0) + 1;
      
      const { error: versionError } = await supabase
        .from('monthly_analysis_versions')
        .insert({
          upload_id: upload.id,
          version_number: currentVersionNumber,
          ai_summary_ka: upload.ai_summary_ka,
          ai_recommendations: upload.ai_recommendations,
          created_by: user.id,
          notes: `Version ${currentVersionNumber}`,
        });

      if (versionError) throw versionError;

      // Update the main record
      const { error } = await supabase
        .from('monthly_analysis_uploads')
        .update({
          ai_summary_ka: editedAnalysis.summary,
          ai_recommendations: editedAnalysis.recommendations,
        })
        .eq('id', upload.id);

      if (error) throw error;

      toast({
        title: "✅ განახლებულია",
        description: "AI ანალიზი წარმატებით განახლდა და ვერსია შეინახა",
      });

      setEditingAnalysis(false);
      refetch();
      refetchVersions();
    } catch (error) {
      console.error('Save analysis error:', error);
      toast({
        title: "შეცდომა",
        description: "ანალიზის შენახვისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleRestoreVersion = async (version: any) => {
    if (!upload) return;

    try {
      const { error } = await supabase
        .from('monthly_analysis_uploads')
        .update({
          ai_summary_ka: version.ai_summary_ka,
          ai_recommendations: version.ai_recommendations,
        })
        .eq('id', upload.id);

      if (error) throw error;

      toast({
        title: "✅ აღდგენილია",
        description: `ვერსია ${version.version_number} წარმატებით აღდგა`,
      });

      setShowVersions(false);
      refetch();
    } catch (error) {
      console.error('Restore version error:', error);
      toast({
        title: "შეცდომა",
        description: "ვერსიის აღდგენისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const handleDeleteVersion = async (versionId: string) => {
    try {
      const { error } = await supabase
        .from('monthly_analysis_versions')
        .delete()
        .eq('id', versionId);

      if (error) throw error;

      toast({
        title: "✅ წაიშალა",
        description: "ვერსია წარმატებით წაიშალა",
      });

      refetchVersions();
    } catch (error) {
      console.error('Delete version error:', error);
      toast({
        title: "შეცდომა",
        description: "ვერსიის წაშლისას მოხდა შეცდომა",
        variant: "destructive",
      });
    }
  };

  const monthLabel = months.find(m => m.value === month)?.label || '';

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/finance/monthly-analysis")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                უკან
              </Button>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-green-500 to-emerald-500">
                  <Calendar className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-foreground">
                    {monthLabel} {year}
                  </h1>
                  <p className="text-xs text-muted-foreground">
                    თვიური ფინანსური რეპორტები და ანალიტიკა
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowInstructions(!showInstructions)}
                className="gap-2"
              >
                <BookOpen className="h-4 w-4" />
                AI მემორი
              </Button>
              {upload?.ai_summary_ka && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowVersions(!showVersions)}
                  className="gap-2"
                >
                  <History className="h-4 w-4" />
                  ვერსიები ({versions?.length || 0})
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {showVersions && versions && (
          <Card className="p-6 mb-6 bg-gradient-to-br from-blue-500/5 to-cyan-500/5 border-blue-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <History className="h-5 w-5 text-blue-600" />
                <h2 className="text-xl font-bold">AI ანალიზის ვერსიების ისტორია</h2>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowVersions(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mb-6">
              აქ ნახავთ ყველა შენახულ ვერსიას და შეგიძლიათ დაბრუნდეთ ნებისმიერ ვერსიაზე
            </p>

            <div className="space-y-3">
              {versions.length > 0 ? (
                versions.map((version: any) => (
                  <Card key={version.id} className="p-4 bg-background">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-lg">ვერსია {version.version_number}</span>
                          <span className="px-2 py-0.5 bg-blue-500/10 text-blue-600 text-xs rounded-full">
                            {new Date(version.created_at).toLocaleDateString('ka-GE')}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {new Date(version.created_at).toLocaleTimeString('ka-GE', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRestoreVersion(version)}
                          className="gap-2"
                        >
                          <RotateCcw className="h-3 w-3" />
                          აღდგენა
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteVersion(version.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    
                    <Collapsible>
                      <CollapsibleTrigger asChild>
                        <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                          ტექსტის ნახვა
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-2 p-3 bg-accent/30 rounded-lg">
                        <div className="text-sm whitespace-pre-wrap">
                          {version.ai_summary_ka?.substring(0, 500)}
                          {version.ai_summary_ka && version.ai_summary_ka.length > 500 ? '...' : ''}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </Card>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>ჯერ არ გაქვთ შენახული ვერსიები</p>
                  <p className="text-xs mt-2">პირველი რედაქტირების შემდეგ ვერსიები ავტომატურად შეინახება</p>
                </div>
              )}
            </div>
          </Card>
        )}

        {showExcelViewer && excelData.length > 0 && (() => {
          const headers = excelData[0] || [];
          const dataRows = excelData.slice(1);
          
          // Filter logic
          const filteredRows = dataRows.filter((row: any[]) => {
            if (!searchTerm) return true;
            
            if (selectedColumn === "all") {
              return row.some(cell => 
                String(cell || '').toLowerCase().includes(searchTerm.toLowerCase())
              );
            } else {
              const colIndex = parseInt(selectedColumn);
              const cellValue = String(row[colIndex] || '').toLowerCase();
              return cellValue.includes(searchTerm.toLowerCase());
            }
          });

          return (
            <Card className="p-6 mb-6 bg-gradient-to-br from-green-500/5 to-emerald-500/5 border-green-200">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="h-5 w-5 text-green-600" />
                  <h2 className="text-xl font-bold">Excel მონაცემები</h2>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setShowExcelViewer(false);
                    setSearchTerm("");
                    setSelectedColumn("all");
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                {upload?.file_name}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="search">ძებნა</Label>
                  <Input
                    id="search"
                    placeholder="მოძებნე მონაცემები..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full"
                  />
                </div>
                <div>
                  <Label htmlFor="column-filter">ფილტრი კოლონით</Label>
                  <Select value={selectedColumn} onValueChange={setSelectedColumn}>
                    <SelectTrigger id="column-filter">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">ყველა კოლონა</SelectItem>
                      {headers.map((header: any, index: number) => (
                        <SelectItem key={index} value={String(index)}>
                          {header || `კოლონა ${index + 1}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {filteredRows.length > 0 ? (
                <>
                  <div className="overflow-x-auto border border-border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {headers.map((header: any, index: number) => (
                            <TableHead key={index} className="bg-accent/50 font-bold">
                              {header || `Column ${index + 1}`}
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredRows.slice(0, 50).map((row: any[], rowIndex: number) => (
                          <TableRow key={rowIndex}>
                            {row.map((cell: any, cellIndex: number) => (
                              <TableCell key={cellIndex} className="text-sm">
                                {cell !== null && cell !== undefined ? String(cell) : ''}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  {filteredRows.length > 50 && (
                    <p className="text-xs text-muted-foreground mt-3 text-center">
                      ნაჩვენებია პირველი 50 მწკრივი {filteredRows.length} გაფილტრული მწკრივიდან
                    </p>
                  )}
                  {searchTerm && (
                    <p className="text-xs text-green-600 mt-2 text-center">
                      ნაპოვნია {filteredRows.length} შედეგი {dataRows.length} მწკრივიდან
                    </p>
                  )}
                </>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <FileSpreadsheet className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p className="font-medium">შედეგები ვერ მოიძებნა</p>
                  <p className="text-xs mt-1">სცადეთ სხვა საძიებო ტერმინი</p>
                </div>
              )}
            </Card>
          );
        })()}

        {showInstructions && (
          <Card className="p-6 mb-6 bg-gradient-to-br from-purple-500/5 to-blue-500/5 border-purple-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-purple-600" />
                <h2 className="text-xl font-bold">AI მემორი და ინსტრუქციები</h2>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowInstructions(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-sm text-muted-foreground mb-6">
              აქ ჩაწერე პრინციპები და ინსტრუქციები როგორ უნდა მუშაობდეს AI ანალიზი.
            </p>

            <div className="bg-background rounded-lg p-4 mb-4 border border-border">
              <div className="space-y-3">
                <div>
                  <Label htmlFor="title">სათაური</Label>
                  <Input
                    id="title"
                    placeholder="მაგ: OtelMS ფაილების ფილტრაცია"
                    value={newInstruction.title}
                    onChange={(e) => setNewInstruction({ ...newInstruction, title: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="category">კატეგორია</Label>
                  <Select
                    value={newInstruction.category}
                    onValueChange={(value) => setNewInstruction({ ...newInstruction, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">ზოგადი</SelectItem>
                      <SelectItem value="otelms">OtelMS</SelectItem>
                      <SelectItem value="filtering">ფილტრაცია</SelectItem>
                      <SelectItem value="analysis">ანალიზი</SelectItem>
                      <SelectItem value="metrics">მეტრიკები</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="text">ინსტრუქცია</Label>
                  <Textarea
                    id="text"
                    placeholder="დეტალური ინსტრუქცია AI-სთვის..."
                    value={newInstruction.text}
                    onChange={(e) => setNewInstruction({ ...newInstruction, text: e.target.value })}
                    rows={4}
                  />
                </div>
                <Button onClick={handleSaveInstruction} className="w-full gap-2">
                  <Save className="h-4 w-4" />
                  {editingInstruction ? "განახლება" : "დამატება"}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              {instructions && instructions.length > 0 ? (
                instructions.map((instruction: any) => (
                  <Collapsible key={instruction.id}>
                    <div className="flex items-center gap-2 p-3 bg-background rounded-lg border border-border">
                      <CollapsibleTrigger className="flex-1 text-left">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{instruction.title}</p>
                            <p className="text-xs text-muted-foreground">{instruction.category}</p>
                          </div>
                        </div>
                      </CollapsibleTrigger>
                      <Switch
                        checked={instruction.is_active}
                        onCheckedChange={() => handleToggleActive(instruction.id, instruction.is_active)}
                      />
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditingInstruction(instruction.id);
                          setNewInstruction({
                            title: instruction.title,
                            text: instruction.instruction_text,
                            category: instruction.category,
                          });
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteInstruction(instruction.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <CollapsibleContent className="px-3 py-2 text-sm text-muted-foreground">
                      {instruction.instruction_text}
                    </CollapsibleContent>
                  </Collapsible>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BookOpen className="h-12 w-12 mx-auto mb-3 opacity-50" />
                  <p>ჯერ არ გაქვთ დამატებული ინსტრუქციები</p>
                </div>
              )}
            </div>
          </Card>
        )}

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-[200px] w-full" />
            <Skeleton className="h-[400px] w-full" />
          </div>
        ) : upload ? (
          <div className="space-y-6">
            {/* Tabs Navigation */}
            <Tabs defaultValue="reporting" className="w-full">
              <TabsList className="grid w-full grid-cols-4 h-auto">
                <TabsTrigger value="reporting" className="flex items-center gap-2 py-3">
                  <FileText className="h-4 w-4" />
                  <span className="hidden sm:inline">Reporting</span>
                </TabsTrigger>
                <TabsTrigger value="revenue" className="flex items-center gap-2 py-3">
                  <TrendingUp className="h-4 w-4" />
                  <span className="hidden sm:inline">Revenue</span>
                </TabsTrigger>
                <TabsTrigger value="expenses" className="flex items-center gap-2 py-3">
                  <Receipt className="h-4 w-4" />
                  <span className="hidden sm:inline">Expenses</span>
                </TabsTrigger>
                <TabsTrigger value="profit" className="flex items-center gap-2 py-3">
                  <DollarSign className="h-4 w-4" />
                  <span className="hidden sm:inline">Profit & ROI</span>
                </TabsTrigger>
              </TabsList>

              {/* Reporting Tab */}
              <TabsContent value="reporting" className="mt-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="p-6 bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-950 dark:to-emerald-900 border-emerald-200 dark:border-emerald-800">
                    <div className="space-y-2">
                      <div className="text-2xl">💰</div>
                      <div className="text-xs font-medium text-muted-foreground uppercase">
                        სულ შემოსავალი
                      </div>
                      <div className="text-2xl font-bold">
                        ₾{upload.total_revenue?.toLocaleString('ka-GE', { maximumFractionDigits: 0 })}
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-950 dark:to-red-900 border-red-200 dark:border-red-800">
                    <div className="space-y-2">
                      <div className="text-2xl">📉</div>
                      <div className="text-xs font-medium text-muted-foreground uppercase">
                        სულ ხარჯები
                      </div>
                      <div className="text-2xl font-bold">
                        ₾{upload.total_expenses?.toLocaleString('ka-GE', { maximumFractionDigits: 0 })}
                      </div>
                    </div>
                  </Card>

                  <Card className="p-6 bg-gradient-to-br from-violet-50 to-violet-100 dark:from-violet-950 dark:to-violet-900 border-violet-200 dark:border-violet-800">
                    <div className="space-y-2">
                      <div className="text-2xl">📈</div>
                      <div className="text-xs font-medium text-muted-foreground uppercase">
                        წმინდა მოგება
                      </div>
                      <div className="text-2xl font-bold">
                        ₾{upload.net_profit?.toLocaleString('ka-GE', { maximumFractionDigits: 0 })}
                      </div>
                    </div>
                  </Card>
                </div>
              </TabsContent>

              {/* Revenue Tab */}
              <TabsContent value="revenue" className="mt-6 space-y-6">
                <RevenueModuleDetail
                  totalRevenue={upload.total_revenue || 0}
                  occupancyRate={upload.occupancy_rate || 0}
                  adr={upload.adr || 0}
                  revpar={upload.revpar || 0}
                  totalNights={upload.total_nights || 0}
                  totalBookings={upload.total_bookings || 0}
                  totalRooms={upload.total_rooms || 0}
                />
              </TabsContent>

              {/* Expenses Tab */}
              <TabsContent value="expenses" className="mt-6 space-y-6">
                <ExpensesModuleDetail
                  totalExpenses={upload.total_expenses || 0}
                  totalRevenue={upload.total_revenue || 0}
                />
              </TabsContent>

              {/* Profit Tab */}
              <TabsContent value="profit" className="mt-6 space-y-6">
                <ProfitModuleDetail
                  netProfit={upload.net_profit || 0}
                  totalRevenue={upload.total_revenue || 0}
                  totalExpenses={upload.total_expenses || 0}
                  profitMargin={upload.profit_margin || 0}
                />
              </TabsContent>
            </Tabs>
          </div>
        ) : (
          <Card className="p-8">
            <div className="text-center">
              <p className="text-muted-foreground">მონაცემები ვერ მოიძებნა</p>
            </div>
          </Card>
        )}
      </main>
    </div>
  );
};

export default FinanceMonthlyAnalysisDetail;
