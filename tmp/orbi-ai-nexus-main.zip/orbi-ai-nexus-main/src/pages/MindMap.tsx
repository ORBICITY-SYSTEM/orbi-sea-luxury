import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, LayoutGrid, ListTree, Calendar } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { TreeView } from "@/components/mind-map/TreeView";
import { KanbanView } from "@/components/mind-map/KanbanView";
import { TimelineView } from "@/components/mind-map/TimelineView";

const MindMap = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [viewMode, setViewMode] = useState<'tree' | 'kanban' | 'timeline'>('tree');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/')}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold">
                  🗺️ {t("AI Director Mind Map", "AI Director Mind Map")}
                </h1>
                <p className="text-sm text-muted-foreground">
                  {t("სისტემური დავალებების ვიზუალიზაცია და მართვა", "System tasks visualization and management")}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as any)} className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-8">
            <TabsTrigger value="tree" className="gap-2">
              <ListTree className="h-4 w-4" />
              {t("იერარქია", "Tree")}
            </TabsTrigger>
            <TabsTrigger value="kanban" className="gap-2">
              <LayoutGrid className="h-4 w-4" />
              {t("Kanban", "Kanban")}
            </TabsTrigger>
            <TabsTrigger value="timeline" className="gap-2">
              <Calendar className="h-4 w-4" />
              {t("Timeline", "Timeline")}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tree" className="mt-0">
            <TreeView />
          </TabsContent>

          <TabsContent value="kanban" className="mt-0">
            <KanbanView />
          </TabsContent>

          <TabsContent value="timeline" className="mt-0">
            <TimelineView />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default MindMap;