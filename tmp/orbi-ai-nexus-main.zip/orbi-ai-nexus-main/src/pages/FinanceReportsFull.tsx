import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Printer } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Skeleton } from "@/components/ui/skeleton";
import { FinanceDateRangePicker } from "@/components/finance/FinanceDateRangePicker";
import { FinanceReportTables } from "@/components/finance/FinanceReportTables";
import { FinanceReportCharts } from "@/components/finance/FinanceReportCharts";

interface DateRange {
  from: Date;
  to: Date;
}

export default function FinanceReportsFull() {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [dateRange, setDateRange] = useState<DateRange>({
    from: new Date('2025-01-01'),
    to: new Date('2025-09-30'),
  });

  const { data: financeData, isLoading } = useQuery({
    queryKey: ['finance-full-report', dateRange],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: records, error: recordsError } = await supabase
        .from('finance_records')
        .select('*')
        .eq('user_id', user.id)
        .gte('date', dateRange.from.toISOString().split('T')[0])
        .lte('date', dateRange.to.toISOString().split('T')[0])
        .order('date', { ascending: true });

      if (recordsError) throw recordsError;

      const { data: expenses, error: expensesError } = await supabase
        .from('expense_records')
        .select('*')
        .eq('user_id', user.id)
        .gte('date', dateRange.from.toISOString().split('T')[0])
        .lte('date', dateRange.to.toISOString().split('T')[0]);

      if (expensesError) throw expensesError;

      return { records: records || [], expenses: expenses || [] };
    },
  });

  const formatCurrency = (amount: number) => {
    return language === 'ka'
      ? `${amount.toLocaleString('ka-GE', { maximumFractionDigits: 2 })} ₾`
      : `€${amount.toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  const records = financeData?.records || [];
  const expenses = financeData?.expenses || [];

  // Calculate summary stats
  const totalRevenue = records.reduce((sum, r) => sum + Number(r.revenue || 0), 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);
  const totalBookings = records.length;
  const totalNights = records.reduce((sum, r) => sum + Number(r.nights || 0), 0);
  const avgADR = totalNights > 0 ? totalRevenue / totalNights : 0;
  
  // Calculate unique rooms
  const uniqueRooms = new Set(records.map(r => r.room_number).filter(Boolean));
  const totalRooms = uniqueRooms.size;

  // Calculate occupancy (simplified)
  const daysInPeriod = Math.ceil((dateRange.to.getTime() - dateRange.from.getTime()) / (1000 * 60 * 60 * 24));
  const possibleNights = totalRooms * daysInPeriod;
  const occupancyRate = possibleNights > 0 ? (totalNights / possibleNights) * 100 : 0;

  const summaryStats = {
    totalRevenue,
    totalExpenses,
    netProfit: totalRevenue - totalExpenses,
    totalBookings,
    totalNights,
    avgADR,
    occupancyRate,
    totalRooms,
  };

  return (
    <div className="min-h-screen bg-background">
      <div id="finance-dashboard" className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/finance')}>
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-bold">
                  {language === 'ka' ? 'შემოსავლები და სტუდიოები - სრული ანალიზი' : 'Revenue & Studios - Full Analysis'}
                </h1>
                <p className="text-muted-foreground">
                  {language === 'ka' ? 'დეტალური ფინანსური რეპორტები და ანალიზი' : 'Detailed financial reports and analysis'}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" onClick={() => window.print()}>
                <Printer className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <FinanceDateRangePicker 
            dateRange={dateRange}
            onDateRangeChange={setDateRange}
          />
        </div>

        {/* Executive Summary */}
        <Card className="border-2 border-primary/20">
          <CardHeader>
            <CardTitle className="text-2xl">
              {language === 'ka' ? '📊 აღმასრულებელი რეზიუმე' : '📊 Executive Summary'}
            </CardTitle>
            <CardDescription>
              {language === 'ka' 
                ? `${dateRange.from.toLocaleDateString('ka-GE')} - ${dateRange.to.toLocaleDateString('ka-GE')}`
                : `${dateRange.from.toLocaleDateString('en-US')} - ${dateRange.to.toLocaleDateString('en-US')}`
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '💰 მთლიანი შემოსავალი' : '💰 Total Revenue'}
                </div>
                <div className="text-2xl font-bold text-primary">{formatCurrency(totalRevenue)}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '🏨 სულ ჯავშნები' : '🏨 Total Bookings'}
                </div>
                <div className="text-2xl font-bold">{totalBookings.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '🌙 სულ ღამეები' : '🌙 Total Nights'}
                </div>
                <div className="text-2xl font-bold">{totalNights.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '📈 საშუალო ADR' : '📈 Average ADR'}
                </div>
                <div className="text-2xl font-bold">{formatCurrency(avgADR)}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '📊 Occupancy' : '📊 Occupancy'}
                </div>
                <div className="text-2xl font-bold">{occupancyRate.toFixed(1)}%</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '🏗️ სტუდიოები' : '🏗️ Studios'}
                </div>
                <div className="text-2xl font-bold">{totalRooms}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '💸 ხარჯები' : '💸 Expenses'}
                </div>
                <div className="text-2xl font-bold text-destructive">{formatCurrency(totalExpenses)}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">
                  {language === 'ka' ? '💵 წმინდა მოგება' : '💵 Net Profit'}
                </div>
                <div className="text-2xl font-bold text-green-600">{formatCurrency(summaryStats.netProfit)}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Charts */}
        <FinanceReportCharts records={records} />

        {/* Tables */}
        <FinanceReportTables records={records} expenses={expenses} />
      </div>
    </div>
  );
}
