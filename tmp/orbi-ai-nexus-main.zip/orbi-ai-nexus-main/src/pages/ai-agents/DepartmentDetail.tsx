import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, ArrowRight, Bot } from "lucide-react";

interface Department {
  id: number;
  name: string;
  slug: string;
  description: string;
}

interface Agent {
  id: number;
  name: string;
  slug: string;
  description: string;
  capabilities: string;
  status: string;
  department_id: number;
}

// Static data (no database tables yet)
const staticDepartments: Department[] = [
  { id: 1, name: "Marketing", slug: "marketing", description: "Marketing and promotional AI agents" },
  { id: 2, name: "Finance", slug: "finance", description: "Financial analysis and reporting agents" },
  { id: 3, name: "Operations", slug: "operations", description: "Operational management agents" },
  { id: 4, name: "Logistics", slug: "logistics", description: "Logistics and inventory agents" },
];

const staticAgents: Agent[] = [
  { id: 1, name: "Marketing Analyst", slug: "marketing-analyst", description: "Analyzes marketing campaigns", capabilities: "Analytics, Reports, Insights", status: "active", department_id: 1 },
  { id: 2, name: "Content Creator", slug: "content-creator", description: "Creates marketing content", capabilities: "Writing, SEO, Social Media", status: "active", department_id: 1 },
  { id: 3, name: "Financial Advisor", slug: "financial-advisor", description: "Provides financial insights", capabilities: "Budgeting, Forecasting, Analysis", status: "active", department_id: 2 },
  { id: 4, name: "Revenue Analyst", slug: "revenue-analyst", description: "Tracks revenue metrics", capabilities: "Revenue, KPIs, Trends", status: "active", department_id: 2 },
  { id: 5, name: "Operations Manager", slug: "operations-manager", description: "Manages daily operations", capabilities: "Scheduling, Planning, Coordination", status: "active", department_id: 3 },
  { id: 6, name: "Inventory Agent", slug: "inventory-agent", description: "Tracks inventory and supplies", capabilities: "Inventory, Stock, Orders", status: "active", department_id: 4 },
];

export default function DepartmentDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const department = staticDepartments.find(d => d.slug === slug) || null;
  const agents = staticAgents.filter(a => a.department_id === department?.id);

  if (!department) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Department not found</h2>
          <Button onClick={() => navigate("/ai-agents")}>Back to Departments</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
                <span className="cursor-pointer hover:text-foreground" onClick={() => navigate("/ai-agents")}>
                  AI Agents
                </span>
                <span>/</span>
                <span>{department.name}</span>
              </div>
              <h1 className="text-2xl font-bold text-foreground">{department.name}</h1>
              <p className="text-sm text-muted-foreground">{department.description}</p>
            </div>
            <Button variant="outline" onClick={() => navigate("/ai-agents")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Departments
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Available AI Agents</h2>
          <p className="text-muted-foreground">Click on an agent to start a conversation and access specialized tools</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2">
          {agents.map((agent) => (
            <Card
              key={agent.id}
              className="group cursor-pointer hover:shadow-xl transition-all duration-300 border-2 hover:border-primary"
              onClick={() => navigate(`/ai-agents/chat/${agent.slug}`)}
            >
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                    <Bot className="w-6 h-6 text-white" />
                  </div>
                  <Badge variant={agent.status === "active" ? "default" : "secondary"}>
                    {agent.status}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{agent.name}</CardTitle>
                <CardDescription className="text-sm">{agent.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-2">CAPABILITIES</p>
                  <div className="flex flex-wrap gap-2">
                    {agent.capabilities?.split(",").slice(0, 3).map((cap, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">
                        {cap.trim()}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Button variant="ghost" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  Start Conversation
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
}
