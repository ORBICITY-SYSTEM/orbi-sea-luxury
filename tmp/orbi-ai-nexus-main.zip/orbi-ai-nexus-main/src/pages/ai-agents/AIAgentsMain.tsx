import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Megaphone, DollarSign, Calendar, Package, ArrowLeft } from "lucide-react";

interface Department {
  id: number;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
}

const iconMap: Record<string, any> = {
  megaphone: Megaphone,
  "dollar-sign": DollarSign,
  calendar: Calendar,
  package: Package,
};

const colorMap: Record<string, string> = {
  blue: "from-blue-500 to-blue-600",
  green: "from-green-500 to-green-600",
  purple: "from-purple-500 to-purple-600",
  orange: "from-orange-500 to-orange-600",
};

// Static departments data (no database table yet)
const staticDepartments: Department[] = [
  {
    id: 1,
    name: "Marketing",
    slug: "marketing",
    description: "Marketing and promotional AI agents",
    icon: "megaphone",
    color: "blue",
  },
  {
    id: 2,
    name: "Finance",
    slug: "finance",
    description: "Financial analysis and reporting agents",
    icon: "dollar-sign",
    color: "green",
  },
  {
    id: 3,
    name: "Operations",
    slug: "operations",
    description: "Operational management agents",
    icon: "calendar",
    color: "purple",
  },
  {
    id: 4,
    name: "Logistics",
    slug: "logistics",
    description: "Logistics and inventory agents",
    icon: "package",
    color: "orange",
  },
];

export default function AIAgentsMain() {
  const [departments] = useState<Department[]>(staticDepartments);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">AI Agent Management System</h1>
              <p className="text-sm text-muted-foreground">Select a department to access specialized AI agents and management tools</p>
            </div>
            <Button variant="outline" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Select Department</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose a department to access specialized AI agents and management tools
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 max-w-5xl mx-auto">
          {departments.map((dept) => {
            const Icon = iconMap[dept.icon] || Package;
            const gradient = colorMap[dept.color] || "from-gray-500 to-gray-600";

            return (
              <Card
                key={dept.id}
                className="group cursor-pointer hover:shadow-xl transition-all duration-300 border-2 hover:border-primary"
                onClick={() => navigate(`/ai-agents/departments/${dept.slug}`)}
              >
                <CardHeader>
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center mb-4`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl">{dept.name}</CardTitle>
                  <CardDescription className="text-base">{dept.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="ghost" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    View Agents
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
}
