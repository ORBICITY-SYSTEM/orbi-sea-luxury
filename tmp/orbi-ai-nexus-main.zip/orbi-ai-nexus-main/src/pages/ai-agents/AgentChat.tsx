import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Send, Bot, User, Loader2, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Agent {
  id: number;
  name: string;
  slug: string;
  description: string;
  system_prompt: string;
  capabilities: string;
  department_id: number;
}

interface Message {
  id: number;
  role: string;
  content: string;
  created_at: string;
}

// Static agents data
const staticAgents: Agent[] = [
  { id: 1, name: "Marketing Analyst", slug: "marketing-analyst", description: "Analyzes marketing campaigns", system_prompt: "You are a marketing analyst for Orbi City aparthotel.", capabilities: "Analytics, Reports, Insights", department_id: 1 },
  { id: 2, name: "Content Creator", slug: "content-creator", description: "Creates marketing content", system_prompt: "You are a content creator for Orbi City aparthotel.", capabilities: "Writing, SEO, Social Media", department_id: 1 },
  { id: 3, name: "Financial Advisor", slug: "financial-advisor", description: "Provides financial insights", system_prompt: "You are a financial advisor for Orbi City aparthotel.", capabilities: "Budgeting, Forecasting, Analysis", department_id: 2 },
  { id: 4, name: "Revenue Analyst", slug: "revenue-analyst", description: "Tracks revenue metrics", system_prompt: "You are a revenue analyst for Orbi City aparthotel.", capabilities: "Revenue, KPIs, Trends", department_id: 2 },
  { id: 5, name: "Operations Manager", slug: "operations-manager", description: "Manages daily operations", system_prompt: "You are an operations manager for Orbi City aparthotel.", capabilities: "Scheduling, Planning, Coordination", department_id: 3 },
  { id: 6, name: "Inventory Agent", slug: "inventory-agent", description: "Tracks inventory and supplies", system_prompt: "You are an inventory management agent for Orbi City aparthotel.", capabilities: "Inventory, Stock, Orders", department_id: 4 },
];

export default function AgentChat() {
  const { slug } = useParams<{ slug: string }>();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);

  const agent = staticAgents.find(a => a.slug === slug) || null;

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const sendMessage = async () => {
    if (!input.trim() || !agent || sending) return;

    const userMessage = input.trim();
    setInput("");
    setSending(true);

    const userMsg: Message = {
      id: Date.now(),
      role: "user",
      content: userMessage,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, userMsg]);

    try {
      // Simple mock response for now (no database)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const aiResponse = `Thank you for your message. As the ${agent.name}, I'm here to help with ${agent.capabilities.toLowerCase()}. This is a demo response - full AI integration coming soon!`;

      const aiMsg: Message = {
        id: Date.now() + 1,
        role: "assistant",
        content: aiResponse,
        created_at: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setTimeout(scrollToBottom, 100);
    } catch (error: any) {
      toast({
        title: "Error sending message",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSending(false);
    }
  };

  if (!agent) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Agent not found</h2>
          <Button onClick={() => navigate("/ai-agents")}>Back to Agents</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">{agent.name}</h1>
                <p className="text-sm text-muted-foreground">{agent.description}</p>
              </div>
            </div>
            <Button variant="outline" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div className="flex-1 container mx-auto px-6 py-6 flex gap-6">
        {/* Main Chat */}
        <div className="flex-1 flex flex-col">
          <Card className="flex-1 flex flex-col">
            <CardHeader>
              <CardTitle>Conversation</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <ScrollArea className="flex-1 pr-4 mb-4">
                <div className="space-y-4">
                  {messages.length === 0 && (
                    <div className="text-center py-12">
                      <Bot className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground">Start a conversation with {agent.name}</p>
                    </div>
                  )}
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                    >
                      {msg.role === "assistant" && (
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                          <Bot className="w-4 h-4 text-white" />
                        </div>
                      )}
                      <div
                        className={`max-w-[70%] rounded-lg p-4 ${
                          msg.role === "user"
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted"
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        <p className="text-xs opacity-70 mt-2">
                          {new Date(msg.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                      {msg.role === "user" && (
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                          <User className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                  ))}
                  <div ref={scrollRef} />
                </div>
              </ScrollArea>

              {/* Input Area */}
              <div className="flex gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  placeholder="Type your message... (Press Enter to send, Shift+Enter for new line)"
                  className="min-h-[60px] resize-none"
                  disabled={sending}
                />
                <Button onClick={sendMessage} disabled={sending || !input.trim()} size="lg">
                  {sending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="w-80 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Agent Capabilities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {agent.capabilities?.split(",").map((cap, idx) => (
                  <Badge key={idx} variant="secondary" className="text-xs">
                    {cap.trim()}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Upload File
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
