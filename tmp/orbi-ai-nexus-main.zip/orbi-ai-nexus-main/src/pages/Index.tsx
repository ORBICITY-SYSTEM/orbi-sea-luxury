import { useState, useEffect } from "react";
import { AIDirectorStatus } from "@/components/AIDirectorStatus";
import { AIDirectorChat } from "@/components/AIDirectorChat";
import { OrbiLogistics } from "@/components/OrbiLogistics";
import { UserProfile } from "@/components/UserProfile";
import { OthersModulesSection } from "@/components/OthersModulesSection";
import { Building2, LogOut, Brain } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageToggle } from "@/components/LanguageToggle";

const Index = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { t } = useLanguage();
  const [userRole, setUserRole] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserRole = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);

      // Set user role - prioritize admin, then other specific roles
      if (roles && roles.length > 0) {
        const roleNames = roles.map(r => r.role);
        if (roleNames.includes('admin')) {
          setUserRole('admin');
        } else if (roleNames.includes('manager')) {
          setUserRole('manager');
        } else if (roleNames.includes('finance')) {
          setUserRole('finance');
        } else if (roleNames.includes('marketing')) {
          setUserRole('marketing');
        } else if (roleNames.includes('logistics')) {
          setUserRole('logistics');
        } else if (roleNames.includes('customer_service')) {
          setUserRole('customer_service');
        } else {
          setUserRole('user');
        }
      }
    };

    fetchUserRole();
  }, []);

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "გამოხვედით სისტემიდან",
        description: "თქვენ წარმატებით გამოხვედით.",
      });
      navigate("/auth");
    } catch (error: any) {
      toast({
        title: "შეცდომა",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-ai">
                <Building2 className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Orbi City AI Core</h1>
                <p className="text-xs text-muted-foreground">Batumi, Georgia</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <LanguageToggle />
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                {t("გასვლა", "Logout")}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        {/* Rooms & Housekeeping - Main Module */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-4">
            {t("ოთახები და დასუფთავება", "Rooms & Housekeeping")}
          </h2>
        </div>
        <div className="mb-8">
          <OrbiLogistics />
        </div>

        {/* OTHERS - Password Protected Section */}
        <div className="mt-12">
          <OthersModulesSection userRole={userRole} />
        </div>


        {/* User Profile */}
        <div className="mt-8">
          <UserProfile />
        </div>

        {/* AI Director Status */}
        <div className="mt-8">
          <AIDirectorStatus />
        </div>
      </main>

      {/* AI Director Chat */}
      <AIDirectorChat />
    </div>
  );
};

export default Index;
