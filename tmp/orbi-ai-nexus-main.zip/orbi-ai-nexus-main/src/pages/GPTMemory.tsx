import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Database, ArrowLeft, BarChart3, FileText, FolderTree, Search, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { KnowledgeUpload } from "@/components/KnowledgeUpload";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const GPTMemory = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const { data: documents } = useQuery({
    queryKey: ['gpt-memory-documents'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('gpt_memory_documents')
        .select('*')
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: stats } = useQuery({
    queryKey: ['gpt-memory-stats'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return { documents: 0, categories: 0 };

      const { data: docs } = await supabase
        .from('gpt_memory_documents')
        .select('category')
        .eq('user_id', user.id);

      const uniqueCategories = new Set(docs?.map(d => d.category).filter(Boolean));
      
      return {
        documents: docs?.length || 0,
        categories: uniqueCategories.size,
      };
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              {t("უკან", "Back")}
            </Button>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-info/20 to-info/10">
                <Database className="h-6 w-6 text-info" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  GPT Memory Archive
                </h1>
                <p className="text-xs text-muted-foreground">
                  {t("ცოდნის საცავი AI-ით", "AI-powered knowledge base")}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-8">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              {t("დეშბორდი", "Dashboard")}
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              {t("დოკუმენტები", "Documents")}
            </TabsTrigger>
            <TabsTrigger value="topics" className="flex items-center gap-2">
              <FolderTree className="h-4 w-4" />
              {t("თემები", "Topics")}
            </TabsTrigger>
            <TabsTrigger value="search" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              {t("ძიება", "Search")}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <div className="grid gap-4 md:grid-cols-2 mb-6">
              <Card className="p-6">
                <p className="text-sm text-muted-foreground mb-1">{t("დოკუმენტები", "Documents")}</p>
                <p className="text-3xl font-bold">{stats?.documents || 0}</p>
              </Card>
              <Card className="p-6">
                <p className="text-sm text-muted-foreground mb-1">{t("კატეგორიები", "Categories")}</p>
                <p className="text-3xl font-bold">{stats?.categories || 0}</p>
              </Card>
            </div>
            <KnowledgeUpload />
          </TabsContent>

          <TabsContent value="documents">
            <div className="space-y-4">
              <KnowledgeUpload />
              
              <div className="grid gap-4 mt-6">
                {documents?.map((doc) => (
                  <Card key={doc.id} className="p-6">
                    <div className="space-y-4">
                      {/* Header */}
                      <div className="flex items-start justify-between border-b pb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-lg font-bold">{doc.title}</h3>
                            {doc.category && (
                              <span className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium">
                                {doc.category}
                              </span>
                            )}
                          </div>
                          {doc.file_name && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <FileText className="h-3 w-3" />
                              {doc.file_name}
                            </p>
                          )}
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(doc.created_at).toLocaleDateString('ka-GE')}
                        </span>
                      </div>

                      {/* Content Summary */}
                      <div>
                        <h4 className="text-sm font-semibold mb-2">
                          {t("შინაარსი", "Content")}
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {doc.content}
                        </p>
                      </div>

                      {/* AI Analysis */}
                      {doc.ai_analysis && (
                        <div className="border-t pt-4 space-y-4">
                          <div className="flex items-center gap-2">
                            <Sparkles className="h-4 w-4 text-primary" />
                            <h4 className="font-semibold text-primary">
                              {t("AI Director-ის ანალიზი", "AI Director Analysis")}
                            </h4>
                          </div>

                          {(() => {
                            const analysis = doc.ai_analysis as {
                              pros?: string[];
                              cons?: string[];
                              recommendations?: string[];
                              quick_tips?: string[];
                            };

                            return (
                              <>
                                {/* Pros */}
                                {analysis.pros && analysis.pros.length > 0 && (
                                  <div className="space-y-2">
                                    <h5 className="text-sm font-semibold text-success">
                                      ✅ {t("რა მოსწონს", "What's Good")}
                                    </h5>
                                    <ul className="space-y-1">
                                      {analysis.pros.map((pro, idx) => (
                                        <li key={idx} className="text-sm text-muted-foreground pl-4">
                                          • {pro}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                {/* Cons */}
                                {analysis.cons && analysis.cons.length > 0 && (
                                  <div className="space-y-2">
                                    <h5 className="text-sm font-semibold text-warning">
                                      ⚠️ {t("რა არ მოსწონს", "Issues")}
                                    </h5>
                                    <ul className="space-y-1">
                                      {analysis.cons.map((con, idx) => (
                                        <li key={idx} className="text-sm text-muted-foreground pl-4">
                                          • {con}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                {/* Recommendations */}
                                {analysis.recommendations && analysis.recommendations.length > 0 && (
                                  <div className="space-y-2">
                                    <h5 className="text-sm font-semibold text-info">
                                      💡 {t("რეკომენდაციები", "Recommendations")}
                                    </h5>
                                    <ul className="space-y-1">
                                      {analysis.recommendations.map((rec, idx) => (
                                        <li key={idx} className="text-sm text-muted-foreground pl-4">
                                          • {rec}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}

                                {/* Quick Tips */}
                                {analysis.quick_tips && analysis.quick_tips.length > 0 && (
                                  <div className="space-y-2 bg-primary/5 p-3 rounded-lg">
                                    <h5 className="text-sm font-semibold">
                                      ⚡ {t("სწრაფი Tips", "Quick Tips")}
                                    </h5>
                                    <ul className="space-y-1">
                                      {analysis.quick_tips.map((tip, idx) => (
                                        <li key={idx} className="text-sm text-muted-foreground pl-4">
                                          • {tip}
                                        </li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </>
                            );
                          })()}
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
                
                {!documents || documents.length === 0 ? (
                  <Card className="p-8 text-center">
                    <p className="text-muted-foreground">
                      {t("ჯერ არ არის დამატებული დოკუმენტები", "No documents added yet")}
                    </p>
                  </Card>
                ) : null}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="topics">
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">
                {t("თემების მოდული განვითარების პროცესშია", "Topics module under development")}
              </p>
            </Card>
          </TabsContent>

          <TabsContent value="search">
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">
                {t("ძიების მოდული განვითარების პროცესშია", "Search module under development")}
              </p>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default GPTMemory;
