import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Copy, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const RoleManagement = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [copiedLink, setCopiedLink] = useState(false);

  const logisticsLink = `${window.location.origin}/logistics`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(logisticsLink);
    setCopiedLink(true);
    toast({
      title: "ლინკი დაკოპირებულია",
      description: "ლინკი დაკოპირდა ბუფერში",
    });
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              უკან
            </Button>
            <div>
              <h1 className="text-xl font-bold text-foreground">როლების მართვა</h1>
              <p className="text-xs text-muted-foreground">
                მომხმარებლების როლების და წვდომების კონფიგურაცია
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8 max-w-4xl">
        <Card>
          <CardHeader>
            <CardTitle>ლოჯისტიკის მოდულზე წვდომა</CardTitle>
            <CardDescription>
              ეს მოდული ხელმისაწვდომია მხოლოდ "manager" და "logistics" როლების მქონე მომხმარებლებისთვის
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Link Section */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">მოდულის ლინკი</h3>
              <div className="flex gap-2">
                <div className="flex-1 p-3 bg-muted rounded-md font-mono text-sm break-all">
                  {logisticsLink}
                </div>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={copyToClipboard}
                  className="shrink-0"
                >
                  {copiedLink ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {/* Instructions */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">როგორ მივანიჭოთ როლი მომხმარებელს:</h3>
              
              <div className="space-y-3 text-sm text-muted-foreground">
                <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                  <p className="font-medium text-foreground">1. გახსენით Backend (Lovable Cloud)</p>
                  <p>დაწკაპეთ Settings → Backend Management ან გამოიყენეთ შემდეგი ბმული:</p>
                  <p className="font-mono text-xs bg-background p-2 rounded">
                    Table Editor → user_roles
                  </p>
                </div>

                <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                  <p className="font-medium text-foreground">2. დაამატეთ ახალი ჩანაწერი</p>
                  <p>Insert Row ღილაკზე დაჭერით შეავსეთ:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li><code>user_id</code>: მომხმარებლის UUID (profiles ცხრილიდან)</li>
                    <li><code>role</code>: აირჩიეთ "manager" ან "logistics"</li>
                  </ul>
                </div>

                <div className="p-4 bg-muted/50 rounded-lg space-y-2">
                  <p className="font-medium text-foreground">3. შეინახეთ ცვლილებები</p>
                  <p>Save ღილაკზე დაჭერა და მომხმარებელს ექნება წვდომა ლოჯისტიკის მოდულზე</p>
                </div>
              </div>
            </div>

            {/* Available Roles */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">ხელმისაწვდომი როლები:</h3>
              <div className="grid gap-3">
                <div className="p-3 border border-border rounded-lg">
                  <p className="font-medium text-sm">manager</p>
                  <p className="text-xs text-muted-foreground">
                    სრული წვდომა ლოჯისტიკის მოდულზე - ინვენტარი, დასუფთავება, მოვლა-შენახვა
                  </p>
                </div>
                <div className="p-3 border border-border rounded-lg">
                  <p className="font-medium text-sm">logistics</p>
                  <p className="text-xs text-muted-foreground">
                    სრული წვდომა ლოჯისტიკის მოდულზე - ინვენტარი, დასუფთავება, მოვლა-შენახვა
                  </p>
                </div>
              </div>
            </div>

            {/* SQL Query Helper */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold">სწრაფი SQL Query (ოფციონალური):</h3>
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-xs text-muted-foreground mb-2">
                  მონაცემთა ბაზის SQL Editor-ში შეგიძლიათ გამოიყენოთ:
                </p>
                <pre className="text-xs bg-background p-3 rounded overflow-x-auto">
{`-- ნახეთ ყველა მომხმარებლის email და ID
SELECT id, email FROM auth.users;

-- დაამატეთ manager როლი
INSERT INTO user_roles (user_id, role)
VALUES ('user-id-here', 'manager');

-- დაამატეთ logistics როლი
INSERT INTO user_roles (user_id, role)
VALUES ('user-id-here', 'logistics');`}
                </pre>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <Button onClick={() => navigate("/logistics")} className="w-full">
                გახსენით ლოჯისტიკის მოდული
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default RoleManagement;
