import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Marketing from "./pages/Marketing";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";
import Finance from "./pages/Finance";
import FinanceAnalytics from "./pages/FinanceAnalytics";
import FinanceOtelMS from "./pages/FinanceOtelMS";
import FinanceMonthlyAnalysis from "./pages/FinanceMonthlyAnalysis";
import FinanceMonthlyAnalysisDetail from "./pages/FinanceMonthlyAnalysisDetail";
import FinanceDevelopmentExpenses from "./pages/FinanceDevelopmentExpenses";
import DevExpensesDashboard from "./pages/development-expenses/DevExpensesDashboard";
import DevExpensesUpload from "./pages/development-expenses/DevExpensesUpload";
import DevExpensesAnalytics from "./pages/development-expenses/DevExpensesAnalytics";
import DevExpensesForecast from "./pages/development-expenses/DevExpensesForecast";
import DevExpensesInvestments from "./pages/development-expenses/DevExpensesInvestments";
import FinanceReportsFull from "./pages/FinanceReportsFull";
import Logistics from "./pages/Logistics";
import Housekeeping from "./pages/Housekeeping";
import GuestCommunication from "./pages/GuestCommunication";
import WebsiteLeads from "./pages/WebsiteLeads";
import GPTMemory from "./pages/GPTMemory";
import MindMap from "./pages/MindMap";
import GoogleCallback from "./pages/GoogleCallback";
import APIIntegrations from "./pages/APIIntegrations";
import UserApproval from "./pages/UserApproval";
import OTADashboard from "./pages/OTADashboard";
import OTAAgents from "./pages/OTAAgents";
import AIAgentsMain from "./pages/ai-agents/AIAgentsMain";
import DepartmentDetail from "./pages/ai-agents/DepartmentDetail";
import AgentChat from "./pages/ai-agents/AgentChat";
import EmailManagement from "./pages/EmailManagement";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { RoleProtectedRoute } from "@/components/RoleProtectedRoute";
import { FinanceAnalysisProvider } from "@/contexts/FinanceAnalysisContext";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/auth" element={<Auth />} />
          <Route path="/" element={<ProtectedRoute><Index /></ProtectedRoute>} />
          
          {/* Public role-based access routes */}
          <Route path="/finances" element={<Finance />} />
          <Route path="/marketing" element={<Marketing />} />
          <Route path="/logistics" element={<Logistics />} />
          <Route path="/customer-service" element={<GuestCommunication />} />
          
          {/* Protected routes (legacy/authenticated access) */}
          <Route path="/finance" element={<ProtectedRoute><Finance /></ProtectedRoute>} />
          <Route path="/finance/analytics" element={<ProtectedRoute><FinanceAnalysisProvider><FinanceAnalytics /></FinanceAnalysisProvider></ProtectedRoute>} />
          <Route path="/finance/otelms" element={<ProtectedRoute><FinanceOtelMS /></ProtectedRoute>} />
          <Route path="/finance/monthly-analysis" element={<ProtectedRoute><FinanceMonthlyAnalysis /></ProtectedRoute>} />
          <Route path="/finance/monthly-analysis/:year/:month" element={<ProtectedRoute><FinanceMonthlyAnalysisDetail /></ProtectedRoute>} />
          <Route path="/finance/development-expenses" element={<ProtectedRoute><FinanceDevelopmentExpenses /></ProtectedRoute>} />
          <Route path="/finance/development-expenses/dashboard" element={<ProtectedRoute><DevExpensesDashboard /></ProtectedRoute>} />
          <Route path="/finance/development-expenses/upload" element={<ProtectedRoute><DevExpensesUpload /></ProtectedRoute>} />
          <Route path="/finance/development-expenses/analytics" element={<ProtectedRoute><DevExpensesAnalytics /></ProtectedRoute>} />
          <Route path="/finance/development-expenses/forecast" element={<ProtectedRoute><DevExpensesForecast /></ProtectedRoute>} />
          <Route path="/finance/development-expenses/investments" element={<ProtectedRoute><DevExpensesInvestments /></ProtectedRoute>} />
          <Route path="/finance/reports" element={<ProtectedRoute><FinanceReportsFull /></ProtectedRoute>} />
          <Route path="/housekeeping" element={<ProtectedRoute><RoleProtectedRoute allowedRoles={['manager', 'logistics']}><Housekeeping /></RoleProtectedRoute></ProtectedRoute>} />
          <Route path="/guest-communication" element={<ProtectedRoute><GuestCommunication /></ProtectedRoute>} />
          <Route path="/website-leads" element={<ProtectedRoute><WebsiteLeads /></ProtectedRoute>} />
          <Route path="/gpt-memory" element={<ProtectedRoute><GPTMemory /></ProtectedRoute>} />
          <Route path="/mind-map" element={<ProtectedRoute><MindMap /></ProtectedRoute>} />
          <Route path="/api-integrations" element={<ProtectedRoute><APIIntegrations /></ProtectedRoute>} />
          <Route path="/user-approval" element={<ProtectedRoute><UserApproval /></ProtectedRoute>} />
          <Route path="/google-callback" element={<GoogleCallback />} />
          <Route path="/ota-dashboard" element={<ProtectedRoute><OTADashboard /></ProtectedRoute>} />
          <Route path="/ota-agents" element={<ProtectedRoute><OTAAgents /></ProtectedRoute>} />
          <Route path="/ai-agents" element={<ProtectedRoute><AIAgentsMain /></ProtectedRoute>} />
          <Route path="/ai-agents/departments/:slug" element={<ProtectedRoute><DepartmentDetail /></ProtectedRoute>} />
          <Route path="/ai-agents/chat/:slug" element={<ProtectedRoute><AgentChat /></ProtectedRoute>} />
          <Route path="/email-management" element={<ProtectedRoute><EmailManagement /></ProtectedRoute>} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
