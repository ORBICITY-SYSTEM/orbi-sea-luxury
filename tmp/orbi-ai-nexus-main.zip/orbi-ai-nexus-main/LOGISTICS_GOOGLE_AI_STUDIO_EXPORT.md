# 🏨 Orbi City - Logistics Module Complete Export
## For Google AI Studio / Flash UI Replication

> **დანიშნულება:** ეს ფაილი შეიცავს სრულ კოდს, DB სქემას, კონსტანტებს და React კომპონენტებს, რომ Google AI Studio-მ ან Flash UI-მ შეძლოს ამ მოდულის რეპლიკაცია.

---

## 📊 1. DATABASE SCHEMA (Supabase/PostgreSQL)

```sql
-- ========================================
-- ORBI CITY LOGISTICS DATABASE SCHEMA
-- ========================================

-- 🏠 ROOMS TABLE (ოთახების ცხრილი)
-- ინახავს ყველა ოთახს/სტუდიოს
CREATE TABLE public.rooms (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  room_number TEXT NOT NULL,              -- მაგ: "A 1033", "B 2044"
  user_id UUID REFERENCES auth.users,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- 📦 STANDARD INVENTORY ITEMS (სტანდარტული ინვენტარის ნივთები)
-- განსაზღვრავს რა ნივთები უნდა იყოს ოთახში
CREATE TABLE public.standard_inventory_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,                 -- მაგ: "სამზარეულო", "აბაზანა", "ძირითადი ავეჯი"
  item_name TEXT NOT NULL,                -- მაგ: "თეფში დიდი", "ქვაბი პატარა"
  standard_quantity INTEGER NOT NULL,     -- რამდენი უნდა იყოს სტანდარტულად
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- 🔗 ROOM INVENTORY ITEMS (ოთახის ინვენტარის ხიდი-ცხრილი)
-- აკავშირებს ოთახს სტანდარტულ ნივთებთან
CREATE TABLE public.room_inventory_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.rooms(id),
  standard_item_id UUID NOT NULL REFERENCES public.standard_inventory_items(id),
  actual_quantity INTEGER DEFAULT 0,      -- რეალური რაოდენობა ოთახში
  condition TEXT DEFAULT 'OK',            -- OK, Missing, To Replace
  notes TEXT,                             -- დამატებითი შენიშვნები
  last_checked TIMESTAMPTZ DEFAULT now(),
  issue_detected_at TIMESTAMPTZ,          -- როდის აღმოჩნდა პრობლემა
  issue_resolved_at TIMESTAMPTZ,          -- როდის მოგვარდა
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- 🧹 HOUSEKEEPING SCHEDULES (დასუფთავების გრაფიკი)
CREATE TABLE public.housekeeping_schedules (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users,
  scheduled_date DATE NOT NULL,
  rooms TEXT[] NOT NULL,                  -- ["A 1033", "B 2044"] - ოთახების მასივი
  total_rooms INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',          -- pending, completed, in_progress
  notes TEXT,
  additional_notes TEXT,
  media_urls TEXT[] DEFAULT '{}',         -- ფოტოების URL-ები
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- 🔧 MAINTENANCE SCHEDULES (ტექნიკური შეკეთების გრაფიკი)
CREATE TABLE public.maintenance_schedules (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users,
  room_number TEXT NOT NULL,              -- ოთახის ნომერი
  problem TEXT NOT NULL,                  -- პრობლემის აღწერა
  scheduled_date DATE NOT NULL,           -- დაგეგმვის თარიღი
  solving_date DATE,                      -- გადაჭრის თარიღი
  cost NUMERIC DEFAULT 0,                 -- ხარჯი
  status TEXT DEFAULT 'pending',          -- pending, in_progress, completed
  notes TEXT,
  additional_notes TEXT,
  media_urls TEXT[] DEFAULT '{}',
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- 📋 ROOM INVENTORY DESCRIPTIONS (ინვენტარის ცვლილებების ისტორია)
CREATE TABLE public.room_inventory_descriptions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.rooms(id),
  user_id UUID REFERENCES auth.users,
  description_date TIMESTAMPTZ DEFAULT now(),
  change_type TEXT,                       -- რა ტიპის ცვლილება: "რაოდენობის შეცვლა", "გადატანა"
  items_missing TEXT,                     -- რა აკლია
  items_added TEXT,                       -- რა დაემატა
  items_removed TEXT,                     -- რა წაიღეს
  transfer_from_room TEXT,                -- საიდან გადმოვიდა
  transfer_to_room TEXT,                  -- სად გადავიდა
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- 📝 LOGISTICS ACTIVITY LOG (აქტივობის ჟურნალი)
CREATE TABLE public.logistics_activity_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users,
  user_email TEXT,
  action TEXT NOT NULL,                   -- create, update, delete
  entity_type TEXT NOT NULL,              -- room, inventory_item, housekeeping_schedule
  entity_id UUID,
  entity_name TEXT,
  changes JSONB,                          -- რა შეიცვალა
  created_at TIMESTAMPTZ DEFAULT now() NOT NULL
);

-- ========================================
-- INDEXES (ინდექსები სწრაფი ძიებისთვის)
-- ========================================
CREATE INDEX idx_rooms_number ON public.rooms(room_number);
CREATE INDEX idx_room_inventory_room ON public.room_inventory_items(room_id);
CREATE INDEX idx_housekeeping_date ON public.housekeeping_schedules(scheduled_date);
CREATE INDEX idx_maintenance_room ON public.maintenance_schedules(room_number);
CREATE INDEX idx_activity_log_date ON public.logistics_activity_log(created_at);

-- ========================================
-- RLS POLICIES (Row Level Security)
-- ========================================
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.standard_inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.housekeeping_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maintenance_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.logistics_activity_log ENABLE ROW LEVEL SECURITY;

-- მაგალითი: ყველას შეუძლია ნახვა (Public read)
CREATE POLICY "Anyone can view all rooms" ON public.rooms FOR SELECT USING (true);
CREATE POLICY "Anyone can view all housekeeping" ON public.housekeeping_schedules FOR SELECT USING (true);
```

---

## 🗄️ 2. SAMPLE DATA / სატესტო მონაცემები

```sql
-- ========================================
-- SAMPLE ROOMS (56 ოთახი)
-- ========================================
INSERT INTO public.rooms (room_number) VALUES
  ('A 1033'), ('A 1034'), ('A 1035'), ('A 1036'),
  ('A 1122'), ('A 1123'), ('A 1124'), ('A 1125'),
  ('A 1222'), ('A 1223'), ('A 1224'), ('A 1225'),
  ('A 1322'), ('A 1323'), ('A 1324'), ('A 1325'),
  ('A 1422'), ('A 1423'), ('A 1424'), ('A 1425'),
  ('A 1522'), ('A 1523'), ('A 1524'), ('A 1525'),
  ('A 1622'), ('A 1623'), ('A 1624'), ('A 1625'),
  ('B 2033'), ('B 2034'), ('B 2035'), ('B 2036'),
  ('B 2122'), ('B 2123'), ('B 2124'), ('B 2125'),
  ('B 2222'), ('B 2223'), ('B 2224'), ('B 2225'),
  ('B 2322'), ('B 2323'), ('B 2324'), ('B 2325'),
  ('B 2422'), ('B 2423'), ('B 2424'), ('B 2425'),
  ('B 2522'), ('B 2523'), ('B 2524'), ('B 2525'),
  ('B 2622'), ('B 2623'), ('B 2624'), ('B 2625');

-- ========================================
-- STANDARD INVENTORY ITEMS (სტანდარტული ნივთები)
-- ========================================

-- 🍳 სამზარეულო / Kitchen
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
  ('სამზარეულო', 'თეფში დიდი', 4),
  ('სამზარეულო', 'თეფში პატარა', 4),
  ('სამზარეულო', 'თეფში წვნიანი', 4),
  ('სამზარეულო', 'ფინჯანი', 4),
  ('სამზარეულო', 'ფინჯნის ლამბაქი', 4),
  ('სამზარეულო', 'ჭიქა წყლის', 4),
  ('სამზარეულო', 'ჭიქა ღვინის', 4),
  ('სამზარეულო', 'ჩანგალი', 4),
  ('სამზარეულო', 'კოვზი პატარა', 4),
  ('სამზარეულო', 'კოვზი დიდი', 4),
  ('სამზარეულო', 'დანა', 4),
  ('სამზარეულო', 'ქვაბი დიდი', 1),
  ('სამზარეულო', 'ქვაბი პატარა', 1),
  ('სამზარეულო', 'ტაფა დიდი', 1),
  ('სამზარეულო', 'ტაფა პატარა', 1),
  ('სამზარეულო', 'ჩაიდანი', 1),
  ('სამზარეულო', 'სასქესი', 1),
  ('სამზარეულო', 'საწური', 1),
  ('სამზარეულო', 'ჯამი დიდი', 1),
  ('სამზარეულო', 'ჯამი პატარა', 1),
  ('სამზარეულო', 'საჭრელი დაფა', 1),
  ('სამზარეულო', 'სამზარეულოს დანა', 1),
  ('სამზარეულო', 'გასაღები (საცობის)', 1),
  ('სამზარეულო', 'ნაგვის ურნა', 1),
  ('სამზარეულო', 'ხელსახოცის სადგამი', 1);

-- 🚿 აბაზანა / Bathroom
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
  ('აბაზანა', 'პირსახოცი დიდი', 2),
  ('აბაზანა', 'პირსახოცი პატარა', 2),
  ('აბაზანა', 'აბაზანის ხალიჩა', 1),
  ('აბაზანა', 'შამპუნის დისპენსერი', 1),
  ('აბაზანა', 'საპნის დისპენსერი', 1),
  ('აბაზანა', 'უნიტაზის ჯაგრისი', 1),
  ('აბაზანა', 'ნაგვის ურნა აბაზანის', 1),
  ('აბაზანა', 'სარკე', 1),
  ('აბაზანა', 'ფენი', 1),
  ('აბაზანა', 'შავერის ფარდა', 1);

-- 🛋️ ძირითადი ავეჯი / Main Furniture
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
  ('ძირითადი ავეჯი', 'კარადა სარკით', 1),
  ('ძირითადი ავეჯი', 'საწოლი დიდი', 1),
  ('ძირითადი ავეჯი', 'ტუმბო საწოლთან', 2),
  ('ძირითადი ავეჯი', 'სავარძელი', 1),
  ('ძირითადი ავეჯი', 'მაგიდა ჯურნალის', 1),
  ('ძირითადი ავეჯი', 'სკამი სასადილო', 4),
  ('ძირითადი ავეჯი', 'მაგიდა სასადილო', 1),
  ('ძირითადი ავეჯი', 'აივნის სკამი', 2),
  ('ძირითადი ავეჯი', 'აივნის მაგიდა', 1);

-- 🛏️ საწოლის თეთრეული / Bedding
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
  ('საწოლის თეთრეული', 'თეთრეულის კომპლექტი', 2),
  ('საწოლის თეთრეული', 'ბალიში', 4),
  ('საწოლის თეთრეული', 'საბანი', 2),
  ('საწოლის თეთრეული', 'ლეიბი', 1),
  ('საწოლის თეთრეული', 'მატრასის ბალიში', 1);

-- 📺 ტექნიკა / Electronics
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
  ('ტექნიკა', 'ტელევიზორი', 1),
  ('ტექნიკა', 'ტელევიზორის პულტი', 1),
  ('ტექნიკა', 'კონდიციონერის პულტი', 1),
  ('ტექნიკა', 'უთო', 1),
  ('ტექნიკა', 'უთოს დაფა', 1),
  ('ტექნიკა', 'მტვერსასრუტი', 1),
  ('ტექნიკა', 'მაცივარი', 1),
  ('ტექნიკა', 'მიქსერი', 1),
  ('ტექნიკა', 'ტოსტერი', 1),
  ('ტექნიკა', 'ფენი', 1);

-- 💡 განათება და სხვა / Lighting & Misc
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
  ('განათება', 'ნათურა', 8),
  ('განათება', 'საწოლის ლამპა', 2),
  ('განათება', 'ჭერის სანათი', 1);

-- ========================================
-- SAMPLE HOUSEKEEPING SCHEDULES
-- ========================================
INSERT INTO public.housekeeping_schedules 
  (scheduled_date, rooms, total_rooms, status, notes) 
VALUES
  (CURRENT_DATE, ARRAY['A 1033', 'A 1034', 'A 1035'], 3, 'pending', 'რეგულარული დასუფთავება'),
  (CURRENT_DATE - INTERVAL '1 day', ARRAY['B 2033', 'B 2034'], 2, 'completed', 'დასრულდა დროულად'),
  (CURRENT_DATE + INTERVAL '1 day', ARRAY['A 1122', 'A 1123', 'A 1124', 'A 1125'], 4, 'pending', 'Check-out დასუფთავება');

-- ========================================
-- SAMPLE MAINTENANCE SCHEDULES
-- ========================================
INSERT INTO public.maintenance_schedules 
  (room_number, problem, scheduled_date, status, cost, notes) 
VALUES
  ('A 1033', 'კონდიციონერი არ მუშაობს - ფრეონის დამატება', CURRENT_DATE, 'pending', 150, 'მასტერი გამოიძახეთ'),
  ('B 2044', 'საკეტი დაზიანდა - კარი არ იკეტება', CURRENT_DATE - INTERVAL '2 days', 'completed', 80, 'შეცვალა'),
  ('A 1225', 'წყალი ჟონავს აბაზანაში', CURRENT_DATE, 'in_progress', 120, 'სანტექნიკი მუშაობს'),
  ('B 2122', 'ტელევიზორი არ ირთვება', CURRENT_DATE + INTERVAL '1 day', 'pending', 0, 'შესამოწმებელია');
```

---

## 🎨 3. CONSTANTS / კონსტანტები (TypeScript)

```typescript
// constants/logistics.ts

// ოთახების სია
export const ROOM_BLOCKS = {
  A: ['A 1033', 'A 1034', 'A 1035', 'A 1036', 
      'A 1122', 'A 1123', 'A 1124', 'A 1125',
      'A 1222', 'A 1223', 'A 1224', 'A 1225',
      'A 1322', 'A 1323', 'A 1324', 'A 1325',
      'A 1422', 'A 1423', 'A 1424', 'A 1425',
      'A 1522', 'A 1523', 'A 1524', 'A 1525',
      'A 1622', 'A 1623', 'A 1624', 'A 1625'],
  B: ['B 2033', 'B 2034', 'B 2035', 'B 2036',
      'B 2122', 'B 2123', 'B 2124', 'B 2125',
      'B 2222', 'B 2223', 'B 2224', 'B 2225',
      'B 2322', 'B 2323', 'B 2324', 'B 2325',
      'B 2422', 'B 2423', 'B 2424', 'B 2425',
      'B 2522', 'B 2523', 'B 2524', 'B 2525',
      'B 2622', 'B 2623', 'B 2624', 'B 2625'],
};

export const ALL_ROOMS = [...ROOM_BLOCKS.A, ...ROOM_BLOCKS.B];

// ინვენტარის კატეგორიები
export const INVENTORY_CATEGORIES = [
  'სამზარეულო',
  'აბაზანა', 
  'ძირითადი ავეჯი',
  'საწოლის თეთრეული',
  'ტექნიკა',
  'განათება',
] as const;

// სტატუსები
export const SCHEDULE_STATUSES = {
  PENDING: 'pending',
  IN_PROGRESS: 'in_progress',
  COMPLETED: 'completed',
} as const;

export const CONDITION_STATUSES = {
  OK: 'OK',
  MISSING: 'Missing',
  TO_REPLACE: 'To Replace',
} as const;

// თარგმანები
export const TRANSLATIONS = {
  ka: {
    dashboard: 'დეშბორდი',
    inventory: 'ინვენტარი',
    housekeeping: 'დასუფთავება',
    maintenance: 'ტექნიკური',
    activity: 'აქტივობა',
    rooms: 'ოთახები',
    totalRooms: 'სულ ოთახი',
    itemsMissing: 'ნაკლული ნივთები',
    pendingTasks: 'მოლოდინში',
    completedTasks: 'დასრულებული',
    save: 'შენახვა',
    cancel: 'გაუქმება',
    add: 'დამატება',
    edit: 'რედაქტირება',
    delete: 'წაშლა',
    search: 'ძებნა',
    filter: 'ფილტრი',
    export: 'ექსპორტი',
    history: 'ისტორია',
  },
  en: {
    dashboard: 'Dashboard',
    inventory: 'Inventory',
    housekeeping: 'Housekeeping',
    maintenance: 'Maintenance',
    activity: 'Activity',
    rooms: 'Rooms',
    totalRooms: 'Total Rooms',
    itemsMissing: 'Missing Items',
    pendingTasks: 'Pending',
    completedTasks: 'Completed',
    save: 'Save',
    cancel: 'Cancel',
    add: 'Add',
    edit: 'Edit',
    delete: 'Delete',
    search: 'Search',
    filter: 'Filter',
    export: 'Export',
    history: 'History',
  },
};
```

---

## 📱 4. MAIN COMPONENTS / მთავარი კომპონენტები

### 4.1 Logistics Page (მთავარი გვერდი)

```tsx
// pages/Logistics.tsx
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Package, ArrowLeft, BarChart3, ClipboardList, Wrench, History } from "lucide-react";

const Logistics = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              უკან / Back
            </Button>
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Package className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">ოთახები და დასუფთავება</h1>
                <p className="text-xs text-muted-foreground">
                  სტუდიოების ინვენტარის მართვა და ანალიტიკა
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              დეშბორდი
            </TabsTrigger>
            <TabsTrigger value="inventory" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              ინვენტარი
            </TabsTrigger>
            <TabsTrigger value="housekeeping" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              დასუფთავება
            </TabsTrigger>
            <TabsTrigger value="maintenance" className="flex items-center gap-2">
              <Wrench className="h-4 w-4" />
              ტექნიკური
            </TabsTrigger>
            <TabsTrigger value="activity" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              აქტივობა
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <InventoryDashboardStats />
          </TabsContent>

          <TabsContent value="inventory">
            <StudioInventoryList />
          </TabsContent>

          <TabsContent value="housekeeping">
            <HousekeepingModule />
          </TabsContent>

          <TabsContent value="maintenance">
            <MaintenanceModule />
          </TabsContent>

          <TabsContent value="activity">
            <LogisticsActivityLog />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Logistics;
```

### 4.2 Dashboard Stats Component

```tsx
// components/InventoryDashboardStats.tsx
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, AlertTriangle, CheckCircle, Wrench } from "lucide-react";

export function InventoryDashboardStats() {
  // Fetch rooms count
  const { data: roomsCount } = useQuery({
    queryKey: ["rooms-count"],
    queryFn: async () => {
      const { count } = await supabase.from("rooms").select("*", { count: "exact", head: true });
      return count || 0;
    },
  });

  // Fetch missing items count
  const { data: missingItemsData } = useQuery({
    queryKey: ["missing-items-count"],
    queryFn: async () => {
      const { data: standardItems } = await supabase.from("standard_inventory_items").select("*");
      const { data: roomItems } = await supabase.from("room_inventory_items").select("*");
      
      let missingCount = 0;
      let affectedRooms = new Set();

      standardItems?.forEach((std) => {
        roomItems?.forEach((ri) => {
          if (ri.standard_item_id === std.id && ri.actual_quantity < std.standard_quantity) {
            missingCount += (std.standard_quantity - ri.actual_quantity);
            affectedRooms.add(ri.room_id);
          }
        });
      });

      return { missingCount, affectedRoomsCount: affectedRooms.size };
    },
  });

  // Fetch today's housekeeping
  const { data: housekeepingStats } = useQuery({
    queryKey: ["housekeeping-stats"],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      
      const { data: todayTasks } = await supabase
        .from("housekeeping_schedules")
        .select("*")
        .eq("scheduled_date", today);

      const completed = todayTasks?.filter(t => t.status === "completed").length || 0;
      const pending = todayTasks?.filter(t => t.status === "pending").length || 0;
      const total = todayTasks?.length || 0;

      return { completed, pending, total };
    },
  });

  // Fetch maintenance stats
  const { data: maintenanceStats } = useQuery({
    queryKey: ["maintenance-stats"],
    queryFn: async () => {
      const { data } = await supabase
        .from("maintenance_schedules")
        .select("*")
        .neq("status", "completed");

      return { pending: data?.length || 0 };
    },
  });

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {/* Total Rooms */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">სულ ოთახი</CardTitle>
          <Package className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{roomsCount}</div>
          <p className="text-xs text-muted-foreground">აქტიური სტუდიო</p>
        </CardContent>
      </Card>

      {/* Missing Items */}
      <Card className={missingItemsData?.missingCount > 0 ? "border-destructive/50" : ""}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">ნაკლული ნივთები</CardTitle>
          <AlertTriangle className={`h-4 w-4 ${missingItemsData?.missingCount > 0 ? "text-destructive" : "text-muted-foreground"}`} />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{missingItemsData?.missingCount || 0}</div>
          <p className="text-xs text-muted-foreground">
            {missingItemsData?.affectedRoomsCount || 0} ოთახში
          </p>
        </CardContent>
      </Card>

      {/* Today's Housekeeping */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">დღევანდელი დასუფთავება</CardTitle>
          <CheckCircle className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {housekeepingStats?.completed || 0}/{housekeepingStats?.total || 0}
          </div>
          <p className="text-xs text-muted-foreground">
            დასრულებული / სულ
          </p>
        </CardContent>
      </Card>

      {/* Pending Maintenance */}
      <Card className={maintenanceStats?.pending > 0 ? "border-yellow-500/50" : ""}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">ტექნიკური პრობლემები</CardTitle>
          <Wrench className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{maintenanceStats?.pending || 0}</div>
          <p className="text-xs text-muted-foreground">მოლოდინში</p>
        </CardContent>
      </Card>
    </div>
  );
}
```

### 4.3 Housekeeping Module

```tsx
// components/HousekeepingModule.tsx
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Plus, CalendarIcon, CheckCircle, Clock, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { RoomMultiSelect } from "./RoomMultiSelect";

interface HousekeepingSchedule {
  id: string;
  scheduled_date: string;
  rooms: string[];
  total_rooms: number;
  status: string;
  notes: string | null;
  completed_at: string | null;
}

export function HousekeepingModule() {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedRooms, setSelectedRooms] = useState<string[]>([]);
  const [notes, setNotes] = useState("");

  // Fetch all rooms for selection
  const { data: allRooms } = useQuery({
    queryKey: ["rooms-list"],
    queryFn: async () => {
      const { data } = await supabase.from("rooms").select("room_number").order("room_number");
      return data?.map(r => r.room_number) || [];
    },
  });

  // Fetch housekeeping schedules
  const { data: schedules, isLoading } = useQuery({
    queryKey: ["housekeeping-schedules"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("housekeeping_schedules")
        .select("*")
        .order("scheduled_date", { ascending: false })
        .limit(50);

      if (error) throw error;
      return data as HousekeepingSchedule[];
    },
  });

  // Create new schedule
  const createMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("housekeeping_schedules").insert({
        scheduled_date: format(selectedDate, "yyyy-MM-dd"),
        rooms: selectedRooms,
        total_rooms: selectedRooms.length,
        status: "pending",
        notes: notes || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["housekeeping-schedules"] });
      toast.success("დასუფთავება დაგეგმილია!");
      setIsAddDialogOpen(false);
      setSelectedRooms([]);
      setNotes("");
    },
    onError: (error) => {
      toast.error("შეცდომა: " + error.message);
    },
  });

  // Complete schedule
  const completeMutation = useMutation({
    mutationFn: async (scheduleId: string) => {
      const { error } = await supabase
        .from("housekeeping_schedules")
        .update({ 
          status: "completed", 
          completed_at: new Date().toISOString() 
        })
        .eq("id", scheduleId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["housekeeping-schedules"] });
      toast.success("დასრულებულია!");
    },
  });

  // Delete schedule
  const deleteMutation = useMutation({
    mutationFn: async (scheduleId: string) => {
      const { error } = await supabase
        .from("housekeeping_schedules")
        .delete()
        .eq("id", scheduleId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["housekeeping-schedules"] });
      toast.success("წაშლილია!");
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">დასრულებული</Badge>;
      case "in_progress":
        return <Badge className="bg-yellow-500">მიმდინარე</Badge>;
      default:
        return <Badge variant="secondary">მოლოდინში</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>დასუფთავების გრაფიკი</CardTitle>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              ახალი დასუფთავება
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>ახალი დასუფთავების დაგეგმვა</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {/* Date Picker */}
              <div className="space-y-2">
                <label className="text-sm font-medium">თარიღი</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {format(selectedDate, "yyyy-MM-dd")}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={(date) => date && setSelectedDate(date)}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Room Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">ოთახები</label>
                <RoomMultiSelect
                  availableRooms={allRooms || []}
                  selectedRooms={selectedRooms}
                  onChange={setSelectedRooms}
                />
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <label className="text-sm font-medium">შენიშვნა</label>
                <Input
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="დამატებითი ინფორმაცია..."
                />
              </div>

              <Button 
                onClick={() => createMutation.mutate()} 
                disabled={selectedRooms.length === 0}
                className="w-full"
              >
                დაგეგმვა ({selectedRooms.length} ოთახი)
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>

      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>თარიღი</TableHead>
              <TableHead>ოთახები</TableHead>
              <TableHead>სტატუსი</TableHead>
              <TableHead>შენიშვნა</TableHead>
              <TableHead className="text-right">მოქმედება</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {schedules?.map((schedule) => (
              <TableRow key={schedule.id}>
                <TableCell className="font-medium">
                  {format(new Date(schedule.scheduled_date), "dd/MM/yyyy")}
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1 max-w-[300px]">
                    {schedule.rooms.slice(0, 3).map((room) => (
                      <Badge key={room} variant="outline" className="text-xs">
                        {room}
                      </Badge>
                    ))}
                    {schedule.rooms.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{schedule.rooms.length - 3}
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>{getStatusBadge(schedule.status)}</TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {schedule.notes || "-"}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    {schedule.status !== "completed" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => completeMutation.mutate(schedule.id)}
                      >
                        <CheckCircle className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteMutation.mutate(schedule.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
```

### 4.4 Maintenance Module

```tsx
// components/MaintenanceModule.tsx
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Wrench, CheckCircle, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface MaintenanceSchedule {
  id: string;
  room_number: string;
  problem: string;
  scheduled_date: string;
  solving_date: string | null;
  cost: number;
  status: string;
  notes: string | null;
}

export function MaintenanceModule() {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    room_number: "",
    problem: "",
    cost: 0,
    notes: "",
  });

  // Fetch all rooms
  const { data: allRooms } = useQuery({
    queryKey: ["rooms-list"],
    queryFn: async () => {
      const { data } = await supabase.from("rooms").select("room_number").order("room_number");
      return data || [];
    },
  });

  // Fetch maintenance schedules
  const { data: schedules, isLoading } = useQuery({
    queryKey: ["maintenance-schedules"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("maintenance_schedules")
        .select("*")
        .order("scheduled_date", { ascending: false })
        .limit(50);

      if (error) throw error;
      return data as MaintenanceSchedule[];
    },
  });

  // Create new maintenance
  const createMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("maintenance_schedules").insert({
        room_number: formData.room_number,
        problem: formData.problem,
        cost: formData.cost,
        notes: formData.notes || null,
        scheduled_date: new Date().toISOString().split("T")[0],
        status: "pending",
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["maintenance-schedules"] });
      toast.success("პრობლემა დარეგისტრირდა!");
      setIsAddDialogOpen(false);
      setFormData({ room_number: "", problem: "", cost: 0, notes: "" });
    },
    onError: (error) => {
      toast.error("შეცდომა: " + error.message);
    },
  });

  // Complete maintenance
  const completeMutation = useMutation({
    mutationFn: async (maintenanceId: string) => {
      const { error } = await supabase
        .from("maintenance_schedules")
        .update({ 
          status: "completed",
          solving_date: new Date().toISOString().split("T")[0],
          completed_at: new Date().toISOString(),
        })
        .eq("id", maintenanceId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["maintenance-schedules"] });
      toast.success("მოგვარებულია!");
    },
  });

  // Delete maintenance
  const deleteMutation = useMutation({
    mutationFn: async (maintenanceId: string) => {
      const { error } = await supabase
        .from("maintenance_schedules")
        .delete()
        .eq("id", maintenanceId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["maintenance-schedules"] });
      toast.success("წაშლილია!");
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-500">მოგვარებული</Badge>;
      case "in_progress":
        return <Badge className="bg-yellow-500">მიმდინარე</Badge>;
      default:
        return <Badge variant="destructive">მოლოდინში</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5" />
          ტექნიკური პრობლემები
        </CardTitle>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              ახალი პრობლემა
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>ახალი ტექნიკური პრობლემის დარეგისტრირება</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              {/* Room Selection */}
              <div className="space-y-2">
                <label className="text-sm font-medium">ოთახი</label>
                <Select
                  value={formData.room_number}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, room_number: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="აირჩიეთ ოთახი" />
                  </SelectTrigger>
                  <SelectContent>
                    {allRooms?.map((room) => (
                      <SelectItem key={room.room_number} value={room.room_number}>
                        {room.room_number}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Problem Description */}
              <div className="space-y-2">
                <label className="text-sm font-medium">პრობლემის აღწერა</label>
                <Textarea
                  value={formData.problem}
                  onChange={(e) => setFormData(prev => ({ ...prev, problem: e.target.value }))}
                  placeholder="მაგ: კონდიციონერი არ მუშაობს..."
                  rows={3}
                />
              </div>

              {/* Estimated Cost */}
              <div className="space-y-2">
                <label className="text-sm font-medium">სავარაუდო ხარჯი (₾)</label>
                <Input
                  type="number"
                  value={formData.cost}
                  onChange={(e) => setFormData(prev => ({ ...prev, cost: Number(e.target.value) }))}
                  placeholder="0"
                />
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <label className="text-sm font-medium">შენიშვნა</label>
                <Input
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="დამატებითი ინფორმაცია..."
                />
              </div>

              <Button 
                onClick={() => createMutation.mutate()} 
                disabled={!formData.room_number || !formData.problem}
                className="w-full"
              >
                რეგისტრაცია
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>

      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ოთახი</TableHead>
              <TableHead>პრობლემა</TableHead>
              <TableHead>თარიღი</TableHead>
              <TableHead>ხარჯი</TableHead>
              <TableHead>სტატუსი</TableHead>
              <TableHead className="text-right">მოქმედება</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {schedules?.map((schedule) => (
              <TableRow key={schedule.id}>
                <TableCell>
                  <Badge variant="outline">{schedule.room_number}</Badge>
                </TableCell>
                <TableCell className="max-w-[300px]">
                  <p className="truncate">{schedule.problem}</p>
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {format(new Date(schedule.scheduled_date), "dd/MM/yyyy")}
                </TableCell>
                <TableCell>
                  {schedule.cost > 0 ? `${schedule.cost} ₾` : "-"}
                </TableCell>
                <TableCell>{getStatusBadge(schedule.status)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    {schedule.status !== "completed" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => completeMutation.mutate(schedule.id)}
                        title="მოგვარებულად მონიშვნა"
                      >
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteMutation.mutate(schedule.id)}
                      title="წაშლა"
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
```

### 4.5 All Rooms Inventory Matrix

```tsx
// components/AllRoomsInventory.tsx
// სრული Inventory Matrix - კატეგორიების მიხედვით ყველა ოთახის შედარება

import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangle } from "lucide-react";

export function AllRoomsInventory() {
  // Fetch all data
  const { data: rooms } = useQuery({
    queryKey: ["rooms"],
    queryFn: async () => {
      const { data } = await supabase.from("rooms").select("*").order("room_number");
      return data || [];
    },
  });

  const { data: standardItems } = useQuery({
    queryKey: ["standard-inventory-items"],
    queryFn: async () => {
      const { data } = await supabase
        .from("standard_inventory_items")
        .select("*")
        .order("category")
        .order("item_name");
      return data || [];
    },
  });

  const { data: allRoomItems } = useQuery({
    queryKey: ["all-room-inventory-items"],
    queryFn: async () => {
      const { data } = await supabase.from("room_inventory_items").select("*");
      return data || [];
    },
  });

  if (!rooms || !standardItems) return <div>Loading...</div>;

  // Build inventory matrix by item
  const inventoryByItem: Record<string, { 
    item: typeof standardItems[0], 
    totalMissing: number,
    roomQuantities: Array<{ roomNumber: string, roomId: string, actualQty: number, isMissing: boolean }>
  }> = {};

  standardItems.forEach((item) => {
    let totalMissing = 0;
    const roomQuantities: Array<{ roomNumber: string, roomId: string, actualQty: number, isMissing: boolean }> = [];

    rooms.forEach((room) => {
      const roomItem = allRoomItems?.find(
        (ri) => ri.room_id === room.id && ri.standard_item_id === item.id
      );
      const actualQty = roomItem?.actual_quantity ?? item.standard_quantity;
      const isMissing = actualQty < item.standard_quantity;
      
      if (isMissing) {
        totalMissing += (item.standard_quantity - actualQty);
      }

      roomQuantities.push({ 
        roomNumber: room.room_number, 
        roomId: room.id,
        actualQty,
        isMissing 
      });
    });

    inventoryByItem[item.id] = { item, totalMissing, roomQuantities };
  });

  // Group by category
  const groupedInventory = Object.values(inventoryByItem).reduce((acc, data) => {
    if (!acc[data.item.category]) {
      acc[data.item.category] = [];
    }
    acc[data.item.category].push(data);
    return acc;
  }, {} as Record<string, typeof inventoryByItem[string][]>);

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <AlertTriangle className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold">ყველა ოთახის ინვენტარი</h3>
      </div>

      <Tabs defaultValue={Object.keys(groupedInventory)[0]} className="w-full">
        <TabsList className="flex flex-wrap h-auto mb-4">
          {Object.keys(groupedInventory).map((category) => (
            <TabsTrigger key={category} value={category}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(groupedInventory).map(([category, items]) => (
          <TabsContent key={category} value={category}>
            <div className="border rounded-md overflow-auto max-h-[600px]">
              <Table>
                <TableHeader className="sticky top-0 bg-background z-10">
                  <TableRow>
                    <TableHead className="sticky left-0 bg-background z-20 min-w-[250px]">
                      ნივთი
                    </TableHead>
                    <TableHead className="min-w-[100px] text-center">სტანდარტი</TableHead>
                    <TableHead className="min-w-[100px] text-center">ნაკლული ჯამი</TableHead>
                    {rooms.map((room) => (
                      <TableHead key={room.id} className="min-w-[80px] text-center text-xs">
                        {room.room_number}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map(({ item, totalMissing, roomQuantities }) => (
                    <TableRow key={item.id}>
                      <TableCell className="sticky left-0 bg-background font-medium">
                        {item.item_name}
                      </TableCell>
                      <TableCell className="text-center">{item.standard_quantity}</TableCell>
                      <TableCell className="text-center">
                        {totalMissing > 0 ? (
                          <Badge variant="destructive">{totalMissing}</Badge>
                        ) : (
                          <Badge variant="secondary">0</Badge>
                        )}
                      </TableCell>
                      {roomQuantities.map(({ roomId, actualQty, isMissing }) => (
                        <TableCell key={roomId} className="text-center">
                          <Badge 
                            variant={isMissing ? "destructive" : "secondary"}
                            className="min-w-[30px]"
                          >
                            {actualQty}
                          </Badge>
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </Card>
  );
}
```

---

## 🔗 5. HELPER COMPONENTS

### 5.1 Room Multi-Select

```tsx
// components/RoomMultiSelect.tsx
import { useState } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface RoomMultiSelectProps {
  availableRooms: string[];
  selectedRooms: string[];
  onChange: (rooms: string[]) => void;
}

export const RoomMultiSelect = ({ availableRooms, selectedRooms, onChange }: RoomMultiSelectProps) => {
  const [open, setOpen] = useState(false);

  const toggleRoom = (room: string) => {
    if (selectedRooms.includes(room)) {
      onChange(selectedRooms.filter((r) => r !== room));
    } else {
      onChange([...selectedRooms, room]);
    }
  };

  return (
    <div className="space-y-2">
      {selectedRooms.length > 0 && (
        <div className="flex flex-wrap gap-1.5 p-2 border rounded-md bg-muted/30">
          {selectedRooms.map((room) => (
            <Badge key={room} variant="secondary">{room}</Badge>
          ))}
        </div>
      )}
      
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="w-full">
            <ChevronsUpDown className="mr-2 h-4 w-4" />
            {selectedRooms.length === 0 ? "აირჩიეთ ოთახები" : `არჩეულია: ${selectedRooms.length}`}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0">
          <Command>
            <CommandInput placeholder="ძიება..." />
            <CommandList>
              <CommandEmpty>ოთახი ვერ მოიძებნა</CommandEmpty>
              <CommandGroup>
                {availableRooms.map((room) => (
                  <CommandItem key={room} value={room} onSelect={() => toggleRoom(room)}>
                    <Check className={cn("mr-2 h-4 w-4", selectedRooms.includes(room) ? "opacity-100" : "opacity-0")} />
                    {room}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
          <div className="border-t p-2">
            <Button onClick={() => setOpen(false)} className="w-full" size="sm">
              დასრულება ({selectedRooms.length})
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};
```

### 5.2 Activity Logger Hook

```tsx
// hooks/useLogisticsActivity.ts
import { supabase } from "@/integrations/supabase/client";

interface LogActivityParams {
  action: "create" | "update" | "delete";
  entityType: "room" | "inventory_item" | "housekeeping_schedule" | "maintenance_schedule";
  entityId?: string;
  entityName?: string;
  changes?: any;
}

export const useLogisticsActivity = () => {
  const logActivity = async ({ action, entityType, entityId, entityName, changes }: LogActivityParams) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from("logistics_activity_log").insert({
        user_id: user.id,
        user_email: user.email,
        action,
        entity_type: entityType,
        entity_id: entityId,
        entity_name: entityName,
        changes,
      });
    } catch (error) {
      console.error("Error logging activity:", error);
    }
  };

  return { logActivity };
};
```

---

## 🎨 6. CSS / STYLES

```css
/* index.css - Tailwind + Custom Styles */

@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  /* Primary Colors - Sea Blue (Orbi City brand) */
  --primary: 199 89% 36%;        /* #0078B7 */
  --primary-foreground: 0 0% 100%;
  
  /* Gold accent */
  --accent: 39 58% 59%;          /* #D6A85A */
  
  /* Background & Foreground */
  --background: 210 20% 98%;
  --foreground: 222 47% 11%;
  
  /* Cards & Borders */
  --card: 0 0% 100%;
  --card-foreground: 222 47% 11%;
  --border: 214 32% 91%;
  
  /* Muted colors */
  --muted: 210 40% 96%;
  --muted-foreground: 215 16% 47%;
  
  /* Semantic colors */
  --destructive: 0 84% 60%;
  --destructive-foreground: 0 0% 100%;
  
  /* Radius */
  --radius: 0.5rem;
}

.dark {
  --background: 222 47% 11%;
  --foreground: 210 40% 98%;
  --card: 222 47% 15%;
  --card-foreground: 210 40% 98%;
  --border: 217 33% 25%;
  --muted: 217 33% 20%;
  --muted-foreground: 215 20% 65%;
}

/* Custom scrollbar */
.custom-scrollbar::-webkit-scrollbar {
  width: 8px;
  height: 8px;
}

.custom-scrollbar::-webkit-scrollbar-track {
  background: hsl(var(--muted));
  border-radius: 4px;
}

.custom-scrollbar::-webkit-scrollbar-thumb {
  background: hsl(var(--primary) / 0.5);
  border-radius: 4px;
}

.custom-scrollbar::-webkit-scrollbar-thumb:hover {
  background: hsl(var(--primary) / 0.7);
}
```

---

## 📋 7. DEPENDENCIES / დამოკიდებულებები

```json
{
  "dependencies": {
    "@radix-ui/react-dialog": "^1.1.14",
    "@radix-ui/react-popover": "^1.1.14",
    "@radix-ui/react-select": "^2.2.5",
    "@radix-ui/react-tabs": "^1.1.12",
    "@supabase/supabase-js": "^2.76.1",
    "@tanstack/react-query": "^5.83.0",
    "cmdk": "^1.1.1",
    "date-fns": "^3.6.0",
    "lucide-react": "^0.462.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router-dom": "^6.30.1",
    "sonner": "^1.7.4",
    "tailwindcss": "^3.4.0",
    "xlsx": "^0.18.5"
  }
}
```

---

## 🚀 8. QUICK START INSTRUCTIONS

1. **Database Setup:**
   - Copy SQL schema და run Supabase-ში
   - Enable RLS policies
   - Insert sample data

2. **Frontend Setup:**
   - Create React + Vite project
   - Install dependencies
   - Copy components

3. **Environment Variables:**
   ```env
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_anon_key
   ```

---

**Last Updated:** 2024-12-29  
**Version:** 2.0  
**Author:** Orbi City AI System
