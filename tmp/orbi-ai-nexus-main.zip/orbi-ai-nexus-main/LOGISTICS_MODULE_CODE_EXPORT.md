# Logistics Module - Complete Code Export for Google Flash UI

## Project Overview

This is a complete **Rooms & Housekeeping (Logistics)** module built with:
- **React** + **TypeScript**
- **Vite** as build tool
- **Tailwind CSS** for styling
- **Shadcn/UI** for UI components
- **Supabase** for backend (PostgreSQL database)
- **TanStack React Query** for data fetching
- **Lucide React** for icons
- **date-fns** for date formatting

---

## Database Schema

### Tables Required

```sql
-- 1. Rooms table
CREATE TABLE public.rooms (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  room_number TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 2. Standard inventory items (master list)
CREATE TABLE public.standard_inventory_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,
  item_name TEXT NOT NULL,
  standard_quantity INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 3. Room inventory items (actual quantities per room)
CREATE TABLE public.room_inventory_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES rooms(id),
  standard_item_id UUID NOT NULL REFERENCES standard_inventory_items(id),
  actual_quantity INTEGER NOT NULL DEFAULT 0,
  condition TEXT DEFAULT 'OK',
  notes TEXT,
  last_checked TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  issue_detected_at TIMESTAMP WITH TIME ZONE,
  issue_resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 4. Room inventory descriptions (change history)
CREATE TABLE public.room_inventory_descriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES rooms(id),
  user_id UUID,
  description_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  change_type TEXT,
  items_missing TEXT,
  items_added TEXT,
  items_removed TEXT,
  transfer_from_room TEXT,
  transfer_to_room TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 5. Housekeeping schedules
CREATE TABLE public.housekeeping_schedules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  scheduled_date DATE NOT NULL,
  rooms TEXT[] NOT NULL,
  total_rooms INTEGER NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  media_urls TEXT[] DEFAULT '{}',
  additional_notes TEXT,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 6. Maintenance schedules
CREATE TABLE public.maintenance_schedules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID,
  scheduled_date DATE NOT NULL,
  solving_date DATE,
  room_number TEXT NOT NULL,
  problem TEXT NOT NULL,
  notes TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  cost NUMERIC DEFAULT 0,
  media_urls TEXT[] DEFAULT '{}',
  additional_notes TEXT,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 7. Activity log
CREATE TABLE public.logistics_activity_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  user_email TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  entity_name TEXT,
  changes JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
```

---

## File Structure

```
src/
├── pages/
│   └── Logistics.tsx                    # Main page with tabs
├── components/
│   ├── HousekeepingModule.tsx           # Housekeeping CRUD
│   ├── MaintenanceModule.tsx            # Maintenance CRUD  
│   ├── StudioInventoryList.tsx          # Room selector
│   ├── AllRoomsInventory.tsx            # All rooms inventory grid
│   ├── RoomInventoryTable.tsx           # Single room inventory
│   ├── RoomInventoryHistory.tsx         # Room change history
│   ├── RoomMultiSelect.tsx              # Multi-room selector
│   ├── InventoryDashboardStats.tsx      # Dashboard statistics
│   ├── InventoryDashboard.tsx           # Detailed dashboard
│   ├── CategoryInventoryHistory.tsx     # Category history dialog
│   ├── LogisticsActivityLog.tsx         # Activity log display
│   ├── BulkInventoryImport.tsx          # Text-based import
│   └── OrbiLogistics.tsx                # Module card for homepage
├── hooks/
│   ├── useLogisticsActivity.ts          # Activity logging hook
│   └── useLogisticsRealtimeNotifications.ts  # Realtime notifications
└── contexts/
    └── LanguageContext.tsx              # i18n support (Georgian/English)
```

---

## Complete Component Code

### 1. Main Page: `src/pages/Logistics.tsx`

```tsx
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Package, ArrowLeft, BarChart3, ClipboardList, Wrench, History } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { InventoryDashboardStats } from "@/components/InventoryDashboardStats";
import { StudioInventoryList } from "@/components/StudioInventoryList";
import { HousekeepingModule } from "@/components/HousekeepingModule";
import { MaintenanceModule } from "@/components/MaintenanceModule";
import { LogisticsActivityLog } from "@/components/LogisticsActivityLog";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState, Suspense } from "react";
import { Loader2 } from "lucide-react";
import { useLogisticsRealtimeNotifications } from "@/hooks/useLogisticsRealtimeNotifications";

const Logistics = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  // Enable real-time notifications
  useLogisticsRealtimeNotifications();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsAuthenticated(!!session);
    });
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            {isAuthenticated && (
              <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                {t("უკან", "Back")}
              </Button>
            )}
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-ai">
                <Package className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">
                  {t("ოთახები და დასუფთავება", "Rooms & Housekeeping")}
                </h1>
                <p className="text-xs text-muted-foreground">
                  {t("სტუდიოების ინვენტარის მართვა და ანალიტიკა", "Studio inventory management and analytics")}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              {t("დეშბორდი", "Dashboard")}
            </TabsTrigger>
            <TabsTrigger value="inventory" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              {t("ინვენტარი", "Inventory")}
            </TabsTrigger>
            <TabsTrigger value="housekeeping" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              {t("დასუფთავება", "Housekeeping")}
            </TabsTrigger>
            <TabsTrigger value="maintenance" className="flex items-center gap-2">
              <Wrench className="h-4 w-4" />
              {t("ტექნიკური", "Maintenance")}
            </TabsTrigger>
            <TabsTrigger value="activity" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              {t("აქტივობა", "Activity")}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <Suspense fallback={<div className="flex items-center justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
              <InventoryDashboardStats />
            </Suspense>
          </TabsContent>

          <TabsContent value="inventory">
            <Suspense fallback={<div className="flex items-center justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
              <StudioInventoryList />
            </Suspense>
          </TabsContent>

          <TabsContent value="housekeeping">
            <Suspense fallback={<div className="flex items-center justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
              <HousekeepingModule />
            </Suspense>
          </TabsContent>

          <TabsContent value="maintenance">
            <Suspense fallback={<div className="flex items-center justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
              <MaintenanceModule />
            </Suspense>
          </TabsContent>

          <TabsContent value="activity">
            <Suspense fallback={<div className="flex items-center justify-center p-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>}>
              <LogisticsActivityLog />
            </Suspense>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Logistics;
```

---

### 2. Dashboard Stats: `src/components/InventoryDashboardStats.tsx`

```tsx
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Package, CheckCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Loader2 } from "lucide-react";
import { useEffect } from "react";

interface MissingItem {
  category: string;
  item_name: string;
  standard_quantity: number;
  rooms_with_issues: Array<{
    room_number: string;
    actual_quantity: number;
    missing_count: number;
  }>;
  total_missing: number;
}

export function InventoryDashboardStats() {
  const { t } = useLanguage();
  const queryClient = useQueryClient();

  // Set up realtime subscriptions for data updates
  useEffect(() => {
    const roomsChannel = supabase
      .channel('dashboard-rooms-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'rooms' }, () => {
        queryClient.invalidateQueries({ queryKey: ["rooms"] });
      })
      .subscribe();

    const inventoryChannel = supabase
      .channel('dashboard-inventory-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'room_inventory_items' }, () => {
        queryClient.invalidateQueries({ queryKey: ["all-room-inventory-items"] });
      })
      .subscribe();

    const housekeepingChannel = supabase
      .channel('dashboard-housekeeping-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'housekeeping_schedules' }, () => {
        queryClient.invalidateQueries({ queryKey: ["housekeeping-schedules-stats"] });
      })
      .subscribe();

    const maintenanceChannel = supabase
      .channel('dashboard-maintenance-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'maintenance_schedules' }, () => {
        queryClient.invalidateQueries({ queryKey: ["maintenance-schedules-stats"] });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(roomsChannel);
      supabase.removeChannel(inventoryChannel);
      supabase.removeChannel(housekeepingChannel);
      supabase.removeChannel(maintenanceChannel);
    };
  }, [queryClient]);

  const { data: housekeepingSchedules = [], isLoading: isLoadingHousekeeping } = useQuery({
    queryKey: ["housekeeping-schedules-stats"],
    queryFn: async () => {
      const { data, error } = await supabase.from("housekeeping_schedules").select("*");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: maintenanceSchedules = [], isLoading: isLoadingMaintenance } = useQuery({
    queryKey: ["maintenance-schedules-stats"],
    queryFn: async () => {
      const { data, error } = await supabase.from("maintenance_schedules").select("*");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: rooms = [], isLoading: isLoadingRooms } = useQuery({
    queryKey: ["rooms"],
    queryFn: async () => {
      const { data, error } = await supabase.from("rooms").select("*");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: standardItems = [], isLoading: isLoadingStandardItems } = useQuery({
    queryKey: ["standard-inventory-items"],
    queryFn: async () => {
      const { data, error } = await supabase.from("standard_inventory_items").select("*");
      if (error) throw error;
      return data || [];
    },
  });

  const { data: allRoomItems = [], isLoading: isLoadingRoomItems } = useQuery({
    queryKey: ["all-room-inventory-items"],
    queryFn: async () => {
      const { data, error } = await supabase.from("room_inventory_items").select("*");
      if (error) throw error;
      return data || [];
    },
  });

  const isLoading = isLoadingHousekeeping || isLoadingMaintenance || isLoadingRooms || isLoadingStandardItems || isLoadingRoomItems;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Calculate missing items
  const missingItems: MissingItem[] = [];
  const roomsWithIssues = new Set<string>();

  standardItems.forEach((item) => {
    const roomsWithMissing: Array<{ room_number: string; actual_quantity: number; missing_count: number }> = [];
    let totalMissing = 0;

    rooms.forEach((room) => {
      const roomItem = allRoomItems.find((ri) => ri.room_id === room.id && ri.standard_item_id === item.id);
      const actualQty = roomItem?.actual_quantity ?? item.standard_quantity;

      if (actualQty < item.standard_quantity) {
        const missingCount = item.standard_quantity - actualQty;
        roomsWithMissing.push({ room_number: room.room_number, actual_quantity: actualQty, missing_count: missingCount });
        totalMissing += missingCount;
        roomsWithIssues.add(room.room_number);
      }
    });

    if (roomsWithMissing.length > 0) {
      missingItems.push({
        category: item.category,
        item_name: item.item_name,
        standard_quantity: item.standard_quantity,
        rooms_with_issues: roomsWithMissing,
        total_missing: totalMissing,
      });
    }
  });

  // Group by category
  const missingByCategory = missingItems.reduce((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, MissingItem[]>);

  // Group by room
  const missingByRoom: Record<string, Array<{ item_name: string; missing_count: number }>> = {};
  missingItems.forEach((item) => {
    item.rooms_with_issues.forEach((room) => {
      if (!missingByRoom[room.room_number]) missingByRoom[room.room_number] = [];
      missingByRoom[room.room_number].push({ item_name: item.item_name, missing_count: room.missing_count });
    });
  });

  const totalRooms = rooms.length;
  const roomsOK = totalRooms - roomsWithIssues.size;

  // Calculate stats
  const totalHousekeepingTasks = housekeepingSchedules?.length || 0;
  const completedHousekeepingTasks = housekeepingSchedules?.filter(s => s.status === 'completed').length || 0;
  const pendingHousekeepingTasks = totalHousekeepingTasks - completedHousekeepingTasks;

  const totalMaintenanceTasks = maintenanceSchedules?.length || 0;
  const completedMaintenanceTasks = maintenanceSchedules?.filter(s => s.status === 'completed').length || 0;
  const pendingMaintenanceTasks = totalMaintenanceTasks - completedMaintenanceTasks;
  const totalMaintenanceCost = maintenanceSchedules?.reduce((sum, s) => sum + (Number(s.cost) || 0), 0) || 0;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-primary/10 rounded-lg">
              <Package className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("სულ ოთახები", "Total Rooms")}</p>
              <p className="text-2xl font-bold">{totalRooms}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-500/10 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("რეგულარული ოთახები", "Rooms OK")}</p>
              <p className="text-2xl font-bold">{roomsOK}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-destructive/10 rounded-lg">
              <AlertTriangle className="h-6 w-6 text-destructive" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{t("ოთახები პრობლემებით", "Rooms with Issues")}</p>
              <p className="text-2xl font-bold">{roomsWithIssues.size}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Housekeeping & Maintenance Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-primary" />
            {t("დასუფთავება", "Housekeeping")}
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t("სულ დავალებები", "Total Tasks")}</span>
              <span className="font-semibold">{totalHousekeepingTasks}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t("შესრულებული", "Completed")}</span>
              <span className="font-semibold text-green-600">{completedHousekeepingTasks}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t("მიმდინარე", "Pending")}</span>
              <span className="font-semibold text-yellow-600">{pendingHousekeepingTasks}</span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-primary" />
            {t("ტექნიკური", "Maintenance")}
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t("სულ დავალებები", "Total Tasks")}</span>
              <span className="font-semibold">{totalMaintenanceTasks}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t("შესრულებული", "Completed")}</span>
              <span className="font-semibold text-green-600">{completedMaintenanceTasks}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">{t("მიმდინარე", "Pending")}</span>
              <span className="font-semibold text-yellow-600">{pendingMaintenanceTasks}</span>
            </div>
            <div className="flex justify-between items-center border-t pt-3">
              <span className="text-sm text-muted-foreground">{t("სულ ხარჯი", "Total Cost")}</span>
              <span className="font-semibold">{totalMaintenanceCost.toFixed(2)} ₾</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Missing Items by Category */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Package className="h-5 w-5 text-primary" />
          {t("დანაკლისი ნივთები კატეგორიების მიხედვით", "Missing Items by Category")}
        </h3>
        <div className="space-y-4">
          {Object.entries(missingByCategory).map(([category, items]) => (
            <div key={category} className="border rounded-lg p-4">
              <h4 className="font-medium mb-3 text-primary">{category}</h4>
              <div className="space-y-2">
                {items.map((item) => (
                  <div key={item.item_name} className="flex items-center justify-between text-sm">
                    <span>{item.item_name}</span>
                    <Badge variant="destructive">{t("ნაკლი", "Missing")}: {item.total_missing}</Badge>
                  </div>
                ))}
              </div>
            </div>
          ))}
          {Object.keys(missingByCategory).length === 0 && (
            <div className="text-center text-muted-foreground py-8">
              <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-600" />
              <p>{t("ყველა ნივთი სრულყოფილია!", "All items are complete!")}</p>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
```

---

### 3. Housekeeping Module: `src/components/HousekeepingModule.tsx`

**Features:**
- Multi-room selection for cleaning schedules
- Status tracking (pending/completed)
- Photo/video upload to storage bucket
- Edit and delete schedules
- Activity logging

```tsx
import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Check, Pencil, Upload, Calendar, X } from "lucide-react";
import { format } from "date-fns";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { RoomMultiSelect } from "@/components/RoomMultiSelect";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useLogisticsActivity } from "@/hooks/useLogisticsActivity";

interface ScheduleEntry {
  date: string;
  rooms: string[];
  notes: string;
}

export const HousekeepingModule = () => {
  const { t } = useLanguage();
  const queryClient = useQueryClient();
  const { logActivity } = useLogisticsActivity();
  const [entries, setEntries] = useState<ScheduleEntry[]>([]);
  const [editingSchedule, setEditingSchedule] = useState<any>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [selectedSchedule, setSelectedSchedule] = useState<any>(null);
  const [uploadingFiles, setUploadingFiles] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: availableRooms } = useQuery({
    queryKey: ["available-rooms"],
    queryFn: async () => {
      const { data, error } = await supabase.from("rooms").select("room_number").order("room_number");
      if (error) throw error;
      return data.map(r => r.room_number);
    },
  });

  const { data: schedules, isLoading } = useQuery({
    queryKey: ["housekeeping-schedules"],
    queryFn: async () => {
      const { data, error } = await supabase.from("housekeeping_schedules").select("*").order("scheduled_date", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const addScheduleMutation = useMutation({
    mutationFn: async (entry: ScheduleEntry) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { data, error } = await supabase.from("housekeeping_schedules").insert({
        user_id: user.id,
        scheduled_date: entry.date,
        rooms: entry.rooms,
        total_rooms: entry.rooms.length,
        notes: entry.notes.trim() || null,
        status: "pending",
      }).select().single();

      if (error) throw error;
      return data;
    },
    onSuccess: async (data, entry) => {
      await logActivity({
        action: "create",
        entityType: "housekeeping_schedule",
        entityId: data.id,
        entityName: `${entry.rooms.length} rooms - ${entry.date}`,
        changes: { rooms: entry.rooms, notes: entry.notes },
      });
      queryClient.invalidateQueries({ queryKey: ["housekeeping-schedules"] });
      toast.success(t("ჩანაწერი დაემატა", "Entry added"));
    },
  });

  // ... rest of the component (mutations, handlers, render)
  // See full code in actual file
};
```

---

### 4. Activity Logging Hook: `src/hooks/useLogisticsActivity.ts`

```tsx
import { supabase } from "@/integrations/supabase/client";

interface LogActivityParams {
  action: "create" | "update" | "delete";
  entityType: "room" | "inventory_item" | "housekeeping_schedule" | "maintenance_schedule";
  entityId?: string;
  entityName?: string;
  changes?: any;
}

export const useLogisticsActivity = () => {
  const logActivity = async ({ action, entityType, entityId, entityName, changes }: LogActivityParams) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase.from("logistics_activity_log").insert({
        user_id: user.id,
        user_email: user.email,
        action,
        entity_type: entityType,
        entity_id: entityId,
        entity_name: entityName,
        changes,
      });
    } catch (error) {
      console.error("Error logging activity:", error);
    }
  };

  return { logActivity };
};
```

---

### 5. Realtime Notifications Hook: `src/hooks/useLogisticsRealtimeNotifications.ts`

```tsx
import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

export const useLogisticsRealtimeNotifications = () => {
  const { t } = useLanguage();

  useEffect(() => {
    const getCurrentUserId = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      return user?.id;
    };

    const setupRealtimeSubscription = async () => {
      const currentUserId = await getCurrentUserId();

      const channel = supabase
        .channel('logistics-changes')
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'logistics_activity_log' }, (payload) => {
          const newLog = payload.new as any;
          
          if (newLog.user_id === currentUserId) return;

          const actionText = {
            create: t("შექმნა", "created"),
            update: t("განაახლა", "updated"),
            delete: t("წაშალა", "deleted")
          }[newLog.action] || newLog.action;

          const entityText = {
            room: t("ოთახი", "room"),
            inventory_item: t("ინვენტარის ელემენტი", "inventory item"),
            housekeeping_schedule: t("დასუფთავების გრაფიკი", "housekeeping schedule"),
            maintenance_schedule: t("ტექნიკური გრაფიკი", "maintenance schedule")
          }[newLog.entity_type] || newLog.entity_type;

          toast({
            title: t("ახალი ცვლილება", "New Change"),
            description: `${newLog.user_email || t("მომხმარებელმა", "User")} ${actionText} ${entityText}`,
            duration: 5000,
          });
        })
        .subscribe();

      return () => supabase.removeChannel(channel);
    };

    setupRealtimeSubscription();
  }, [t]);
};
```

---

### 6. Room Multi-Select Component: `src/components/RoomMultiSelect.tsx`

```tsx
import { useState } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/contexts/LanguageContext";

interface RoomMultiSelectProps {
  availableRooms: string[];
  selectedRooms: string[];
  onChange: (rooms: string[]) => void;
}

export const RoomMultiSelect = ({ availableRooms, selectedRooms, onChange }: RoomMultiSelectProps) => {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);

  const toggleRoom = (room: string) => {
    if (selectedRooms.includes(room)) {
      onChange(selectedRooms.filter((r) => r !== room));
    } else {
      onChange([...selectedRooms, room]);
    }
  };

  return (
    <div className="space-y-2">
      {selectedRooms.length > 0 && (
        <div className="flex flex-wrap gap-1.5 p-2 border rounded-md bg-muted/30 min-h-10">
          {selectedRooms.map((room) => (
            <Badge key={room} variant="secondary" className="text-sm">{room}</Badge>
          ))}
        </div>
      )}
      
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="w-full">
            <ChevronsUpDown className="mr-2 h-4 w-4" />
            {selectedRooms.length === 0 ? t("აირჩიეთ ნომრები", "Select rooms") : t("ცვლილება", "Edit selection")}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0 z-50 bg-popover" align="start">
          <Command>
            <CommandInput placeholder={t("ძიება...", "Search...")} />
            <CommandList>
              <CommandEmpty>{t("ნომერი არ მოიძებნა", "No room found")}</CommandEmpty>
              <CommandGroup>
                {availableRooms.map((room) => (
                  <CommandItem key={room} value={room} onSelect={() => toggleRoom(room)}>
                    <Check className={cn("mr-2 h-4 w-4", selectedRooms.includes(room) ? "opacity-100" : "opacity-0")} />
                    {room}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
          <div className="border-t p-2">
            <Button onClick={() => setOpen(false)} className="w-full" size="sm">
              {t("არჩევის დასრულება", "Done")} ({selectedRooms.length})
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};
```

---

## Key Features Summary

1. **Dashboard** - Real-time statistics for rooms, housekeeping, maintenance, missing inventory
2. **Inventory Management** - Track items per room, compare to standard quantities
3. **Housekeeping Scheduler** - Multi-room selection, status tracking, photo uploads
4. **Maintenance Tracker** - Problem logging, cost tracking, status management
5. **Activity Log** - All changes logged with user info and timestamps
6. **Real-time Updates** - Supabase realtime subscriptions for live data
7. **Bilingual** - Georgian/English support via LanguageContext
8. **File Storage** - Media uploads to Supabase storage bucket

---

## Dependencies

```json
{
  "@tanstack/react-query": "^5.x",
  "@supabase/supabase-js": "^2.x",
  "date-fns": "^3.x",
  "lucide-react": "^0.x",
  "sonner": "^1.x",
  "xlsx": "^0.18.x"
}
```

**Shadcn/UI Components Used:**
- Card, Button, Input, Textarea, Badge
- Table, Tabs, Dialog, Popover, Calendar
- Select, Command, ScrollArea, Alert

---

## Notes for Replication

1. Set up Supabase project with tables from the SQL schema above
2. Create `housekeeping-media` storage bucket for file uploads
3. Enable realtime for `logistics_activity_log` table
4. Configure RLS policies for multi-user access
5. Implement LanguageContext for i18n support
