# Orbi City - Logistics Module Complete Documentation

## 📋 Overview

The Logistics Module is a comprehensive room and housekeeping management system for Orbi City Aparthotel in Batumi, Georgia. It manages 56 studio apartments across multiple buildings (A, C, D1, D2).

**Module URL**: `/logistics`

---

## 🏗️ Architecture

### Technology Stack
- **Frontend**: React + TypeScript + Vite
- **UI Framework**: Tailwind CSS + shadcn/ui
- **State Management**: TanStack Query (React Query)
- **Backend**: Supabase (PostgreSQL + Realtime)
- **File Storage**: Supabase Storage (`housekeeping-media` bucket)

### Component Structure
```
src/pages/Logistics.tsx                    # Main page with tabs
├── src/components/InventoryDashboardStats.tsx  # Dashboard with statistics
├── src/components/StudioInventoryList.tsx      # Room inventory management
├── src/components/HousekeepingModule.tsx       # Housekeeping schedules
├── src/components/MaintenanceModule.tsx        # Maintenance/repairs tracking
├── src/components/LogisticsActivityLog.tsx     # Activity history
├── src/hooks/useLogisticsActivity.ts           # Activity logging hook
└── src/hooks/useLogisticsRealtimeNotifications.ts  # Realtime notifications
```

---

## 🗄️ Database Schema

### 1. `rooms` Table
Stores all 56 studio apartments.

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| room_number | text | Room identifier (e.g., "A 1821", "C 2936") |
| user_id | uuid | Owner/creator ID |
| created_at | timestamp | Creation date |
| updated_at | timestamp | Last update |

**Room Numbers Pattern**:
- **Building A**: A 1033, A 1258, A 1301, A 1806, A 1821, A 1833, A 2035, A 2441, A 3035, A 3041, A 4022-A 4029, A 4035
- **Building C**: C 1256, C 2107, C 2520, C 2522, C 2524, C 2529, C 2547, C 2558, C 2609, C 2637, C 2641, C 2847, C 2861, C 2921, C 2923, C 2936, C 2947, C 2961, C 3421, C 3423, C 3425, C 3428, C 3431, C 3437, C 3439, C 3441, C 3611, C 3834, C 3928, C 3937, C 4011, C 4638, C 4704, C 4706
- **Building D1**: D1 3414, D1 3416, D1 3418
- **Building D2**: D2 3727

---

### 2. `standard_inventory_items` Table
Defines standard items that should be in every room.

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| category | text | Item category |
| item_name | text | Item name (Georgian) |
| standard_quantity | integer | Expected quantity per room |

**Categories & Items** (56 standard items):

#### აბაზანის აქსესუარები (Bathroom Accessories)
- აბაზანის სარკე (Bathroom mirror) - 1
- ნაგვის ურნა (Trash bin) - 1
- ნიჟარა შემრევით (Sink with mixer) - 1
- საშხაპე დუშითა და შემრევით (Shower with mixer) - 1
- საშხაპის აქსესუარი (Shower accessory) - 1
- ტუალეტის ქაღალდის საკიდი (Toilet paper holder) - 1
- უნიტაზი (Toilet) - 1
- უნიტაზის ჯაგრისი (Toilet brush) - 1
- ფენი (Hair dryer) - 1
- წყლის გამაცხელებელი (Water heater) - 1
- ხის კალათა (Wooden basket) - 1

#### ავეჯი და ტექსტილი (Furniture & Textile)
- აივნის მაგიდა (Balcony table) - 1
- აივნის სკამი (Balcony chair) - 4
- ბალიში (Pillow) - 3
- ბალიშის ჩიხოლი (Pillowcase) - 3
- დივანი გასაშლელი (Sofa bed) - 1
- ზეწარი (Sheet) - 2
- კარადა სარკით (Wardrobe with mirror) - 1
- ... (more items)

#### სამზარეულო (Kitchen)
- ჭიქა (Glass) - 5
- თეფში პატარა (Small plate) - 4
- თეფში დიდი (Large plate) - 4
- ჩანგალი (Fork) - 4
- დანა (Knife) - 4
- კოვზი (Spoon) - 4
- ... (more items)

#### ტექნიკა (Appliances)
- ტელევიზორი (TV) - 1
- კონდიციონერი (Air conditioner) - 1
- მაცივარი (Refrigerator) - 1
- მიკროტალღური ღუმელი (Microwave) - 1
- ელექტროქურა (Electric stove) - 1
- ... (more items)

---

### 3. `room_inventory_items` Table
Tracks actual item quantities in each room.

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| room_id | uuid | Reference to rooms table |
| standard_item_id | uuid | Reference to standard_inventory_items |
| actual_quantity | integer | Current quantity in room |
| condition | text | Item condition ("OK", "damaged", etc.) |
| last_checked | timestamp | Last inspection date |
| issue_detected_at | timestamp | When issue was found |
| issue_resolved_at | timestamp | When issue was resolved |
| notes | text | Additional notes |

---

### 4. `housekeeping_schedules` Table
Manages daily cleaning schedules.

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| user_id | uuid | Creator ID |
| scheduled_date | date | Cleaning date |
| rooms | text[] | Array of room numbers to clean |
| total_rooms | integer | Number of rooms |
| notes | text | Cleaner name or notes |
| status | text | "pending" or "completed" |
| completed_at | timestamp | Completion time |
| media_urls | text[] | Photos/evidence URLs |
| additional_notes | text | Extra comments |

---

### 5. `maintenance_schedules` Table
Tracks repairs and maintenance issues.

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| user_id | uuid | Creator ID |
| scheduled_date | date | Issue report date |
| room_number | text | Affected room |
| problem | text | Problem description |
| notes | text | Solution/action taken |
| status | text | "pending", "in_progress", "completed" |
| solving_date | date | Resolution date |
| cost | numeric | Repair cost in GEL (₾) |
| media_urls | text[] | Photo evidence |
| additional_notes | text | Extra comments |

---

### 6. `logistics_activity_log` Table
Audit trail of all changes.

| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| user_id | uuid | User who made change |
| user_email | text | User's email |
| action | text | "create", "update", "delete" |
| entity_type | text | Type of entity changed |
| entity_id | uuid | ID of changed entity |
| entity_name | text | Human-readable name |
| changes | jsonb | Details of changes |
| created_at | timestamp | When change occurred |

---

## 🔧 Features & Functionality

### 1. Dashboard (InventoryDashboardStats)
**Purpose**: Overview of all logistics metrics

**Statistics Displayed**:
- Total rooms (56)
- Rooms with complete inventory
- Rooms with missing items
- Housekeeping tasks (total/completed/pending)
- Maintenance tasks (total/completed/pending)
- Total maintenance costs

**Missing Items Analysis**:
- Groups missing items by category
- Groups missing items by room
- Shows which rooms need attention

**Realtime Updates**: Subscribes to changes in all tables

---

### 2. Inventory Management (StudioInventoryList)
**Purpose**: Manage individual room inventory

**Features**:
- Select specific room or view all rooms
- Check off items as present/missing
- Update quantities
- Track item condition
- Automatic initialization of new rooms

---

### 3. Housekeeping (HousekeepingModule)
**Purpose**: Schedule and track daily cleaning

**Workflow**:
1. Click "ახალი ჩანაწერი" (New Entry)
2. Select date
3. Multi-select rooms to clean (RoomMultiSelect component)
4. Add cleaner name in notes (e.g., "ნანა")
5. Save entry
6. Mark as completed when done
7. Upload photos as evidence

**Key Fields**:
- Date picker
- Multi-room selection
- Notes field
- Status toggle (pending/completed)
- File upload support

---

### 4. Maintenance (MaintenanceModule)
**Purpose**: Track repairs and technical issues

**Workflow**:
1. Add new maintenance entry
2. Select date, room, describe problem
3. Set status (pending/in_progress/completed)
4. Add cost when resolved
5. Upload photos before/after

**Key Fields**:
- Date (scheduled and solving date)
- Room selection
- Problem description
- Solution notes
- Cost in GEL (₾)
- Status management
- File uploads

---

### 5. Activity Log (LogisticsActivityLog)
**Purpose**: Audit trail of all changes

**Displays**:
- Who made the change (email)
- What action (create/update/delete)
- Which entity type
- When it happened
- Expandable change details (JSON)

---

## 📊 Current Data Summary (as of 2025-12-22)

### Rooms
- **Total**: 56 studios
- **Building A**: 18 rooms
- **Building C**: 34 rooms
- **Building D1**: 3 rooms
- **Building D2**: 1 room

### Housekeeping Schedules (Recent)
| Date | Rooms | Cleaner | Status |
|------|-------|---------|--------|
| 2025-12-20 | A 4023, A 4025, A 4022, A 4024, C 2921, C 2923 | ნანა | pending |
| 2025-12-19 | C 4706, C 4704, C 2529, C 3611, C 3937, D2 3727 | ნანა | completed |
| 2025-12-18 | A 1301, A 4029, A 4022, A 4024 | ნანა | completed |
| 2025-12-17 | A 4029, C 2861, C 4706, C 3937 | ნანა | completed |
| 2025-12-16 | C 3437, A 4027, C 2947, C 2609 | ნანა | completed |
| 2025-12-15 | C 4706, A 4026 | ნანა | completed |
| 2025-12-14 | A 4029, A 4027, C 2921, C 2947, C 3611, D2 3727 | ნანა | completed |
| 2025-12-13 | A 4026, A 1806, A 1301, A 4035 | ნანა | completed |
| 2025-12-12 | A 1301, A 4029, C 3425, C 3611, C 4704, C 4706, C 1256 | ნანა | completed |

### Maintenance Records (Recent)
| Date | Room | Problem | Cost (₾) | Status |
|------|------|---------|----------|--------|
| 2025-12-16 | C 3611 | საბარათე დაზიანდა (Card reader damaged) | 45 | completed |
| 2025-12-13 | C 2947 | გატყდა დუშის ყურმილი (Shower hose broken) | 8 | completed |
| 2025-12-12 | C 1256 | C837 საბარათე (Card reader) | 45 | completed |
| 2025-12-10 | C 1256 | შუქი არ ინთებოდა (Light not working) | 45 | completed |
| 2025-12-04 | A 1301 | დაჯდა კარის ელემენტი (Door element issue) | 20 | completed |
| 2025-12-03 | A 1033 | აივნის კარი არ იკეტება (Balcony door won't close) | 100 | completed |
| 2025-11-29 | C 4704 | დაიკარგა ბარათი (Card lost) | 20 | completed |
| 2025-11-22 | A 3035 | წყალი ჩადიოდა უნიტაზში (Toilet water leak) | 10 | completed |
| 2025-11-21 | A 3035 | რეგულატორი (Regulator issue) | 80 | completed |
| 2025-11-20 | A 2035 | ტვ პულტს ელემენტი არ ჰქონდა (TV remote battery) | 2 | completed |
| 2025-11-19 | A 3035 | დუშის შლანგი გაფუჭდა (Shower hose damaged) | 8 | completed |

**Total Maintenance Costs**: ~393 ₾ (for visible records)

---

## 🔄 Realtime Features

### Subscriptions
The module subscribes to these tables for live updates:
- `rooms` - Room changes
- `room_inventory_items` - Inventory updates
- `housekeeping_schedules` - Cleaning schedule changes
- `maintenance_schedules` - Repair status updates
- `logistics_activity_log` - New activity entries

### Notifications
When another user makes changes, toast notifications appear showing:
- Who made the change
- What action was taken
- Which entity was affected

---

## 🔐 Security (RLS Policies)

All tables have Row Level Security enabled:

- **rooms**: Anyone can view, insert, update, delete (public access)
- **standard_inventory_items**: Anyone can view/modify (public access)
- **room_inventory_items**: Anyone can view/modify (public access)
- **housekeeping_schedules**: Anyone can view/modify (public access)
- **maintenance_schedules**: Anyone can view/modify (public access)
- **logistics_activity_log**: Anyone can insert/view (no update/delete)

---

## 📱 User Interface

### Main Page Tabs
1. **დეშბორდი (Dashboard)** - Statistics overview
2. **ინვენტარი (Inventory)** - Room inventory management
3. **დასუფთავება (Housekeeping)** - Cleaning schedules
4. **ტექნიკური (Maintenance)** - Repair tracking
5. **აქტივობა (Activity)** - Change history

### Language Support
- Georgian (primary) 🇬🇪
- English 🇬🇧

### Status Badges
- **pending/მოლოდინში**: Outline variant
- **in_progress/მიმდინარე**: Secondary variant
- **completed/დასრულებული**: Default (primary) variant

---

## 📁 File Storage

**Bucket**: `housekeeping-media` (public)
**Path Pattern**: `{user_id}/{schedule_id}/{timestamp}.{extension}`

Used for:
- Before/after photos for housekeeping
- Damage evidence for maintenance
- Proof of work completion

---

## 🔗 Related Components

### RoomMultiSelect
Custom component for selecting multiple rooms from a searchable list.

### RoomInventoryTable
Displays inventory items for a specific room with edit capabilities.

### AllRoomsInventory
Shows inventory status across all 56 rooms simultaneously.

---

## 📝 Activity Log Format

```json
{
  "action": "create | update | delete",
  "entityType": "housekeeping_schedule | maintenance_schedule | room | inventory_item",
  "entityId": "uuid",
  "entityName": "human readable name",
  "changes": {
    "rooms": ["A 4023", "A 4025"],
    "notes": "ნანა",
    "status": "completed",
    "previous_status": "pending"
  }
}
```

---

## 🚀 Future Enhancements (Phase 2-3)

1. Cleaner assignment by room/building
2. Automated scheduling based on checkout dates
3. Inventory reorder alerts
4. Maintenance cost reporting by category
5. Mobile app for cleaners
6. QR code room check-in
7. Integration with OtelMS PMS

---

## 📞 Contact

**Project Owner**: Tamar Makharadze
**Location**: Orbi City, Batumi, Georgia
**Website**: www.orbicitybatumi.com
