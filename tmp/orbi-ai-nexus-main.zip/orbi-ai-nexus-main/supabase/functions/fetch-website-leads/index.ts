import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client for auth validation
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Verify user is authenticated
    const {
      data: { user },
      error: authError,
    } = await supabaseClient.auth.getUser();

    if (authError || !user) {
      console.error('Authentication error:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Fetching leads for user:', user.id);

    // TODO: Replace with actual orbi-sea-luxury API endpoint
    // This should be configured as a secret or environment variable
    const ORBI_SEA_LUXURY_API_URL = Deno.env.get('ORBI_SEA_LUXURY_API_URL') || 'https://your-api-endpoint.com/api/leads';
    const ORBI_SEA_LUXURY_API_KEY = Deno.env.get('ORBI_SEA_LUXURY_API_KEY');

    // Fetch leads from orbi-sea-luxury project
    const response = await fetch(ORBI_SEA_LUXURY_API_URL, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        ...(ORBI_SEA_LUXURY_API_KEY ? { 'Authorization': `Bearer ${ORBI_SEA_LUXURY_API_KEY}` } : {}),
      },
    });

    if (!response.ok) {
      console.error('API request failed:', response.status, response.statusText);
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    const leads = await response.json();
    console.log('Successfully fetched leads:', leads.length || 0);

    return new Response(
      JSON.stringify({ leads }),
      { 
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Error in fetch-website-leads function:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        details: 'Failed to fetch leads from orbi-sea-luxury API'
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
