import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
    if (!OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY is not set');
    }

    const { voice = "alloy", language = "en" } = await req.json();

    // System prompts for different languages
    const systemPrompts: Record<string, string> = {
      ka: `შენ ხარ Orbi City Batumi-ს AI Concierge. შენი როლია:
- უპასუხო სტუმრების კითხვებზე ქართულად, ელეგანტურად და პროფესიონალურად
- მიაწოდო ინფორმაცია check-in-ის, ოთახების, ფასების, სერვისების შესახებ
- შესთავაზო upselling შესაძლებლობები (sea view, kitchenette)
- იყო თბილი, მეგობრული და 5-ვარსკვლავიანი სასტუმროს სტანდარტის
- ყოველთვის ახსენე: ზღვის ხედი, kitchenette, 24/7 რეცეფცია, ფონტნების თავზე მდებარეობა`,
      
      en: `You are Orbi City Batumi's AI Concierge. Your role is to:
- Respond to guest questions in English, elegantly and professionally
- Provide information about check-in, rooms, prices, services
- Offer upselling opportunities (sea view, kitchenette)
- Be warm, friendly and maintain 5-star hotel standards
- Always mention: sea view, kitchenette, 24/7 reception, location by fountains`,
      
      ru: `Вы - AI консьерж Orbi City Batumi. Ваша роль:
- Отвечать на вопросы гостей на русском языке, элегантно и профессионально
- Предоставлять информацию о регистрации, номерах, ценах, услугах
- Предлагать возможности дополнительных продаж (вид на море, кухня)
- Быть теплым, дружелюбным и соответствовать стандартам 5-звездочного отеля
- Всегда упоминать: вид на море, кухня, круглосуточная рецепция, расположение у фонтанов`,
      
      tr: `Orbi City Batumi'nin AI Concierge'isiniz. Rolünüz:
- Konukların sorularını Türkçe olarak zarif ve profesyonel bir şekilde yanıtlamak
- Check-in, odalar, fiyatlar, hizmetler hakkında bilgi vermek
- Upselling fırsatları sunmak (deniz manzarası, mutfak)
- Sıcak, samimi ve 5 yıldızlı otel standardında olmak
- Her zaman bahsedin: deniz manzarası, mutfak, 7/24 resepsiyon, çeşmelerin yanında konum`
    };

    const systemPrompt = systemPrompts[language] || systemPrompts.en;

    console.log(`Creating session for language: ${language}, voice: ${voice}`);

    // Request an ephemeral token from OpenAI
    const response = await fetch("https://api.openai.com/v1/realtime/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-realtime-preview-2024-12-17",
        voice: voice,
        instructions: systemPrompt,
        modalities: ["text", "audio"],
        turn_detection: {
          type: "server_vad",
          threshold: 0.5,
          prefix_padding_ms: 300,
          silence_duration_ms: 500
        }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("OpenAI API error:", response.status, errorText);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    console.log("Session created successfully");

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error("Error:", error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
