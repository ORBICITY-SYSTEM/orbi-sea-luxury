import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function refreshAccessToken(refreshToken: string) {
  const GOOGLE_CLIENT_ID = Deno.env.get("GOOGLE_CLIENT_ID");
  const GOOGLE_CLIENT_SECRET = Deno.env.get("GOOGLE_CLIENT_SECRET");

  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: GOOGLE_CLIENT_ID!,
      client_secret: GOOGLE_CLIENT_SECRET!,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });

  if (!response.ok) {
    throw new Error("Failed to refresh access token");
  }

  return await response.json();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error("Failed to get user");
    }

    // Get tokens from database
    const { data: tokenData, error: tokenError } = await supabase
      .from("google_tokens")
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (tokenError || !tokenData) {
      throw new Error("Google account not connected");
    }

    // Use service role for decryption
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Decrypt tokens
    const { data: decryptedAccess, error: decAccessError } = await supabaseAdmin
      .rpc('decrypt_token', { encrypted_token: tokenData.access_token });
    
    const { data: decryptedRefresh, error: decRefreshError } = await supabaseAdmin
      .rpc('decrypt_token', { encrypted_token: tokenData.refresh_token });

    if (decAccessError || decRefreshError || !decryptedAccess || !decryptedRefresh) {
      console.error("Decryption error:", decAccessError || decRefreshError);
      throw new Error("Failed to decrypt tokens");
    }

    let accessToken = decryptedAccess;

    // Check if token is expired
    if (new Date(tokenData.expires_at) <= new Date()) {
      const newTokens = await refreshAccessToken(decryptedRefresh);
      accessToken = newTokens.access_token;

      // Encrypt and update tokens in database
      const { data: newEncryptedAccess } = await supabaseAdmin
        .rpc('encrypt_token', { token: accessToken });

      await supabase
        .from("google_tokens")
        .update({
          access_token: newEncryptedAccess,
          expires_at: new Date(Date.now() + newTokens.expires_in * 1000).toISOString(),
        })
        .eq("user_id", user.id);
    }

    // Fetch files from Google Drive
    const driveResponse = await fetch(
      "https://www.googleapis.com/drive/v3/files?pageSize=100&fields=files(id,name,mimeType,webViewLink,modifiedTime,size)",
      {
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );

    if (!driveResponse.ok) {
      throw new Error("Failed to fetch Drive files");
    }

    const driveData = await driveResponse.json();

    // Store files in database
    const filesToInsert = driveData.files.map((file: any) => ({
      user_id: user.id,
      file_id: file.id,
      name: file.name,
      mime_type: file.mimeType,
      web_view_link: file.webViewLink,
      modified_time: file.modifiedTime,
      size: file.size ? parseInt(file.size) : null,
    }));

    // Delete old files and insert new ones
    await supabase.from("google_drive_files").delete().eq("user_id", user.id);
    
    const { error: insertError } = await supabase
      .from("google_drive_files")
      .insert(filesToInsert);

    if (insertError) {
      console.error("Failed to store Drive files:", insertError);
      throw insertError;
    }

    return new Response(
      JSON.stringify({ success: true, count: driveData.files.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in google-drive-sync:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});