import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Channel detection patterns
const CHANNEL_PATTERNS = {
  'Booking.com': ['booking.com', '@booking.com', 'bookingcom'],
  'Airbnb': ['airbnb.com', '@airbnb.com', 'airbnb'],
  'Expedia': ['expedia.com', '@expedia.com', 'expedia'],
  'Agoda': ['agoda.com', '@agoda.com', 'agoda'],
  'Ostrovok': ['ostrovok.ru', '@ostrovok.ru', 'ostrovok'],
  'Bronevik': ['bronevik.com', '@bronevik.com', 'bronevik'],
  'Tvil': ['tvil.ru', '@tvil.ru', 'tvil'],
  'Sutochno': ['sutochno.ru', '@sutochno.ru', 'sutochno'],
  'HRS': ['hrs.com', '@hrs.com', 'hrs'],
};

function detectChannel(from: string, subject: string, body: string): string {
  const searchText = `${from} ${subject} ${body}`.toLowerCase();
  
  for (const [channel, patterns] of Object.entries(CHANNEL_PATTERNS)) {
    if (patterns.some(pattern => searchText.includes(pattern))) {
      return channel;
    }
  }
  
  return 'Other';
}

function extractEmailDate(dateString: string): string {
  try {
    const timestamp = parseInt(dateString);
    return new Date(timestamp).toISOString();
  } catch {
    return new Date().toISOString();
  }
}

function parseBasicBookingData(subject: string, body: string) {
  const result: any = {};
  
  // Extract dates (various formats)
  const datePatterns = [
    /check[- ]?in[:\s]+(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    /arrival[:\s]+(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    /from[:\s]+(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
  ];
  
  const checkoutPatterns = [
    /check[- ]?out[:\s]+(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    /departure[:\s]+(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    /to[:\s]+(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
  ];
  
  for (const pattern of datePatterns) {
    const match = body.match(pattern) || subject.match(pattern);
    if (match) {
      result.checkin = match[1];
      break;
    }
  }
  
  for (const pattern of checkoutPatterns) {
    const match = body.match(pattern) || subject.match(pattern);
    if (match) {
      result.checkout = match[1];
      break;
    }
  }
  
  // Extract amount
  const amountPattern = /(?:total|amount|price)[:\s]*€?\$?([0-9,]+\.?\d*)/i;
  const amountMatch = body.match(amountPattern) || subject.match(amountPattern);
  if (amountMatch) {
    result.amount = parseFloat(amountMatch[1].replace(/,/g, ''));
  }
  
  // Extract nights
  const nightsPattern = /(\d+)\s*night/i;
  const nightsMatch = body.match(nightsPattern) || subject.match(nightsPattern);
  if (nightsMatch) {
    result.nights = parseInt(nightsMatch[1]);
  }
  
  // Extract guest name
  const namePattern = /(?:guest|name|customer)[:\s]+([A-Z][a-z]+\s+[A-Z][a-z]+)/;
  const nameMatch = body.match(namePattern);
  if (nameMatch) {
    result.guest_name = nameMatch[1];
  }
  
  // Detect cancellation
  result.cancelled = /cancel|cancelled|cancellation/i.test(subject + body);
  
  return result;
}

async function parseWithGPT(subject: string, body: string, channel: string): Promise<any> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  if (!openaiKey) {
    console.log("OpenAI API key not configured, skipping GPT parsing");
    return null;
  }
  
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${openaiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a booking email parser. Extract structured data from ${channel} emails. Return ONLY valid JSON with these fields: checkin (YYYY-MM-DD), checkout (YYYY-MM-DD), nights (number), amount (number), currency (EUR/USD/GBP), guest_name, room_number, confirmation_code, cancelled (boolean). If a field is missing, omit it or use null.`
          },
          {
            role: "user",
            content: `Subject: ${subject}\n\nBody: ${body.substring(0, 2000)}`
          }
        ],
        temperature: 0.1,
        max_tokens: 300,
      }),
    });
    
    if (!response.ok) {
      console.error("GPT API error:", await response.text());
      return null;
    }
    
    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    if (content) {
      return JSON.parse(content);
    }
  } catch (error) {
    console.error("GPT parsing error:", error);
  }
  
  return null;
}

async function refreshAccessToken(refreshToken: string): Promise<string | null> {
  const clientId = Deno.env.get("GOOGLE_CLIENT_ID");
  const clientSecret = Deno.env.get("GOOGLE_CLIENT_SECRET");
  
  if (!clientId || !clientSecret) {
    throw new Error("Google OAuth credentials not configured");
  }
  
  try {
    const response = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
      }),
    });
    
    if (!response.ok) {
      console.error("Token refresh failed:", await response.text());
      return null;
    }
    
    const data = await response.json();
    return data.access_token;
  } catch (error) {
    console.error("Token refresh error:", error);
    return null;
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }
    
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );
    
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error("Failed to get user");
    }
    
    // Start sync log
    const { data: syncLog, error: syncLogError } = await supabase
      .from("sync_logs")
      .insert({ user_id: user.id, status: 'running' })
      .select()
      .single();
    
    if (syncLogError) {
      console.error("Failed to create sync log:", syncLogError);
    }
    
    // Get Google tokens
    const { data: tokens, error: tokenError } = await supabase
      .from("google_tokens")
      .select("*")
      .eq("user_id", user.id)
      .single();
    
    if (tokenError || !tokens) {
      throw new Error("Gmail not connected. Please connect your Gmail account first.");
    }
    
    let accessToken = tokens.access_token;
    
    // Check if token expired
    const expiresAt = new Date(tokens.expires_at);
    if (expiresAt <= new Date()) {
      console.log("Token expired, refreshing...");
      const newToken = await refreshAccessToken(tokens.refresh_token);
      if (!newToken) {
        throw new Error("Failed to refresh access token");
      }
      accessToken = newToken;
      
      // Update token in database
      await supabase
        .from("google_tokens")
        .update({
          access_token: newToken,
          expires_at: new Date(Date.now() + 3600 * 1000).toISOString(),
        })
        .eq("user_id", user.id);
    }
    
    // Fetch recent messages (last 30 days)
    const after = Math.floor((Date.now() - 30 * 24 * 60 * 60 * 1000) / 1000);
    const gmailResponse = await fetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=100&q=after:${after}`,
      {
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );
    
    if (!gmailResponse.ok) {
      throw new Error(`Gmail API error: ${await gmailResponse.text()}`);
    }
    
    const gmailData = await gmailResponse.json();
    const messages = gmailData.messages || [];
    
    let newBookings = 0;
    let updatedBookings = 0;
    const errors: any[] = [];
    
    for (const msg of messages) {
      try {
        // Fetch full message
        const msgResponse = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}`,
          {
            headers: { Authorization: `Bearer ${accessToken}` },
          }
        );
        
        if (!msgResponse.ok) continue;
        
        const fullMsg = await msgResponse.json();
        const headers = fullMsg.payload.headers;
        
        const from = headers.find((h: any) => h.name === "From")?.value || "";
        const subject = headers.find((h: any) => h.name === "Subject")?.value || "";
        const date = headers.find((h: any) => h.name === "Date")?.value || "";
        
        // Get email body
        let body = "";
        if (fullMsg.payload.body?.data) {
          body = atob(fullMsg.payload.body.data.replace(/-/g, '+').replace(/_/g, '/'));
        } else if (fullMsg.payload.parts) {
          const textPart = fullMsg.payload.parts.find((p: any) => 
            p.mimeType === "text/plain" || p.mimeType === "text/html"
          );
          if (textPart?.body?.data) {
            body = atob(textPart.body.data.replace(/-/g, '+').replace(/_/g, '/'));
          }
        }
        
        // Detect channel
        const channel = detectChannel(from, subject, body);
        
        // Skip if not OTA email
        if (channel === 'Other' && !/(booking|reservation|confirm|check-?in)/i.test(subject)) {
          continue;
        }
        
        // Parse basic data
        const basicData = parseBasicBookingData(subject, body);
        
        // Try GPT parsing for better accuracy
        const gptData = await parseWithGPT(subject, body, channel);
        
        // Merge data (GPT takes precedence)
        const bookingData = {
          ...basicData,
          ...(gptData || {}),
          channel,
          thread_id: fullMsg.threadId,
          message_id: msg.id,
          subject,
          email_received_at: extractEmailDate(fullMsg.internalDate),
          raw_payload: fullMsg,
          parsed_payload: gptData,
          parsed_by_gpt: !!gptData,
        };
        
        // Upsert booking
        const { error: upsertError } = await supabase
          .from("bookings")
          .upsert({
            user_id: user.id,
            ...bookingData,
          }, {
            onConflict: 'user_id,thread_id',
          });
        
        if (upsertError) {
          console.error("Upsert error:", upsertError);
          errors.push({ message_id: msg.id, error: upsertError.message });
        } else {
          newBookings++;
        }
        
      } catch (error) {
        console.error("Message processing error:", error);
        errors.push({ message_id: msg.id, error: error instanceof Error ? error.message : String(error) });
      }
    }
    
    // Update sync log
    if (syncLog) {
      await supabase
        .from("sync_logs")
        .update({
          finished_at: new Date().toISOString(),
          new_bookings: newBookings,
          updated_bookings: updatedBookings,
          status: errors.length > 0 ? 'completed' : 'completed',
          errors: errors.length > 0 ? errors : null,
        })
        .eq("id", syncLog.id);
    }
    
    return new Response(
      JSON.stringify({
        success: true,
        new_bookings: newBookings,
        updated_bookings: updatedBookings,
        errors: errors.length,
        total_processed: messages.length,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
    
  } catch (error) {
    console.error("Sync error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : String(error) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
