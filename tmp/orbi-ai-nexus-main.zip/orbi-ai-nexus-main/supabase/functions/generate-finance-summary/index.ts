import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { uploadId, moduleType, year, month } = await req.json();
    
    const authHeader = req.headers.get('Authorization')!;
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY');

    if (!lovableApiKey) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Check if this is a module instruction generation request
    if (moduleType && !uploadId) {
      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error('User not authenticated');

      // Generate instructions for specific module type
      const moduleDescriptions = {
        revenue: {
          title: 'შემოსავლების ანალიზი',
          description: 'შემოსავლების წყაროები, არხები, ტენდენციები და პროგნოზი',
        },
        expenses: {
          title: 'ხარჯების მართვა',
          description: 'ოპერაციული და ფიქსირებული ხარჯები, ოპტიმიზაციის შესაძლებლობები',
        },
        profit: {
          title: 'მოგების ანალიზი',
          description: 'ნეტო მოგება, ROI, პროფიტის მარჟა და გაუმჯობესების სფეროები',
        },
        analytics: {
          title: 'დეტალური ანალიტიკა',
          description: 'მონაცემთა ღრმა ანალიზი, კორელაციები და ინსაითები',
        },
      };

      const moduleInfo = moduleDescriptions[moduleType as keyof typeof moduleDescriptions];
      const georgianMonths = [
        'იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი',
        'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'
      ];

      const instructionPrompt = `
როგორც ფინანსური ანალიტიკოსი Orbi City Aparthotel-ისთვის, შექმენი **დეტალური ინსტრუქცია** AI-სთვის ${moduleInfo.title} მოდულის ანალიზისთვის.

📅 **პერიოდი:** ${georgianMonths[month - 1]} ${year}
📊 **მოდული:** ${moduleInfo.title}
🎯 **ფოკუსი:** ${moduleInfo.description}

გთხოვთ შექმნათ ინსტრუქცია რომელიც:

1. **კონკრეტული და აქციონებელია** - უთითებს ზუსტად რა უნდა გააანალიზოს AI-მ
2. **მონაცემზე დაფუძნებულია** - ფოკუსირდება ციფრებსა და მეტრიკებზე
3. **პრაქტიკულია** - გამოსადეგია რეალური ბიზნეს გადაწყვეტილებებისთვის
4. **კონტექსტურია** - ითვალისწინებს Orbi City-ს სპეციფიკას (Aparthotel, Batumi, საქართველო)

**ინსტრუქცია უნდა მოიცავდეს:**
- რა მეტრიკები უნდა გაანალიზდეს
- რა შედარებები უნდა გაკეთდეს
- რა რეკომენდაციები უნდა მომზადდეს
- როგორ უნდა წარმოდგენილ იქნას შედეგები

იყავით კონკრეტური და დაწერეთ ინსტრუქცია ისე, რომ AI-მ ზუსტად იცოდეს რა უნდა გააკეთოს.
`;

      // Call Lovable AI
      const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${lovableApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'google/gemini-2.5-flash',
          messages: [
            { 
              role: 'system', 
              content: 'You are a senior financial analyst specializing in hospitality industry analysis. Create detailed, actionable instructions in Georgian language.' 
            },
            { role: 'user', content: instructionPrompt }
          ],
        }),
      });

      if (!aiResponse.ok) {
        if (aiResponse.status === 429) {
          throw new Error('AI rate limit exceeded. Please try again later.');
        }
        if (aiResponse.status === 402) {
          throw new Error('AI credits exhausted. Please add credits to continue.');
        }
        const errorText = await aiResponse.text();
        console.error('AI API error:', aiResponse.status, errorText);
        throw new Error('AI service unavailable');
      }

      const aiData = await aiResponse.json();
      const instruction = aiData.choices[0].message.content;

      // Save the instruction to the database
      const { error: insertError } = await supabase
        .from('finance_analysis_instructions')
        .insert({
          user_id: user.id,
          title: `${moduleInfo.title} - ${georgianMonths[month - 1]} ${year}`,
          instruction_text: instruction,
          category: moduleType,
          is_active: true,
        });

      if (insertError) throw insertError;

      return new Response(
        JSON.stringify({ 
          success: true, 
          instruction,
          message: 'ინსტრუქცია წარმატებით შეიქმნა და დაემატა AI მემორიში',
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Original flow - fetch the upload data for summary generation
    if (!uploadId) {
      throw new Error('uploadId is required for summary generation');
    }

    const { data: upload, error: fetchError } = await supabase
      .from('monthly_analysis_uploads')
      .select('*')
      .eq('id', uploadId)
      .single();

    if (fetchError) throw fetchError;

    // Fetch active instructions from user
    const { data: instructions } = await supabase
      .from('finance_analysis_instructions')
      .select('*')
      .eq('user_id', upload.user_id)
      .eq('is_active', true)
      .order('created_at', { ascending: true });

    // Build instructions section for prompt
    let instructionsSection = '';
    if (instructions && instructions.length > 0) {
      instructionsSection = `\n\n🧠 **მემორი და სპეციალური ინსტრუქციები:**\n\n`;
      instructionsSection += instructions.map(inst => 
        `**${inst.title}** (${inst.category}):\n${inst.instruction_text}`
      ).join('\n\n');
      instructionsSection += `\n\n⚠️ გთხოვთ გაითვალისწინოთ ზემოთ მოცემული ინსტრუქციები ანალიზისას!\n`;
    }

    // Create Georgian month names
    const georgianMonths = [
      'იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი',
      'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'
    ];

    // Create prompt for AI analysis
    const prompt = `
თქვენ ხართ ფინანსური ანალიტიკოსი Orbi City Aparthotel-ისთვის ბათუმში. გააანალიზეთ შემდეგი თვიური მონაცემები:

📊 **${georgianMonths[upload.month - 1]} ${upload.year} - ძირითადი მეტრიკები:**

💰 **შემოსავალი და ფინანსები:**
- სულ შემოსავალი: ₾${upload.total_revenue?.toLocaleString()}
- RevPAR (Revenue Per Available Room): ₾${upload.revpar?.toFixed(2)}
- ADR (საშუალო ღამის ფასი): ₾${upload.adr?.toFixed(2)}

🏨 **დაკავება და ოპერაციები:**
- დაკავების მაჩვენებელი: ${upload.occupancy_rate?.toFixed(1)}%
- სულ ღამეები: ${upload.total_nights}
- სულ ბრონირებები: ${upload.total_bookings}
- ოთახების რაოდენობა: ${upload.total_rooms}
- საშუალო ყოფნის ხანგრძლივობა: ${upload.total_bookings ? (upload.total_nights / upload.total_bookings).toFixed(1) : 0} ღამე

---

გთხოვთ მოამზადოთ **დეტალური და პრაქტიკული ანალიზი** რომელიც მოიცავს:

## 📈 მიმოხილვა
რა არის ამ თვის ძირითადი შედეგები? როგორია ზოგადი სურათი?

## 💪 ძლიერი მხარეები
- რა წარმატებულად გამოვიდა ამ თვეში?
- რომელი მეტრიკები არის განსაკუთრებით კარგი?
- რა უნდა გავაგრძელოთ?

## ⚠️ გამოწვევები და საყურადღებო პუნქტები
- რომელი მეტრიკები საჭიროებს გაუმჯობესებას?
- რა პრობლემებია შესამჩნევი?
- სად ვკარგავთ პოტენციურ შემოსავალს?

## 🎯 კონკრეტული რეკომენდაციები შემდეგი თვისთვის
- **ფასების ოპტიმიზაცია:** როგორ გავზარდოთ ADR და RevPAR?
- **დაკავების გაზრდა:** რა სტრატეგიები გამოვიყენოთ დაბალი სეზონისთვის?
- **ოპერაციული ეფექტურობა:** როგორ გავაუმჯობესოთ guest experience?
- **მარკეტინგი:** სად ფოკუსირება უნდა მოხდეს?

${instructionsSection}

---

**მნიშვნელოვანი:**
- იყავით კონკრეტური და აქციონებელი - არა ზოგადი რჩევები
- გამოიყენეთ ციფრები და კონკრეტული მაგალითები
- ყველა რეკომენდაცია უნდა იყოს რეალისტური და შესრულებადი
- ფოკუსირება მოახდინეთ შემოსავლის გაზრდასა და guest satisfaction-ზე
`;

    // Call Lovable AI
    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { 
            role: 'system', 
            content: 'You are a senior financial analyst and hospitality consultant for Orbi City Aparthotel in Batumi, Georgia. Provide insightful, actionable, and data-driven analysis in Georgian language. Use emojis appropriately to make the report engaging.' 
          },
          { role: 'user', content: prompt }
        ],
      }),
    });

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        throw new Error('AI rate limit exceeded. Please try again later.');
      }
      if (aiResponse.status === 402) {
        throw new Error('AI credits exhausted. Please add credits to continue.');
      }
      const errorText = await aiResponse.text();
      console.error('AI API error:', aiResponse.status, errorText);
      throw new Error('AI service unavailable');
    }

    const aiData = await aiResponse.json();
    const summary = aiData.choices[0].message.content;

    // Update the record with AI summary
    const { error: updateError } = await supabase
      .from('monthly_analysis_uploads')
      .update({
        ai_summary_ka: summary,
        summary_generated_at: new Date().toISOString(),
      })
      .eq('id', uploadId);

    if (updateError) throw updateError;

    return new Response(
      JSON.stringify({ 
        success: true, 
        summary,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error generating summary:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});