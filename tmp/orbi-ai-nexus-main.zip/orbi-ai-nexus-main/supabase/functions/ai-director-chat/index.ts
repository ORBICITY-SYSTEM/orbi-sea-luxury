import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Input validation schema
const requestSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(['user', 'assistant', 'system']),
    content: z.string().min(1).max(10000)
  })).min(1).max(50),
  userId: z.string().uuid()
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authentication required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Parse and validate request body
    const body = await req.json();
    const validatedData = requestSchema.parse(body);

    // Verify userId matches authenticated user
    if (validatedData.userId !== user.id) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY not configured');
      return new Response(JSON.stringify({ error: 'Service configuration error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Initialize Supabase admin client for database operations
    const supabaseAdmin = createClient(
      supabaseUrl,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    console.log('AI Director Chat: Processing request for user', user.id);

    // Fetch business knowledge from database
    const { data: documents } = await supabaseAdmin
      .from('gpt_memory_documents')
      .select('title, content, category')
      .eq('user_id', user.id)
      .limit(10);

    // Build context from business knowledge
    let businessContext = '\n\n=== ბიზნეს ცოდნა და ინფორმაცია ===\n';
    if (documents && documents.length > 0) {
      documents.forEach(doc => {
        businessContext += `\n[${doc.category || 'საერთო'}] ${doc.title}:\n${doc.content}\n`;
      });
    } else {
      businessContext += '\nჯერ არ არის ატვირთული ბიზნეს ინფორმაცია. მომხმარებელმა უნდა დაამატოს ინფორმაცია GPT Memory Archive მოდულში.\n';
    }

    // Enhanced system prompt with business context
    const systemPrompt = `შენ ხარ Orbi City-ს AI Director - ინტელექტუალური ასისტენტი, რომელიც მართავს და ორგანიზებას უწევს სასტუმროს ოპერაციებს.

შენი როლი და შესაძლებლობები:
- 100% სიზუსტით იცნობ ბიზნესს, მის ყველა დეტალს და პროცესს
- ფიქრობ სტრატეგიულად და ყოველდღე აანალიზებ რა გააკეთო უკეთესად
- ახორციელებ თემატურ ჩატბოტებს სხვადასხვა სფეროში (review bot, finance bot, logistics bot)
- გასცემ კონკრეტულ და აქშენებულ რეკომენდაციებს
- დაგეგმავ შეხვედრებს, დავალებებს და აკონტროლებ მათ შესრულებას
- ჩატბოტები რომ შექმნი, ისინი უნდა იყვნენ სპეციალისტები თავიანთ სფეროში

Orbi City აღწერა:
- 57 სერვისირებული აპარტამენტი ბათუმში
- ოპერაციები: ოთახების მართვა, დასუფთავება, სტუმრებთან კომუნიკაცია, ფინანსები, მარკეტინგი
- მულტიარხიანი მხარდაჭერა (email, WhatsApp, Telegram, Facebook, OTA პლატფორმები)
- OTA პლატფორმები: Booking.com, Expedia, Agoda, Airbnb

5 მთავარი მოდული:
1. Orbi Logistics - დავალებების დაგეგმვა და დასუფთავება
2. Guest Communications - მრავალარხიანი მხარდაჭერა ავტო-პასუხებით
3. Finance Intelligence - შემოსავლების თვალთვალი და OTA შეჯერება
4. GPT Memory Archive - ცოდნის საცავი და SOP-ები
5. Marketing Control - კამპანიების მართვა და ანალიტიკა

მნიშვნელოვანი პრინციპები:
1. ყოველთვის დაყრდნობი ბიზნეს ცოდნაზე და კონტექსტზე რაც ქვემოთ არის მოცემული
2. უპასუხე ქართულად თუ ქართულად დაგწერეს, ინგლისურად თუ ინგლისურად
3. იყავი კონკრეტული და პრაქტიკული
4. როცა ახალ იდეებს გთავაზობ, აუცილებლად განმარტე რატომ
5. დაიმახსოვრე და გაითვალისწინე ყველა საუბარი

${businessContext}`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'openai/gpt-5',
        messages: [
          { role: 'system', content: systemPrompt },
          ...validatedData.messages
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      console.error('Lovable AI error:', response.status);
      return new Response(JSON.stringify({ error: 'AI service temporarily unavailable' }), {
        status: 503,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(response.body, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/event-stream',
      },
    });

  } catch (error) {
    console.error('AI Director Chat error:', error);
    
    // Handle validation errors
    if (error instanceof z.ZodError) {
      return new Response(JSON.stringify({ error: 'Invalid request data' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Generic error for all other cases
    return new Response(JSON.stringify({ error: 'An error occurred processing your request' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});