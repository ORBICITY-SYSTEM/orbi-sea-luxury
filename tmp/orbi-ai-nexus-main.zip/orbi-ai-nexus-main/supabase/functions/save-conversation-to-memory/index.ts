import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user from auth header
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    // Validate input
    const requestSchema = z.object({
      conversation: z.array(z.object({
        role: z.string(),
        content: z.string().max(10000)
      })).max(100),
      analysis: z.object({
        title: z.string().max(200),
        summary: z.string().max(5000),
        category: z.string().max(100).optional(),
        tags: z.array(z.string().max(50)).max(20).optional(),
        insights: z.array(z.string().max(500)).max(50).optional(),
        actionItems: z.array(z.object({
          title: z.string().max(200),
          description: z.string().max(1000).optional(),
          phase: z.string().max(50).optional(),
          priority: z.enum(['low', 'medium', 'high']).optional(),
          estimatedDays: z.number().int().min(0).max(365).optional()
        })).max(50).optional()
      }),
      createTasks: z.boolean().optional()
    });

    const body = await req.json();
    const validatedData = requestSchema.parse(body);
    const { conversation, analysis, createTasks = true } = validatedData;

    console.log('Saving conversation for user:', user.id);
    console.log('Analysis:', analysis);

    // Save conversation to saved_conversations
    const { data: savedConversation, error: saveError } = await supabase
      .from('saved_conversations')
      .insert({
        user_id: user.id,
        title: analysis.title,
        conversation_data: conversation,
        category: analysis.category,
        tags: analysis.tags || [],
        ai_summary: analysis.summary,
        action_items: analysis.actionItems || []
      })
      .select()
      .single();

    if (saveError) {
      console.error('Error saving conversation:', saveError);
      throw saveError;
    }

    console.log('Conversation saved:', savedConversation.id);

    // Save to GPT Memory Archive as well
    const { error: memoryError } = await supabase
      .from('gpt_memory_documents')
      .insert({
        user_id: user.id,
        title: analysis.title,
        content: JSON.stringify({
          conversation,
          summary: analysis.summary,
          insights: analysis.insights || []
        }),
        category: analysis.category,
        tags: analysis.tags || [],
        metadata: {
          conversation_id: savedConversation.id,
          task_count: analysis.actionItems?.length || 0
        }
      });

    if (memoryError) {
      console.error('Error saving to GPT Memory:', memoryError);
      // Non-fatal, continue
    }

    let createdTasks = [];

    // Create tasks if requested
    if (createTasks && analysis.actionItems && analysis.actionItems.length > 0) {
      console.log('Creating tasks:', analysis.actionItems.length);
      
      const tasksToInsert = analysis.actionItems.map((item: any, index: number) => ({
        user_id: user.id,
        title: item.title,
        description: item.description || '',
        phase: item.phase || 'Phase 1',
        priority: item.priority || 'medium',
        status: 'pending',
        progress: 0,
        conversation_id: savedConversation.id,
        created_by_ai: true,
        due_date: item.estimatedDays 
          ? new Date(Date.now() + item.estimatedDays * 24 * 60 * 60 * 1000).toISOString()
          : null
      }));

      const { data: tasks, error: tasksError } = await supabase
        .from('ai_director_tasks')
        .insert(tasksToInsert)
        .select();

      if (tasksError) {
        console.error('Error creating tasks:', tasksError);
        // Non-fatal, continue
      } else {
        createdTasks = tasks || [];
        console.log('Tasks created:', createdTasks.length);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      conversation: savedConversation,
      tasksCreated: createdTasks.length,
      tasks: createdTasks
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in save-conversation-to-memory:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});