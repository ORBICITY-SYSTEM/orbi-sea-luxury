import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Input validation schema
const requestSchema = z.object({
  conversation: z.array(z.object({
    role: z.string().min(1).max(50),
    content: z.string().min(1).max(10000)
  })).min(1).max(100),
  conversationTitle: z.string().min(1).max(255).optional()
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authentication required', success: false }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized', success: false }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Parse and validate request body
    const body = await req.json();
    const validatedData = requestSchema.parse(body);
    
    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!lovableApiKey) {
      console.error('LOVABLE_API_KEY not configured');
      return new Response(JSON.stringify({ error: 'Service configuration error', success: false }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // System prompt for task extraction
    const systemPrompt = `თქვენ ხართ AI ასისტენტი, რომელიც ანალიზს აკეთებს საუბრებს და გამოყოფს action items და tasks.

თქვენი დავალებაა:
1. წაიკითხოთ საუბარი
2. იდენტიფიცირეთ ყველა action item და task
3. კატეგორიზაცია phase-ების მიხედვით (Phase 1, Phase 2, და ა.შ.)
4. განსაზღვროთ პრიორიტეტები (low, medium, high, urgent)
5. დააკავშიროთ დამოკიდებული tasks ერთმანეთთან
6. შექმნათ timeline estimates

დააბრუნეთ JSON ფორმატით:
{
  "title": "საუბრის სათაური (მოკლე და აღწერილობითი)",
  "summary": "საუბრის შეჯამება (2-3 წინადადება)",
  "category": "Strategic Plans / System Design / Operations / Finance / Marketing",
  "tags": ["tag1", "tag2", "tag3"],
  "actionItems": [
    {
      "title": "დავალების სათაური",
      "description": "დეტალური აღწერა",
      "phase": "Phase 1",
      "priority": "high",
      "estimatedDays": 2,
      "dependencies": []
    }
  ],
  "insights": [
    "key insight 1",
    "key insight 2"
  ]
}

მნიშვნელოვანია:
- სათაურები უნდა იყოს ქართულად და კონკრეტული
- აღწერები უნდა შეიცავდეს technical details
- phase უნდა ემთხვეოდეს საუბარში ნახსენებ ფაზებს
- dependencies მხოლოდ იმ tasks-ის ინდექსები, რომლებზეც დამოკიდებულია`;

    const conversationText = validatedData.conversation.map((msg: any) => 
      `${msg.role === 'user' ? 'User' : 'AI Director'}: ${msg.content}`
    ).join('\n\n');

    console.log('Analyzing conversation for tasks for user:', user.id);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'openai/gpt-5',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `გთხოვ გააანალიზო ეს საუბარი და ამოიღო tasks:\n\n${conversationText}` }
        ],
        response_format: { type: "json_object" }
      }),
    });

    if (!response.ok) {
      console.error('Lovable AI error:', response.status);
      return new Response(JSON.stringify({ error: 'AI service temporarily unavailable', success: false }), {
        status: 503,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const aiResponse = await response.json();
    const analysisResult = JSON.parse(aiResponse.choices[0].message.content);

    console.log('Analysis complete');

    return new Response(JSON.stringify({
      success: true,
      analysis: analysisResult
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in extract-tasks-from-conversation:', error);
    
    // Handle validation errors
    if (error instanceof z.ZodError) {
      return new Response(JSON.stringify({ error: 'Invalid request data', success: false }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Generic error for all other cases
    return new Response(JSON.stringify({ error: 'An error occurred processing your request', success: false }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});