import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error("Failed to get user");
    }

    // Get tokens from database
    const { data: tokenData, error: tokenError } = await supabase
      .from("google_tokens")
      .select("access_token, refresh_token, expires_at")
      .eq("user_id", user.id)
      .maybeSingle();

    if (tokenError || !tokenData) {
      throw new Error("Gmail არ არის დაკავშირებული");
    }

    let accessToken = tokenData.access_token;

    // Check if token is expired and refresh if needed
    const expiresAt = new Date(tokenData.expires_at);
    if (expiresAt <= new Date()) {
      console.log("Token expired, refreshing...");

      const refreshResponse = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: Deno.env.get("GOOGLE_CLIENT_ID") ?? "",
          client_secret: Deno.env.get("GOOGLE_CLIENT_SECRET") ?? "",
          refresh_token: tokenData.refresh_token,
          grant_type: "refresh_token",
        }),
      });

      if (!refreshResponse.ok) {
        throw new Error("Failed to refresh token");
      }

      const refreshData = await refreshResponse.json();
      accessToken = refreshData.access_token;

      await supabase
        .from("google_tokens")
        .update({
          access_token: accessToken,
          expires_at: new Date(Date.now() + refreshData.expires_in * 1000).toISOString(),
        })
        .eq("user_id", user.id);
    }

    // Search for emails containing "review" keyword from 2025-01-01
    const after = new Date("2025-01-01").getTime() / 1000;
    const gmailResponse = await fetch(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages?q=review after:${Math.floor(after)}&maxResults=500`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!gmailResponse.ok) {
      const errorText = await gmailResponse.text();
      console.error("Gmail API error:", errorText);
      throw new Error("Failed to fetch messages from Gmail");
    }

    const { messages = [] } = await gmailResponse.json();

    if (messages.length === 0) {
      await supabase.from("review_import_logs").insert({
        user_id: user.id,
        source: "gmail",
        reviews_imported: 0,
        reviews_skipped: 0,
        status: "success",
      });

      return new Response(
        JSON.stringify({ success: true, imported: 0, skipped: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch full details for each message
    const detailedMessages = await Promise.all(
      messages.map(async (msg: { id: string }) => {
        const detailResponse = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}`,
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          }
        );
        return detailResponse.json();
      })
    );

    // Process and analyze each review
    let imported = 0;
    let skipped = 0;

    for (const msg of detailedMessages) {
      const headers = msg.payload?.headers || [];
      const getHeader = (name: string) =>
        headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase())?.value || "";

      const subject = getHeader("Subject");
      const from = getHeader("From");
      const date = getHeader("Date");
      const snippet = msg.snippet || "";

      // Extract review body from message
      let reviewBody = snippet;
      if (msg.payload?.parts) {
        const textPart = msg.payload.parts.find((p: any) => p.mimeType === "text/plain");
        if (textPart?.body?.data) {
          reviewBody = atob(textPart.body.data.replace(/-/g, '+').replace(/_/g, '/'));
        }
      } else if (msg.payload?.body?.data) {
        reviewBody = atob(msg.payload.body.data.replace(/-/g, '+').replace(/_/g, '/'));
      }

      // Call AI to analyze sentiment and extract details
      const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
      const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            {
              role: "system",
              content: "You are analyzing guest reviews. Extract: language (ka/en/ru/tr/uk/other), sentiment (positive/neutral/negative), stars (1-5), guest_name, apartment_code if mentioned, topics array from: cleanliness, checkin, location, equipment, noise, view, service, price. Return ONLY valid JSON.",
            },
            {
              role: "user",
              content: `Subject: ${subject}\nFrom: ${from}\nBody: ${reviewBody}`,
            },
          ],
          tools: [{
            type: "function",
            function: {
              name: "analyze_review",
              description: "Analyze guest review",
              parameters: {
                type: "object",
                properties: {
                  language: { type: "string", enum: ["ka", "en", "ru", "tr", "uk", "other"] },
                  sentiment: { type: "string", enum: ["positive", "neutral", "negative"] },
                  stars: { type: "integer", minimum: 1, maximum: 5 },
                  guest_name: { type: "string" },
                  apartment_code: { type: "string" },
                  topics: {
                    type: "array",
                    items: {
                      type: "string",
                      enum: ["cleanliness", "checkin", "location", "equipment", "noise", "view", "service", "price"]
                    }
                  }
                },
                required: ["language", "sentiment", "stars", "topics"],
                additionalProperties: false
              }
            }
          }],
          tool_choice: { type: "function", function: { name: "analyze_review" } }
        }),
      });

      let analysis: any = {
        language: "other",
        sentiment: "neutral",
        stars: 3,
        topics: [],
      };

      if (aiResponse.ok) {
        const aiData = await aiResponse.json();
        const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
        if (toolCall?.function?.arguments) {
          try {
            analysis = JSON.parse(toolCall.function.arguments);
          } catch (e) {
            console.error("Failed to parse AI response:", e);
          }
        }
      }

      // Insert review into database
      const { error: insertError } = await supabase
        .from("guest_reviews")
        .insert({
          user_id: user.id,
          source: "gmail",
          review_date: new Date(date || Date.now()).toISOString(),
          guest_name: analysis.guest_name || from.split("<")[0].trim(),
          from_email: from,
          apartment_code: analysis.apartment_code,
          language: analysis.language,
          stars: analysis.stars,
          review_title: subject,
          review_body: reviewBody,
          sentiment: analysis.sentiment,
          topics: analysis.topics,
          reply_status: "new",
          source_message_id: msg.id,
        });

      if (insertError) {
        if (insertError.code === "23505") {
          skipped++;
        } else {
          console.error("Insert error:", insertError);
          skipped++;
        }
      } else {
        imported++;
      }
    }

    // Log import
    await supabase.from("review_import_logs").insert({
      user_id: user.id,
      source: "gmail",
      reviews_imported: imported,
      reviews_skipped: skipped,
      status: "success",
    });

    console.log(`✅ Imported ${imported} reviews, skipped ${skipped} duplicates`);

    return new Response(
      JSON.stringify({ success: true, imported, skipped }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in import-gmail-reviews:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
