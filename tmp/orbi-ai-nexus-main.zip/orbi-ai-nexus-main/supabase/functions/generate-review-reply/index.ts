import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { reviewId } = await req.json();

    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error("Failed to get user");
    }

    // Get review details
    const { data: review, error: reviewError } = await supabase
      .from("guest_reviews")
      .select("*")
      .eq("id", reviewId)
      .eq("user_id", user.id)
      .single();

    if (reviewError || !review) {
      throw new Error("Review not found");
    }

    // Generate AI reply based on sentiment and language
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    const systemPrompt = `You are the customer service manager for Orbi City Aparthotel in Batumi, Georgia. Generate a professional, warm reply to guest reviews. 

Key details to mention when relevant:
- Sea view apartments with kitchenette
- 24/7 reception service
- Location by Dancing Fountains
- Premium 5-star service

Tone guidelines:
- ${review.language === 'ka' ? 'Georgian: refined, polite, warm' : ''}
- ${review.language === 'en' ? 'English: modern, premium-hotel style' : ''}
- ${review.language === 'ru' ? 'Russian: culturally neutral, respectful' : ''}
- ${review.language === 'tr' ? 'Turkish: culturally neutral, respectful' : ''}
- For positive reviews: express gratitude + gentle invitation to book directly next time
- For negative reviews: empathy + quick solution offer, never excuses

Reply in ${review.language === 'ka' ? 'Georgian' : review.language === 'ru' ? 'Russian' : review.language === 'tr' ? 'Turkish' : review.language === 'uk' ? 'Ukrainian' : 'English'} language.
Keep reply under 150 words.`;

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          {
            role: "user",
            content: `Guest: ${review.guest_name || 'Anonymous'}\nRating: ${review.stars}/5\nReview: ${review.review_body}\nSentiment: ${review.sentiment}\nTopics: ${review.topics?.join(', ') || 'none'}`,
          },
        ],
      }),
    });

    if (!aiResponse.ok) {
      throw new Error("Failed to generate AI reply");
    }

    const aiData = await aiResponse.json();
    const generatedReply = aiData.choices?.[0]?.message?.content || "";

    // Update review with generated reply
    const { error: updateError } = await supabase
      .from("guest_reviews")
      .update({
        ai_generated_reply: generatedReply,
        reply_status: "drafted",
      })
      .eq("id", reviewId)
      .eq("user_id", user.id);

    if (updateError) {
      throw updateError;
    }

    console.log(`✅ Generated reply for review ${reviewId}`);

    return new Response(
      JSON.stringify({ success: true, reply: generatedReply }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in generate-review-reply:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
