import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user from auth header
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    // Validate input
    const requestSchema = z.object({
      query: z.string().max(500).optional(),
      category: z.string().max(100).optional(),
      limit: z.number().int().min(1).max(100).optional()
    });

    const body = await req.json();
    const validatedData = requestSchema.parse(body);
    const { query, category, limit = 5 } = validatedData;

    console.log('Recalling conversations for user:', user.id, 'query:', query);

    let dbQuery = supabase
      .from('saved_conversations')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (category) {
      dbQuery = dbQuery.eq('category', category);
    }

    if (query) {
      // Search in title, summary, and tags
      dbQuery = dbQuery.or(`title.ilike.%${query}%,ai_summary.ilike.%${query}%,tags.cs.{${query}}`);
    }

    const { data: conversations, error } = await dbQuery.limit(limit);

    if (error) {
      console.error('Error fetching conversations:', error);
      throw error;
    }

    console.log('Found conversations:', conversations?.length || 0);

    // For each conversation, get associated tasks
    const conversationsWithTasks = await Promise.all(
      (conversations || []).map(async (conv) => {
        const { data: tasks } = await supabase
          .from('ai_director_tasks')
          .select('*')
          .eq('conversation_id', conv.id)
          .order('created_at', { ascending: true });

        return {
          ...conv,
          tasks: tasks || [],
          tasksCompleted: tasks?.filter(t => t.status === 'completed').length || 0,
          tasksTotal: tasks?.length || 0
        };
      })
    );

    return new Response(JSON.stringify({
      success: true,
      conversations: conversationsWithTasks,
      count: conversationsWithTasks.length
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in recall-conversation:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});