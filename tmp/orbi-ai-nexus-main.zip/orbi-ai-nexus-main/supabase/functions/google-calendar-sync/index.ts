import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function refreshAccessToken(refreshToken: string) {
  const GOOGLE_CLIENT_ID = Deno.env.get("GOOGLE_CLIENT_ID");
  const GOOGLE_CLIENT_SECRET = Deno.env.get("GOOGLE_CLIENT_SECRET");

  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: GOOGLE_CLIENT_ID!,
      client_secret: GOOGLE_CLIENT_SECRET!,
      refresh_token: refreshToken,
      grant_type: "refresh_token",
    }),
  });

  if (!response.ok) {
    throw new Error("Failed to refresh access token");
  }

  return await response.json();
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      throw new Error("Failed to get user");
    }

    // Get tokens from database
    const { data: tokenData, error: tokenError } = await supabase
      .from("google_tokens")
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (tokenError || !tokenData) {
      throw new Error("Google account not connected");
    }

    // Use service role for decryption
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Decrypt tokens
    const { data: decryptedAccess, error: decAccessError } = await supabaseAdmin
      .rpc('decrypt_token', { encrypted_token: tokenData.access_token });
    
    const { data: decryptedRefresh, error: decRefreshError } = await supabaseAdmin
      .rpc('decrypt_token', { encrypted_token: tokenData.refresh_token });

    if (decAccessError || decRefreshError || !decryptedAccess || !decryptedRefresh) {
      console.error("Decryption error:", decAccessError || decRefreshError);
      throw new Error("Failed to decrypt tokens");
    }

    let accessToken = decryptedAccess;

    // Check if token is expired
    if (new Date(tokenData.expires_at) <= new Date()) {
      const newTokens = await refreshAccessToken(decryptedRefresh);
      accessToken = newTokens.access_token;

      // Encrypt and update tokens in database
      const { data: newEncryptedAccess } = await supabaseAdmin
        .rpc('encrypt_token', { token: accessToken });

      await supabase
        .from("google_tokens")
        .update({
          access_token: newEncryptedAccess,
          expires_at: new Date(Date.now() + newTokens.expires_in * 1000).toISOString(),
        })
        .eq("user_id", user.id);
    }

    // Fetch events from Google Calendar
    const now = new Date();
    const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    
    const calendarResponse = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${oneMonthAgo.toISOString()}&maxResults=50&singleEvents=true&orderBy=startTime`,
      {
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );

    if (!calendarResponse.ok) {
      throw new Error("Failed to fetch Calendar events");
    }

    const calendarData = await calendarResponse.json();

    if (!calendarData.items || calendarData.items.length === 0) {
      return new Response(
        JSON.stringify({ success: true, count: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse and store events
    const eventsToInsert = calendarData.items.map((event: any) => ({
      user_id: user.id,
      event_id: event.id,
      summary: event.summary || "No title",
      description: event.description || null,
      location: event.location || null,
      start_time: event.start.dateTime || event.start.date,
      end_time: event.end.dateTime || event.end.date,
    }));

    // Delete old events and insert new ones
    await supabase.from("google_calendar_events").delete().eq("user_id", user.id);
    
    const { error: insertError } = await supabase
      .from("google_calendar_events")
      .insert(eventsToInsert);

    if (insertError) {
      console.error("Failed to store Calendar events:", insertError);
      throw insertError;
    }

    return new Response(
      JSON.stringify({ success: true, count: eventsToInsert.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in google-calendar-sync:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});