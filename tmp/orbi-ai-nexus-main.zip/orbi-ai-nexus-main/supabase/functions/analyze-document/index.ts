import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Input validation schema
const requestSchema = z.object({
  fileContent: z.string().min(1).max(100000), // 100KB max
  fileName: z.string().min(1).max(255),
  fileType: z.string().min(1).max(100),
  userId: z.string().uuid()
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authentication required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } }
    });

    // Verify user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Parse and validate request body
    const body = await req.json();
    const validatedData = requestSchema.parse(body);

    // Verify userId matches authenticated user
    if (validatedData.userId !== user.id) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      console.error('LOVABLE_API_KEY not configured');
      return new Response(JSON.stringify({ error: 'Service configuration error' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('Analyzing document:', validatedData.fileName, 'for user:', user.id);

    // Process content based on file type
    let processedContent = validatedData.fileContent;
    
    // Handle Excel files (base64 encoded)
    if (validatedData.fileName.toLowerCase().endsWith('.xlsx') || validatedData.fileName.toLowerCase().endsWith('.xls')) {
      console.log('Processing Excel file');
      processedContent = `Excel File: ${validatedData.fileName}\n\nNote: This is an Excel file. The AI will analyze the structure and data patterns based on the file information provided.`;
    }
    
    // Handle JSON files
    if (validatedData.fileName.toLowerCase().endsWith('.json') || validatedData.fileType === 'application/json') {
      console.log('Processing JSON file');
      try {
        const jsonData = typeof validatedData.fileContent === 'string' ? JSON.parse(validatedData.fileContent) : validatedData.fileContent;
        processedContent = `JSON Data:\n\n${JSON.stringify(jsonData, null, 2)}`;
      } catch (e) {
        console.error('Failed to parse JSON:', e);
        processedContent = validatedData.fileContent;
      }
    }

    // Handle Google Links
    if (validatedData.fileType === 'application/link') {
      console.log('Processing link:', validatedData.fileName);
      processedContent = `${validatedData.fileContent}\n\nTitle: ${validatedData.fileName}`;
    }

    // Prepare analysis prompt - limit to 50000 chars
    const limitedContent = processedContent.substring(0, 50000);
    
    const analysisPrompt = `შენ ხარ Orbi City-ს AI Director - პროფესიონალი ანალიტიკოსი და სტრატეგი.

დაანალიზე შემდეგი შინაარსი და მოამზადე სტრუქტურირებული ანალიზი:

=== ფაილის სახელი ===
${validatedData.fileName}

=== ფაილის ტიპი ===
${validatedData.fileType}

=== შინაარსი ===
${limitedContent} 

=== დავალება ===
გააკეთე შემდეგი ანალიზი:

1. **სათაური** - შექმენი შინაარსის შესაბამისი, კონკრეტული სათაური (მაქს. 100 სიმბოლო)
2. **კატეგორია** - განსაზღვრე ერთი კატეგორია: "ფინანსები", "ლოჯისტიკა", "მარკეტინგი", "სტუმრები", "SOP", "ტექნიკური", "საერთო" ან სხვა შესაფერისი
3. **მთავარი შინაარსი** - მოკლე, ფაქტობრივი შეჯამება (150-300 სიტყვა)
4. **AI Director-ის ანალიზი**:
   - **რა მოსწონს** ✅ - პოზიტიური ასპექტები (2-3 პუნქტი)
   - **რა არ მოსწონს** ⚠️ - პრობლემები და რისკები (2-3 პუნქტი)
   - **რეკომენდაციები** 💡 - კონკრეტული, აქშენებული რჩევები (3-5 პუნქტი)
   - **სწრაფი Tips** ⚡ - მოკლე, პრაქტიკული რჩევები (2-3 პუნქტი)

უპასუხე JSON ფორმატში:
{
  "title": "...",
  "category": "...",
  "summary": "...",
  "ai_analysis": {
    "pros": ["...", "..."],
    "cons": ["...", "..."],
    "recommendations": ["...", "...", "..."],
    "quick_tips": ["...", "..."]
  }
}

ᲛᲜᲘᲨᲕᲜᲔᲚᲝᲕᲐᲜᲘ:
- იყავი კონკრეტული და პრაქტიკული
- რეკომენდაციები უნდა იყოს აქშენებული და განხორციელებადი
- დააფასე რეალური ბიზნეს იმპაქტი
- თუ შინაარსი არ არის ქართულად, მაინც უპასუხე ქართულად
- JSON/Excel/Google ფაილებისთვის გააანალიზე სტრუქტურა და მონაცემები`;

    // Call Lovable AI for analysis
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'openai/gpt-5',
        messages: [
          { role: 'user', content: analysisPrompt }
        ]
      }),
    });

    if (!response.ok) {
      console.error('Lovable AI error:', response.status);
      return new Response(JSON.stringify({ error: 'AI service temporarily unavailable' }), {
        status: 503,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const aiResponse = await response.json();
    const analysisText = aiResponse.choices[0].message.content;
    console.log('AI Analysis received');

    let analysis;
    try {
      analysis = JSON.parse(analysisText);
    } catch (e) {
      console.error('Failed to parse AI response as JSON');
      return new Response(JSON.stringify({ error: 'Invalid AI response format' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Save to database using service role
    const supabaseAdmin = createClient(
      supabaseUrl,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { data: document, error: dbError } = await supabaseAdmin
      .from('gpt_memory_documents')
      .insert({
        user_id: user.id,
        title: analysis.title,
        category: analysis.category,
        content: analysis.summary,
        ai_analysis: analysis.ai_analysis,
        file_name: validatedData.fileName,
        file_type: validatedData.fileType,
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
      return new Response(JSON.stringify({ error: 'Failed to save document' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('Document saved successfully:', document.id);

    return new Response(
      JSON.stringify({ 
        success: true, 
        document,
        analysis 
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Document analysis error:', error);
    
    // Handle validation errors
    if (error instanceof z.ZodError) {
      return new Response(JSON.stringify({ error: 'Invalid request data', success: false }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Generic error for all other cases
    return new Response(JSON.stringify({ error: 'An error occurred processing your request', success: false }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});