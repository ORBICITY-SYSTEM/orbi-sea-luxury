-- Drop existing user-specific RLS policies for Logistics tables
DROP POLICY IF EXISTS "Users can view their own rooms" ON public.rooms;
DROP POLICY IF EXISTS "Users can insert their own rooms" ON public.rooms;
DROP POLICY IF EXISTS "Users can update their own rooms" ON public.rooms;
DROP POLICY IF EXISTS "Users can delete their own rooms" ON public.rooms;

DROP POLICY IF EXISTS "Users can view room inventory for their rooms" ON public.room_inventory_items;
DROP POLICY IF EXISTS "Users can insert room inventory for their rooms" ON public.room_inventory_items;
DROP POLICY IF EXISTS "Users can update room inventory for their rooms" ON public.room_inventory_items;
DROP POLICY IF EXISTS "Users can delete room inventory for their rooms" ON public.room_inventory_items;

DROP POLICY IF EXISTS "Users can view their own room descriptions" ON public.room_inventory_descriptions;
DROP POLICY IF EXISTS "Users can insert their own room descriptions" ON public.room_inventory_descriptions;
DROP POLICY IF EXISTS "Users can update their own room descriptions" ON public.room_inventory_descriptions;
DROP POLICY IF EXISTS "Users can delete their own room descriptions" ON public.room_inventory_descriptions;

DROP POLICY IF EXISTS "Users can view their own housekeeping schedules" ON public.housekeeping_schedules;
DROP POLICY IF EXISTS "Users can create their own housekeeping schedules" ON public.housekeeping_schedules;
DROP POLICY IF EXISTS "Users can update their own housekeeping schedules" ON public.housekeeping_schedules;
DROP POLICY IF EXISTS "Users can delete their own housekeeping schedules" ON public.housekeeping_schedules;

DROP POLICY IF EXISTS "Users can view their own maintenance schedules" ON public.maintenance_schedules;
DROP POLICY IF EXISTS "Users can create their own maintenance schedules" ON public.maintenance_schedules;
DROP POLICY IF EXISTS "Users can update their own maintenance schedules" ON public.maintenance_schedules;
DROP POLICY IF EXISTS "Users can delete their own maintenance schedules" ON public.maintenance_schedules;

-- Create new public shared access policies for rooms
CREATE POLICY "Anyone can view all rooms"
ON public.rooms FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Anyone can insert rooms"
ON public.rooms FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Anyone can update all rooms"
ON public.rooms FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Anyone can delete all rooms"
ON public.rooms FOR DELETE
TO authenticated
USING (true);

-- Create new public shared access policies for room_inventory_items
CREATE POLICY "Anyone can view all room inventory"
ON public.room_inventory_items FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Anyone can insert room inventory"
ON public.room_inventory_items FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Anyone can update all room inventory"
ON public.room_inventory_items FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Anyone can delete all room inventory"
ON public.room_inventory_items FOR DELETE
TO authenticated
USING (true);

-- Create new public shared access policies for room_inventory_descriptions
CREATE POLICY "Anyone can view all room descriptions"
ON public.room_inventory_descriptions FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Anyone can insert room descriptions"
ON public.room_inventory_descriptions FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Anyone can update all room descriptions"
ON public.room_inventory_descriptions FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Anyone can delete all room descriptions"
ON public.room_inventory_descriptions FOR DELETE
TO authenticated
USING (true);

-- Create new public shared access policies for housekeeping_schedules
CREATE POLICY "Anyone can view all housekeeping schedules"
ON public.housekeeping_schedules FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Anyone can create housekeeping schedules"
ON public.housekeeping_schedules FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Anyone can update all housekeeping schedules"
ON public.housekeeping_schedules FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Anyone can delete all housekeeping schedules"
ON public.housekeeping_schedules FOR DELETE
TO authenticated
USING (true);

-- Create new public shared access policies for maintenance_schedules
CREATE POLICY "Anyone can view all maintenance schedules"
ON public.maintenance_schedules FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Anyone can create maintenance schedules"
ON public.maintenance_schedules FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Anyone can update all maintenance schedules"
ON public.maintenance_schedules FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Anyone can delete all maintenance schedules"
ON public.maintenance_schedules FOR DELETE
TO authenticated
USING (true);