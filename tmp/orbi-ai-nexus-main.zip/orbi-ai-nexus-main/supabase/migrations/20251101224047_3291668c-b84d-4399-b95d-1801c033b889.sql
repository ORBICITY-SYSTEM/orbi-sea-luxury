-- Enable pgsodium extension for encryption (should already be enabled in Supabase)
-- This migration encrypts Google OAuth tokens using Supabase Vault

-- Step 1: Add encrypted columns for tokens
ALTER TABLE google_tokens 
  ADD COLUMN IF NOT EXISTS access_token_encrypted TEXT,
  ADD COLUMN IF NOT EXISTS refresh_token_encrypted TEXT;

-- Step 2: Create security definer function to encrypt and store tokens
CREATE OR REPLACE FUNCTION public.store_google_tokens(
  p_user_id UUID,
  p_access_token TEXT,
  p_refresh_token TEXT,
  p_expires_at TIMESTAMPTZ
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_token_id UUID;
  v_access_secret_id UUID;
  v_refresh_secret_id UUID;
BEGIN
  -- Create secrets in vault for access token
  INSERT INTO vault.secrets (secret)
  VALUES (p_access_token)
  RETURNING id INTO v_access_secret_id;
  
  -- Create secrets in vault for refresh token (if provided)
  IF p_refresh_token IS NOT NULL THEN
    INSERT INTO vault.secrets (secret)
    VALUES (p_refresh_token)
    RETURNING id INTO v_refresh_secret_id;
  END IF;
  
  -- Upsert token record
  INSERT INTO google_tokens (user_id, access_token_encrypted, refresh_token_encrypted, expires_at, access_token, refresh_token)
  VALUES (
    p_user_id,
    v_access_secret_id::TEXT,
    v_refresh_secret_id::TEXT,
    p_expires_at,
    '', -- Keep empty for backward compatibility during migration
    ''
  )
  ON CONFLICT (user_id)
  DO UPDATE SET
    access_token_encrypted = v_access_secret_id::TEXT,
    refresh_token_encrypted = v_refresh_secret_id::TEXT,
    expires_at = p_expires_at,
    updated_at = now()
  RETURNING id INTO v_token_id;
  
  RETURN v_token_id;
END;
$$;

-- Step 3: Create security definer function to retrieve decrypted tokens
CREATE OR REPLACE FUNCTION public.get_google_tokens(p_user_id UUID)
RETURNS TABLE (
  access_token TEXT,
  refresh_token TEXT,
  expires_at TIMESTAMPTZ
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(
      (SELECT decrypted_secret FROM vault.decrypted_secrets WHERE id = gt.access_token_encrypted::UUID),
      gt.access_token
    ) as access_token,
    COALESCE(
      (SELECT decrypted_secret FROM vault.decrypted_secrets WHERE id = gt.refresh_token_encrypted::UUID),
      gt.refresh_token
    ) as refresh_token,
    gt.expires_at
  FROM google_tokens gt
  WHERE gt.user_id = p_user_id;
END;
$$;

-- Step 4: Grant necessary permissions
GRANT EXECUTE ON FUNCTION public.store_google_tokens TO authenticated;
GRANT EXECUTE ON FUNCTION public.get_google_tokens TO authenticated;

-- Step 5: Add comments for documentation
COMMENT ON FUNCTION public.store_google_tokens IS 'Securely stores Google OAuth tokens using Supabase Vault encryption';
COMMENT ON FUNCTION public.get_google_tokens IS 'Retrieves and decrypts Google OAuth tokens for authenticated user';
COMMENT ON TABLE google_tokens IS 'OAuth tokens - RLS protected with Vault encryption. Use store_google_tokens() and get_google_tokens() functions for access';

-- Step 6: Update indexes for performance
CREATE INDEX IF NOT EXISTS idx_google_tokens_encrypted_user ON google_tokens(user_id) WHERE access_token_encrypted IS NOT NULL;