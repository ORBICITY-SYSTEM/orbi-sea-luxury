-- Fix function search path for security (with CASCADE)
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Recreate triggers
CREATE TRIGGER update_gpt_memory_documents_updated_at
  BEFORE UPDATE ON public.gpt_memory_documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_ai_director_tasks_updated_at
  BEFORE UPDATE ON public.ai_director_tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();