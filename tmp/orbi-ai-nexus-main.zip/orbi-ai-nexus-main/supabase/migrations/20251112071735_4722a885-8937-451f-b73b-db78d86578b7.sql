-- Add finance role to app_role enum if it doesn't exist
DO $$ 
BEGIN
  ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'finance';
END $$;