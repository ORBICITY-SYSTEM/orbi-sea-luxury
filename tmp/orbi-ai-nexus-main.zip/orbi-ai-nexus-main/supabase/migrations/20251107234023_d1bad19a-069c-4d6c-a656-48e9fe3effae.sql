-- Add expiration_date column to api_integrations table
ALTER TABLE public.api_integrations
ADD COLUMN expiration_date DATE,
ADD COLUMN last_used_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN notification_sent BOOLEAN DEFAULT false;