-- Add AI analysis column to gpt_memory_documents
ALTER TABLE public.gpt_memory_documents
ADD COLUMN IF NOT EXISTS ai_analysis JSONB;

-- Add file info columns
ALTER TABLE public.gpt_memory_documents
ADD COLUMN IF NOT EXISTS file_name TEXT,
ADD COLUMN IF NOT EXISTS file_type TEXT,
ADD COLUMN IF NOT EXISTS file_size BIGINT;

COMMENT ON COLUMN public.gpt_memory_documents.ai_analysis IS 'AI Director analysis containing: summary, ai_comments, recommendations, pros, cons';
COMMENT ON COLUMN public.gpt_memory_documents.file_name IS 'Original uploaded file name';
COMMENT ON COLUMN public.gpt_memory_documents.file_type IS 'MIME type of uploaded file';
COMMENT ON COLUMN public.gpt_memory_documents.file_size IS 'File size in bytes';