-- Add media storage columns to housekeeping_schedules
ALTER TABLE housekeeping_schedules 
ADD COLUMN media_urls text[] DEFAULT '{}',
ADD COLUMN additional_notes text;

-- Create storage bucket for housekeeping media if not exists
INSERT INTO storage.buckets (id, name, public)
VALUES ('housekeeping-media', 'housekeeping-media', true)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for housekeeping media bucket
CREATE POLICY "Users can upload housekeeping media"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'housekeeping-media' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their housekeeping media"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'housekeeping-media'
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their housekeeping media"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'housekeeping-media'
  AND auth.uid()::text = (storage.foldername(name))[1]
);