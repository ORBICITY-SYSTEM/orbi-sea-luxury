-- Allow public read access for logistics-related tables
-- This enables Public Shared Access for the /logistics route

-- Rooms table - allow public read access
DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.rooms;
CREATE POLICY "Enable read access for all users" ON public.rooms
  FOR SELECT
  USING (true);

-- Room inventory items - allow public read access  
DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.room_inventory_items;
CREATE POLICY "Enable read access for all users" ON public.room_inventory_items
  FOR SELECT
  USING (true);

-- Standard inventory items - allow public read access
DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.standard_inventory_items;
CREATE POLICY "Enable read access for all users" ON public.standard_inventory_items
  FOR SELECT
  USING (true);

-- Housekeeping schedules - allow public read access
DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.housekeeping_schedules;
CREATE POLICY "Enable read access for all users" ON public.housekeeping_schedules
  FOR SELECT
  USING (true);

-- Maintenance schedules - allow public read access
DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.maintenance_schedules;
CREATE POLICY "Enable read access for all users" ON public.maintenance_schedules
  FOR SELECT
  USING (true);

-- Logistics activity log - allow public read access
DROP POLICY IF EXISTS "Enable read access for all authenticated users" ON public.logistics_activity_log;
CREATE POLICY "Enable read access for all users" ON public.logistics_activity_log
  FOR SELECT
  USING (true);