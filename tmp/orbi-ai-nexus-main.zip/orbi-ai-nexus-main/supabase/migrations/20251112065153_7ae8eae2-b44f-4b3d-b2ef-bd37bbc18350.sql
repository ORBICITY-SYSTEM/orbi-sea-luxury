-- Make user_id nullable for logistics tables to support anonymous access

-- Housekeeping schedules
ALTER TABLE public.housekeeping_schedules 
  ALTER COLUMN user_id DROP NOT NULL;

-- Maintenance schedules  
ALTER TABLE public.maintenance_schedules 
  ALTER COLUMN user_id DROP NOT NULL;

-- Rooms
ALTER TABLE public.rooms 
  ALTER COLUMN user_id DROP NOT NULL;

-- Room inventory descriptions
ALTER TABLE public.room_inventory_descriptions 
  ALTER COLUMN user_id DROP NOT NULL;