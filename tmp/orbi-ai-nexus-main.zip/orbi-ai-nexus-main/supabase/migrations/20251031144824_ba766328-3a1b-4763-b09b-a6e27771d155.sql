-- Create table for module customizations
CREATE TABLE IF NOT EXISTS public.module_customizations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  module_key TEXT NOT NULL,
  custom_title TEXT,
  custom_description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, module_key)
);

-- Enable RLS
ALTER TABLE public.module_customizations ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own module customizations"
ON public.module_customizations
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own module customizations"
ON public.module_customizations
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own module customizations"
ON public.module_customizations
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own module customizations"
ON public.module_customizations
FOR DELETE
USING (auth.uid() = user_id);