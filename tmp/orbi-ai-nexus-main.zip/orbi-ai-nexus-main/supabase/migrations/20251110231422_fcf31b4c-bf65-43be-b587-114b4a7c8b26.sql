-- Enable realtime for logistics_activity_log table
ALTER PUBLICATION supabase_realtime ADD TABLE public.logistics_activity_log;