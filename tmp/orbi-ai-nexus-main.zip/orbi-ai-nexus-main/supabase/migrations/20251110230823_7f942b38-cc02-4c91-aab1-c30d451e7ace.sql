-- Create activity log table for Logistics module
CREATE TABLE public.logistics_activity_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  user_email TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  entity_name TEXT,
  changes JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.logistics_activity_log ENABLE ROW LEVEL SECURITY;

-- Create shared access policy - everyone can view all logs
CREATE POLICY "Anyone can view all logistics activity logs"
ON public.logistics_activity_log FOR SELECT
TO authenticated
USING (true);

-- Create shared access policy - anyone can insert logs
CREATE POLICY "Anyone can insert logistics activity logs"
ON public.logistics_activity_log FOR INSERT
TO authenticated
WITH CHECK (true);

-- Create index for faster queries
CREATE INDEX idx_logistics_activity_log_created_at ON public.logistics_activity_log(created_at DESC);
CREATE INDEX idx_logistics_activity_log_entity_type ON public.logistics_activity_log(entity_type);
CREATE INDEX idx_logistics_activity_log_user_id ON public.logistics_activity_log(user_id);

-- Add comment
COMMENT ON TABLE public.logistics_activity_log IS 'Activity log for tracking changes in Logistics module';