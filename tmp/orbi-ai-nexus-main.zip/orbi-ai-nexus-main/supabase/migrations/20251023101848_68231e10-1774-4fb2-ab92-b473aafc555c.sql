-- Create standard inventory items table
CREATE TABLE IF NOT EXISTS public.standard_inventory_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,
  item_name TEXT NOT NULL,
  standard_quantity INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create room inventory items table with issue tracking
CREATE TABLE IF NOT EXISTS public.room_inventory_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  standard_item_id UUID NOT NULL REFERENCES public.standard_inventory_items(id) ON DELETE CASCADE,
  actual_quantity INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  last_checked TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  issue_detected_at TIMESTAMP WITH TIME ZONE,
  issue_resolved_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(room_id, standard_item_id)
);

-- Enable RLS
ALTER TABLE public.standard_inventory_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_inventory_items ENABLE ROW LEVEL SECURITY;

-- RLS policies for standard_inventory_items (readable by all authenticated users)
CREATE POLICY "Anyone can view standard inventory items"
ON public.standard_inventory_items
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- RLS policies for room_inventory_items
CREATE POLICY "Users can view room inventory for their rooms"
ON public.room_inventory_items
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.rooms
    WHERE rooms.id = room_inventory_items.room_id
    AND rooms.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert room inventory for their rooms"
ON public.room_inventory_items
FOR INSERT
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.rooms
    WHERE rooms.id = room_inventory_items.room_id
    AND rooms.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update room inventory for their rooms"
ON public.room_inventory_items
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.rooms
    WHERE rooms.id = room_inventory_items.room_id
    AND rooms.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete room inventory for their rooms"
ON public.room_inventory_items
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM public.rooms
    WHERE rooms.id = room_inventory_items.room_id
    AND rooms.user_id = auth.uid()
  )
);

-- Insert standard inventory items from the PDF template
INSERT INTO public.standard_inventory_items (category, item_name, standard_quantity) VALUES
-- ავეჯი და ტექსტილი
('ავეჯი და ტექსტილი', 'კერძა საწოლი', 1),
('ავეჯი და ტექსტილი', 'სამუშაო მაგიდა', 1),
('ავეჯი და ტექსტილი', 'საწოლი მატრასით', 1),
('ავეჯი და ტექსტილი', 'დივანი გახსნილი', 1),
('ავეჯი და ტექსტილი', 'მაგიდა', 1),
('ავეჯი და ტექსტილი', 'სკამი', 2),
('ავეჯი და ტექსტილი', 'ბივენის სკამი', 4),
('ავეჯი და ტექსტილი', 'ბივენის მაგიდა', 1),
('ავეჯი და ტექსტილი', 'ფარდა', 2),
('ავეჯი და ტექსტილი', 'საწოლის დეკორატიული გადასაფარებელი', 1),
('ავეჯი და ტექსტილი', 'სამზის პირი', 1),
('ავეჯი და ტექსტილი', 'ბალიში (საწოლისთვის და დივანისთვის)', 3),
('ავეჯი და ტექსტილი', 'ბალიშის ჩიხლი (საწოლისთვის და დივანისთვის)', 3),
('ავეჯი და ტექსტილი', 'მატრასის გადასაფარებელი', 1),
('ავეჯი და ტექსტილი', 'ზეწარი(საწოლისთვის და დივანისთვის)', 2),
('ავეჯი და ტექსტილი', 'საბანი (საწოლისთვის და დივანისთვის)', 2);

-- Create trigger for updated_at
CREATE TRIGGER update_standard_inventory_items_updated_at
BEFORE UPDATE ON public.standard_inventory_items
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_room_inventory_items_updated_at
BEFORE UPDATE ON public.room_inventory_items
FOR EACH ROW
EXECUTE FUNCTION public.handle_updated_at();