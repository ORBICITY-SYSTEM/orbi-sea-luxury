-- Create saved_conversations table
CREATE TABLE IF NOT EXISTS public.saved_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  conversation_data jsonb NOT NULL,
  category text,
  tags text[],
  ai_summary text,
  action_items jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.saved_conversations ENABLE ROW LEVEL SECURITY;

-- Create policies for saved_conversations
CREATE POLICY "Users can view their own saved conversations" 
ON public.saved_conversations 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own saved conversations" 
ON public.saved_conversations 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own saved conversations" 
ON public.saved_conversations 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own saved conversations" 
ON public.saved_conversations 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_saved_conversations_updated_at
BEFORE UPDATE ON public.saved_conversations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add DELETE policy for google_tokens (GDPR compliance)
CREATE POLICY "Users can delete their own tokens" 
ON public.google_tokens 
FOR DELETE 
USING (auth.uid() = user_id);

-- Add conversation_id to ai_director_tasks if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema = 'public' 
    AND table_name = 'ai_director_tasks' 
    AND column_name = 'conversation_id'
  ) THEN
    ALTER TABLE public.ai_director_tasks 
    ADD COLUMN conversation_id uuid REFERENCES public.saved_conversations(id) ON DELETE SET NULL;
  END IF;
END $$;