-- Add AI summary columns to monthly_analysis_uploads
ALTER TABLE monthly_analysis_uploads
ADD COLUMN IF NOT EXISTS ai_summary_ka TEXT,
ADD COLUMN IF NOT EXISTS ai_summary_en TEXT,
ADD COLUMN IF NOT EXISTS ai_recommendations TEXT,
ADD COLUMN IF NOT EXISTS summary_generated_at TIMESTAMPTZ;