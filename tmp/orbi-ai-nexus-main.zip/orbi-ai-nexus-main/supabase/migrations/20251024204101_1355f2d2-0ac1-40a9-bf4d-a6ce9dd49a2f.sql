-- Create storage bucket for Excel files
INSERT INTO storage.buckets (id, name, public)
VALUES ('excel-files', 'excel-files', false);

-- Create RLS policies for excel-files bucket
CREATE POLICY "Users can upload their own Excel files"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'excel-files' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own Excel files"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'excel-files' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own Excel files"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'excel-files' 
  AND auth.uid()::text = (storage.foldername(name))[1]
);

-- Create table for Excel analysis results
CREATE TABLE excel_analysis_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  upload_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  
  -- Overall statistics
  total_revenue NUMERIC NOT NULL,
  total_nights INTEGER NOT NULL,
  total_bookings INTEGER NOT NULL,
  avg_adr NUMERIC NOT NULL,
  unique_rooms INTEGER NOT NULL,
  occupancy_rate NUMERIC,
  rev_par NUMERIC,
  
  -- Store detailed data as JSONB
  monthly_stats JSONB NOT NULL,
  room_stats JSONB NOT NULL,
  channel_stats JSONB,
  building_stats JSONB,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE excel_analysis_results ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own Excel analysis"
ON excel_analysis_results
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own Excel analysis"
ON excel_analysis_results
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own Excel analysis"
ON excel_analysis_results
FOR DELETE
USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX idx_excel_analysis_user_date ON excel_analysis_results(user_id, upload_date DESC);

-- Add trigger for updated_at
CREATE TRIGGER update_excel_analysis_updated_at
BEFORE UPDATE ON excel_analysis_results
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();