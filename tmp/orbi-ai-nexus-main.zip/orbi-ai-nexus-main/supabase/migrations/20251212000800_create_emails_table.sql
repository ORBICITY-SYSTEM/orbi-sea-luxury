-- Create emails table for AI-categorized email storage
CREATE TABLE IF NOT EXISTS public.emails (
  id TEXT PRIMARY KEY,
  thread_id TEXT NOT NULL,
  subject TEXT,
  sender TEXT,
  recipient TEXT,
  email_date TIMESTAMP WITH TIME ZONE,
  snippet TEXT,
  body TEXT,
  labels TEXT[],
  is_read BOOLEAN DEFAULT false,
  
  -- AI categorization fields
  category TEXT NOT NULL DEFAULT 'general',
  language TEXT NOT NULL DEFAULT 'English',
  sentiment TEXT NOT NULL DEFAULT 'neutral',
  priority TEXT NOT NULL DEFAULT 'normal',
  reasoning TEXT,
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT valid_category CHECK (category IN ('bookings', 'questions', 'payments', 'complaints', 'general', 'technical', 'newsletters', 'spam', 'partnerships', 'reports')),
  CONSTRAINT valid_language CHECK (language IN ('Georgian', 'English', 'Russian')),
  CONSTRAINT valid_sentiment CHECK (sentiment IN ('positive', 'neutral', 'negative')),
  CONSTRAINT valid_priority CHECK (priority IN ('urgent', 'high', 'normal', 'low'))
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_emails_category ON public.emails(category);
CREATE INDEX IF NOT EXISTS idx_emails_priority ON public.emails(priority);
CREATE INDEX IF NOT EXISTS idx_emails_is_read ON public.emails(is_read);
CREATE INDEX IF NOT EXISTS idx_emails_email_date ON public.emails(email_date DESC);
CREATE INDEX IF NOT EXISTS idx_emails_created_at ON public.emails(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_emails_thread_id ON public.emails(thread_id);

-- Enable Row Level Security
ALTER TABLE public.emails ENABLE ROW LEVEL SECURITY;

-- Create policy to allow authenticated users to read all emails
CREATE POLICY "Allow authenticated users to read emails"
  ON public.emails
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policy to allow authenticated users to insert emails
CREATE POLICY "Allow authenticated users to insert emails"
  ON public.emails
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create policy to allow authenticated users to update emails
CREATE POLICY "Allow authenticated users to update emails"
  ON public.emails
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_emails_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_emails_updated_at_trigger
  BEFORE UPDATE ON public.emails
  FOR EACH ROW
  EXECUTE FUNCTION update_emails_updated_at();

-- Add comment to table
COMMENT ON TABLE public.emails IS 'Stores AI-categorized emails from Gmail with metadata and categorization';
