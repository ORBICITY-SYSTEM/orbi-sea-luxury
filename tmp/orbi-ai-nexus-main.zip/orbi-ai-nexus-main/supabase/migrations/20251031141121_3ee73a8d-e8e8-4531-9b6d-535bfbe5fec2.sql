-- Add cost column to maintenance_schedules table
ALTER TABLE maintenance_schedules
ADD COLUMN cost numeric DEFAULT 0;