-- Enable full write access for logistics tables
-- This allows all users to INSERT, UPDATE, and DELETE data on /logistics route

-- First drop existing restrictive policies
DROP POLICY IF EXISTS "Users can insert rooms" ON public.rooms;
DROP POLICY IF EXISTS "Users can update rooms" ON public.rooms;
DROP POLICY IF EXISTS "Users can delete rooms" ON public.rooms;

DROP POLICY IF EXISTS "Users can insert inventory" ON public.room_inventory_items;
DROP POLICY IF EXISTS "Users can update inventory" ON public.room_inventory_items;
DROP POLICY IF EXISTS "Users can delete inventory" ON public.room_inventory_items;

DROP POLICY IF EXISTS "Users can insert standard items" ON public.standard_inventory_items;
DROP POLICY IF EXISTS "Users can update standard items" ON public.standard_inventory_items;
DROP POLICY IF EXISTS "Users can delete standard items" ON public.standard_inventory_items;

-- Rooms table - allow all operations
CREATE POLICY "Enable insert for all users" ON public.rooms
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Enable update for all users" ON public.rooms
  FOR UPDATE
  USING (true);

CREATE POLICY "Enable delete for all users" ON public.rooms
  FOR DELETE
  USING (true);

-- Room inventory items - allow all operations
CREATE POLICY "Enable insert for all users" ON public.room_inventory_items
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Enable update for all users" ON public.room_inventory_items
  FOR UPDATE
  USING (true);

CREATE POLICY "Enable delete for all users" ON public.room_inventory_items
  FOR DELETE
  USING (true);

-- Standard inventory items - allow all operations
CREATE POLICY "Enable insert for all users" ON public.standard_inventory_items
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Enable update for all users" ON public.standard_inventory_items
  FOR UPDATE
  USING (true);

CREATE POLICY "Enable delete for all users" ON public.standard_inventory_items
  FOR DELETE
  USING (true);