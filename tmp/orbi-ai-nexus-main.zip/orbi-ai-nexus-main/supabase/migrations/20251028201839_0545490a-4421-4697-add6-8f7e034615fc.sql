-- Create monthly_reports table with all financial fields
CREATE TABLE IF NOT EXISTS monthly_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  month DATE NOT NULL,
  studio_count INTEGER DEFAULT 56,
  days_available INTEGER DEFAULT 0,
  days_occupied INTEGER DEFAULT 0,
  occupancy NUMERIC DEFAULT 0,
  average_price NUMERIC DEFAULT 0,
  total_revenue NUMERIC DEFAULT 0,
  cleaning_technical NUMERIC DEFAULT 0,
  marketing NUMERIC DEFAULT 0,
  salaries NUMERIC DEFAULT 0,
  utilities NUMERIC DEFAULT 0,
  total_expenses NUMERIC DEFAULT 0,
  total_profit NUMERIC DEFAULT 0,
  company_profit NUMERIC DEFAULT 0,
  studio_owners_profit NUMERIC DEFAULT 0,
  notes TEXT,
  custom_fields JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  created_by UUID REFERENCES auth.users(id),
  UNIQUE(user_id, month)
);

-- Enable RLS
ALTER TABLE monthly_reports ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own monthly reports"
  ON monthly_reports FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own monthly reports"
  ON monthly_reports FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own monthly reports"
  ON monthly_reports FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own monthly reports"
  ON monthly_reports FOR DELETE
  USING (auth.uid() = user_id);

-- Create report_field_definitions table
CREATE TABLE IF NOT EXISTS report_field_definitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  field_name TEXT NOT NULL,
  field_label TEXT NOT NULL,
  field_type TEXT NOT NULL DEFAULT 'number',
  formula TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE report_field_definitions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can manage their own field definitions"
  ON report_field_definitions FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Insert sample data for multiple months
DO $$
DECLARE
  current_user_id UUID;
BEGIN
  -- Get current user ID (will be null if no user is logged in)
  current_user_id := auth.uid();
  
  IF current_user_id IS NOT NULL THEN
    -- August 2025 (Real data)
    INSERT INTO monthly_reports (user_id, month, studio_count, days_available, days_occupied, occupancy, average_price, total_revenue, cleaning_technical, marketing, salaries, utilities, total_expenses, total_profit, company_profit, studio_owners_profit)
    VALUES (current_user_id, '2025-08-01'::date, 56, 1671, 1513, 90.5, 144, 218594, 11675, 7282, 1141, 7062, 27160, 191434, 41890, 144544)
    ON CONFLICT (user_id, month) DO NOTHING;
    
    -- July 2025
    INSERT INTO monthly_reports (user_id, month, studio_count, days_available, days_occupied, occupancy, average_price, total_revenue, cleaning_technical, marketing, salaries, utilities, total_expenses, total_profit, company_profit, studio_owners_profit)
    VALUES (current_user_id, '2025-07-01'::date, 56, 1736, 1475, 85.0, 138, 203500, 10850, 6900, 1141, 6800, 25691, 177809, 38900, 138909)
    ON CONFLICT (user_id, month) DO NOTHING;
    
    -- June 2025
    INSERT INTO monthly_reports (user_id, month, studio_count, days_available, days_occupied, occupancy, average_price, total_revenue, cleaning_technical, marketing, salaries, utilities, total_expenses, total_profit, company_profit, studio_owners_profit)
    VALUES (current_user_id, '2025-06-01'::date, 56, 1680, 1344, 80.0, 135, 181440, 9600, 6500, 1141, 6400, 23641, 157799, 34500, 123299)
    ON CONFLICT (user_id, month) DO NOTHING;
    
    -- September 2025
    INSERT INTO monthly_reports (user_id, month, studio_count, days_available, days_occupied, occupancy, average_price, total_revenue, cleaning_technical, marketing, salaries, utilities, total_expenses, total_profit, company_profit, studio_owners_profit)
    VALUES (current_user_id, '2025-09-01'::date, 56, 1680, 1596, 95.0, 150, 239400, 12750, 7800, 1141, 7300, 28991, 210409, 46000, 164409)
    ON CONFLICT (user_id, month) DO NOTHING;
    
    -- October 2025
    INSERT INTO monthly_reports (user_id, month, studio_count, days_available, days_occupied, occupancy, average_price, total_revenue, cleaning_technical, marketing, salaries, utilities, total_expenses, total_profit, company_profit, studio_owners_profit)
    VALUES (current_user_id, '2025-10-01'::date, 56, 1736, 1476, 85.0, 142, 209592, 11100, 7100, 1141, 6900, 26241, 183351, 40100, 143251)
    ON CONFLICT (user_id, month) DO NOTHING;
  END IF;
END $$;