-- Add encrypted storage column for API keys
ALTER TABLE public.api_integrations
ADD COLUMN IF NOT EXISTS api_key_encrypted TEXT;

-- Add is_encrypted flag to track encryption status
ALTER TABLE public.api_integrations
ADD COLUMN IF NOT EXISTS is_encrypted BOOLEAN DEFAULT false;