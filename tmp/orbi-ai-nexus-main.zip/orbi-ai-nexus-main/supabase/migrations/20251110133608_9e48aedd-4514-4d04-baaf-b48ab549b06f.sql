-- Add manager and logistics roles to enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'manager';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'logistics';

-- Insert admin role for the main user
INSERT INTO public.user_roles (user_id, role) 
VALUES ('de8b1625-864a-4455-abfc-86b47ccbd09b', 'admin')
ON CONFLICT (user_id, role) DO NOTHING;