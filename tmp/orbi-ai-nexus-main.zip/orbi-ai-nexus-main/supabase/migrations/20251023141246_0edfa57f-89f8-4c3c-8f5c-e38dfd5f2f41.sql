-- Update finance_records table to support detailed booking data
ALTER TABLE finance_records ADD COLUMN IF NOT EXISTS room_number text;
ALTER TABLE finance_records ADD COLUMN IF NOT EXISTS nights integer DEFAULT 1;
ALTER TABLE finance_records ADD COLUMN IF NOT EXISTS checkin_date date;
ALTER TABLE finance_records ADD COLUMN IF NOT EXISTS checkout_date date;
ALTER TABLE finance_records ADD COLUMN IF NOT EXISTS building_block text;

-- Create index for better query performance
CREATE INDEX IF NOT EXISTS idx_finance_records_building_block ON finance_records(building_block);
CREATE INDEX IF NOT EXISTS idx_finance_records_date ON finance_records(date);
CREATE INDEX IF NOT EXISTS idx_finance_records_channel ON finance_records(channel);

-- Update expense_records to add more categorization
ALTER TABLE expense_records ADD COLUMN IF NOT EXISTS subcategory text;
ALTER TABLE expense_records ADD COLUMN IF NOT EXISTS vendor text;
ALTER TABLE expense_records ADD COLUMN IF NOT EXISTS payment_method text;

-- Create analytics view for quick reporting
CREATE OR REPLACE VIEW finance_analytics AS
SELECT 
  user_id,
  DATE_TRUNC('month', date) as month,
  building_block,
  channel,
  COUNT(*) as booking_count,
  SUM(revenue) as total_revenue,
  SUM(nights) as total_nights,
  AVG(revenue) as avg_revenue,
  AVG(CASE WHEN nights > 0 THEN revenue / nights ELSE revenue END) as avg_daily_rate
FROM finance_records
WHERE revenue > 0
GROUP BY user_id, DATE_TRUNC('month', date), building_block, channel;