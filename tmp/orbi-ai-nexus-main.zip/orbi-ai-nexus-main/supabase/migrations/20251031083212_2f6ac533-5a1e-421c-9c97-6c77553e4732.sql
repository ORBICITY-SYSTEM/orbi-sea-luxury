-- Create guest_reviews table for centralized review management
CREATE TABLE IF NOT EXISTS public.guest_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source TEXT NOT NULL CHECK (source IN ('google', 'facebook', 'booking', 'airbnb', 'tripadvisor', 'expedia', 'otelms', 'gmail')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  review_date TIMESTAMP WITH TIME ZONE NOT NULL,
  guest_name TEXT,
  apartment_code TEXT,
  language TEXT NOT NULL CHECK (language IN ('ka', 'en', 'ru', 'tr', 'uk', 'other')),
  stars INTEGER CHECK (stars >= 1 AND stars <= 5),
  review_title TEXT,
  review_body TEXT NOT NULL,
  sentiment TEXT NOT NULL DEFAULT 'neutral' CHECK (sentiment IN ('positive', 'neutral', 'negative')),
  topics TEXT[] DEFAULT '{}',
  reply_status TEXT NOT NULL DEFAULT 'new' CHECK (reply_status IN ('new', 'drafted', 'auto_replied', 'manual_pending', 'closed')),
  ai_generated_reply TEXT,
  review_url TEXT,
  source_message_id TEXT,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(source, source_message_id)
);

-- Enable RLS
ALTER TABLE public.guest_reviews ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own reviews"
  ON public.guest_reviews
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own reviews"
  ON public.guest_reviews
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own reviews"
  ON public.guest_reviews
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own reviews"
  ON public.guest_reviews
  FOR DELETE
  USING (auth.uid() = user_id);

-- Create index for performance
CREATE INDEX idx_guest_reviews_user_date ON public.guest_reviews(user_id, review_date DESC);
CREATE INDEX idx_guest_reviews_source ON public.guest_reviews(user_id, source);
CREATE INDEX idx_guest_reviews_sentiment ON public.guest_reviews(user_id, sentiment);
CREATE INDEX idx_guest_reviews_reply_status ON public.guest_reviews(user_id, reply_status);

-- Create trigger for updated_at
CREATE TRIGGER update_guest_reviews_updated_at
  BEFORE UPDATE ON public.guest_reviews
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create review_import_logs table for tracking imports
CREATE TABLE IF NOT EXISTS public.review_import_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source TEXT NOT NULL,
  import_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  reviews_imported INTEGER NOT NULL DEFAULT 0,
  reviews_skipped INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('success', 'partial', 'failed')),
  error_message TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for logs
ALTER TABLE public.review_import_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own import logs"
  ON public.review_import_logs
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own import logs"
  ON public.review_import_logs
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);