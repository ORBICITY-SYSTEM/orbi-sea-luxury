-- Add OTA CHANNELS AGENT as a new department in the ORBI AI NEXUS system
-- This integrates the OTA automation system as a specialized department

-- Insert OTA Channels Department
INSERT INTO departments (name, slug, description, icon, color, is_active, created_at)
VALUES (
  'OTA Channels Operations',
  'ota-channels',
  'Virtual employees managing 15+ distribution channels including Booking.com, Airbnb, Expedia, and Agoda with automated daily, weekly, and monthly tasks',
  'Users',
  '#10b981',
  true,
  NOW()
)
ON CONFLICT (slug) DO UPDATE
SET 
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  icon = EXCLUDED.icon,
  color = EXCLUDED.color,
  updated_at = NOW();

-- Get the department ID for OTA Channels
DO $$
DECLARE
  ota_dept_id UUID;
BEGIN
  SELECT id INTO ota_dept_id FROM departments WHERE slug = 'ota-channels';

  -- Insert MINI Agents for OTA Channels
  INSERT INTO agents (department_id, name, slug, description, role, status, capabilities, created_at)
  VALUES 
    (
      ota_dept_id,
      'Booking MINI Agent',
      'booking-mini-agent',
      'Specialized agent for Booking.com channel management with full knowledge base of competitor analysis, pricing strategies, and performance optimization',
      'Channel Manager - Booking.com',
      'active',
      jsonb_build_object(
        'knowledgeBase', jsonb_build_object(
          'loaded', true,
          'size', 38169,
          'hasCompetitorData', true,
          'hasPricingData', true
        ),
        'tasks', jsonb_build_array(
          'Daily booking monitoring',
          'Competitor price tracking',
          'Review management',
          'Performance analytics'
        ),
        'priority', 'HIGH',
        'propertyId', '10172179'
      ),
      NOW()
    ),
    (
      ota_dept_id,
      'Agoda MINI Agent',
      'agoda-mini-agent',
      'Specialized agent for Agoda channel management with comprehensive market analysis and pricing optimization capabilities',
      'Channel Manager - Agoda',
      'active',
      jsonb_build_object(
        'knowledgeBase', jsonb_build_object(
          'loaded', true,
          'size', 40514,
          'hasCompetitorData', true,
          'hasPricingData', true
        ),
        'tasks', jsonb_build_array(
          'Daily booking monitoring',
          'Competitor analysis',
          'Market positioning',
          'Revenue optimization'
        ),
        'priority', 'MEDIUM'
      ),
      NOW()
    ),
    (
      ota_dept_id,
      'Airbnb MINI Agent',
      'airbnb-mini-agent',
      'Specialized agent for Airbnb channel management with guest communication and listing optimization',
      'Channel Manager - Airbnb',
      'idle',
      jsonb_build_object(
        'knowledgeBase', jsonb_build_object(
          'loaded', false,
          'size', 0,
          'hasCompetitorData', false,
          'hasPricingData', false
        ),
        'tasks', jsonb_build_array(
          'Listing optimization',
          'Guest communication',
          'Review management',
          'Pricing strategy'
        ),
        'priority', 'HIGH',
        'propertyId', '1455314718960040955'
      ),
      NOW()
    ),
    (
      ota_dept_id,
      'Expedia MINI Agent',
      'expedia-mini-agent',
      'Specialized agent for Expedia channel management with multi-brand distribution strategy',
      'Channel Manager - Expedia',
      'idle',
      jsonb_build_object(
        'knowledgeBase', jsonb_build_object(
          'loaded', false,
          'size', 0,
          'hasCompetitorData', false,
          'hasPricingData', false
        ),
        'tasks', jsonb_build_array(
          'Multi-brand management',
          'Rate parity monitoring',
          'Inventory sync',
          'Performance tracking'
        ),
        'priority', 'HIGH'
      ),
      NOW()
    )
  ON CONFLICT (slug) DO UPDATE
  SET 
    name = EXCLUDED.name,
    description = EXCLUDED.description,
    role = EXCLUDED.role,
    status = EXCLUDED.status,
    capabilities = EXCLUDED.capabilities,
    updated_at = NOW();
END $$;

-- Create OTA-specific tables if they don't exist
CREATE TABLE IF NOT EXISTS ota_agent_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
  task_type TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  scheduled_at TIMESTAMPTZ NOT NULL,
  executed_at TIMESTAMPTZ,
  result JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ota_competitor_data (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
  competitor_name TEXT NOT NULL,
  price_data JSONB NOT NULL,
  collected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ota_performance_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES agents(id) ON DELETE CASCADE,
  metric_date DATE NOT NULL,
  review_score DECIMAL(3,1),
  occupancy_rate DECIMAL(5,2),
  average_daily_rate DECIMAL(10,2),
  bookings_count INTEGER DEFAULT 0,
  revenue DECIMAL(12,2),
  metrics_data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(agent_id, metric_date)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_ota_tasks_agent_status ON ota_agent_tasks(agent_id, status);
CREATE INDEX IF NOT EXISTS idx_ota_tasks_scheduled ON ota_agent_tasks(scheduled_at);
CREATE INDEX IF NOT EXISTS idx_ota_competitor_agent ON ota_competitor_data(agent_id, collected_at);
CREATE INDEX IF NOT EXISTS idx_ota_metrics_agent_date ON ota_performance_metrics(agent_id, metric_date);

-- Insert initial performance metrics for Booking agent
INSERT INTO ota_performance_metrics (agent_id, metric_date, review_score, occupancy_rate, average_daily_rate, bookings_count)
SELECT 
  a.id,
  CURRENT_DATE,
  8.4,
  32.5,
  93.70,
  247
FROM agents a
JOIN departments d ON a.department_id = d.id
WHERE d.slug = 'ota-channels' AND a.slug = 'booking-mini-agent'
ON CONFLICT (agent_id, metric_date) DO NOTHING;
