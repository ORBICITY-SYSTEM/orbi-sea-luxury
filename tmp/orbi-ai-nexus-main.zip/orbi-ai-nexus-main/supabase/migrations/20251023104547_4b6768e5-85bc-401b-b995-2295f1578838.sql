-- Create finance_records table for revenue data
CREATE TABLE IF NOT EXISTS public.finance_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  date DATE NOT NULL,
  channel TEXT NOT NULL,
  revenue DECIMAL(10,2) DEFAULT 0,
  expenses DECIMAL(10,2) DEFAULT 0,
  profit DECIMAL(10,2) DEFAULT 0,
  occupancy DECIMAL(5,2) DEFAULT 0,
  adr DECIMAL(10,2) DEFAULT 0,
  currency TEXT DEFAULT 'EUR',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create expense_records table
CREATE TABLE IF NOT EXISTS public.expense_records (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  date DATE NOT NULL,
  category TEXT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  note TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create monthly_summaries table
CREATE TABLE IF NOT EXISTS public.monthly_summaries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  total_revenue DECIMAL(10,2) DEFAULT 0,
  total_expenses DECIMAL(10,2) DEFAULT 0,
  net_profit DECIMAL(10,2) DEFAULT 0,
  occupancy DECIMAL(5,2) DEFAULT 0,
  adr DECIMAL(10,2) DEFAULT 0,
  forecast_3m DECIMAL(10,2) DEFAULT 0,
  summary_ka TEXT,
  summary_en TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, month, year)
);

-- Enable RLS
ALTER TABLE public.finance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expense_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_summaries ENABLE ROW LEVEL SECURITY;

-- RLS Policies for finance_records
CREATE POLICY "Users can view their own finance records"
  ON public.finance_records FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own finance records"
  ON public.finance_records FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own finance records"
  ON public.finance_records FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own finance records"
  ON public.finance_records FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for expense_records
CREATE POLICY "Users can view their own expense records"
  ON public.expense_records FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own expense records"
  ON public.expense_records FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own expense records"
  ON public.expense_records FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own expense records"
  ON public.expense_records FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for monthly_summaries
CREATE POLICY "Users can view their own monthly summaries"
  ON public.monthly_summaries FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own monthly summaries"
  ON public.monthly_summaries FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own monthly summaries"
  ON public.monthly_summaries FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own monthly summaries"
  ON public.monthly_summaries FOR DELETE
  USING (auth.uid() = user_id);

-- Add triggers for updated_at
CREATE TRIGGER update_finance_records_updated_at
  BEFORE UPDATE ON public.finance_records
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_expense_records_updated_at
  BEFORE UPDATE ON public.expense_records
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_monthly_summaries_updated_at
  BEFORE UPDATE ON public.monthly_summaries
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();