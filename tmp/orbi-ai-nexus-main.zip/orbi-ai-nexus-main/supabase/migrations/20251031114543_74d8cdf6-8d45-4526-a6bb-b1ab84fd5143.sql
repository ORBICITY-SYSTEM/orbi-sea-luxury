-- Add condition column to room_inventory_items for tracking item status
ALTER TABLE room_inventory_items 
ADD COLUMN IF NOT EXISTS condition text DEFAULT 'OK' CHECK (condition IN ('OK', 'Missing', 'To Replace'));

-- Add comment for documentation
COMMENT ON COLUMN room_inventory_items.condition IS 'Tracks the condition status of inventory items: OK, Missing, or To Replace';