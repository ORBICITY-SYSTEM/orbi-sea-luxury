-- Add logistics role to app_role enum if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
    CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user', 'logistics');
  ELSE
    -- Add logistics to existing enum
    ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'logistics';
  END IF;
END $$;