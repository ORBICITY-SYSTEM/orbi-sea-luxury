-- Delete existing rooms and insert correct room numbers
DELETE FROM rooms;

-- Insert rooms with correct numbering
INSERT INTO rooms (room_number, user_id) 
SELECT room_number, auth.uid()
FROM (VALUES 
  ('A 1821'), ('A 1033'), ('A 1806'), ('A 2035'), ('C 2936'), ('C 3834'), ('C 3928'),
  ('C 4638'), ('C 2107'), ('C 2529'), ('C 2609'), ('C 3611'), ('C 4011'), ('C 4704'),
  ('C 3421'), ('C 3423'), ('C 3425'), ('C 3428'), ('C 3431'), ('C 3437'), ('C 3439'),
  ('C 3441'), ('A 1301'), ('C 2921'), ('C 2923'), ('C 2558'), ('D1 3414'), ('D1 3416'),
  ('D1 3418'), ('A 4035'), ('C 2522'), ('A 1258'), ('C 2524'), ('C 2520'), ('C 2547'),
  ('C 1256'), ('C 2861'), ('C 2961'), ('C 2847'), ('C 2947'), ('A 3041'), ('A 3035'),
  ('A 1833'), ('A 2441'), ('D2 3727'), ('C 3937'), ('C 2641'), ('C 4706'), ('A 4023'),
  ('A 4025'), ('A 4027'), ('A 4029'), ('A 4024'), ('A 4022'), ('A 4026'), ('C 2637')
) AS t(room_number)
WHERE auth.uid() IS NOT NULL;