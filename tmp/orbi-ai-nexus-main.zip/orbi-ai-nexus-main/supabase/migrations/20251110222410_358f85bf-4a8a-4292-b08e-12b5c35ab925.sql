-- Create pending users table for registration requests
CREATE TABLE IF NOT EXISTS public.pending_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  requested_role app_role DEFAULT 'user',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT now(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id),
  notes TEXT
);

-- Enable RLS
ALTER TABLE public.pending_users ENABLE ROW LEVEL SECURITY;

-- Policy: Admins can view all pending registrations
CREATE POLICY "Admins can view all pending users"
ON public.pending_users
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Policy: Admins can update pending users
CREATE POLICY "Admins can update pending users"
ON public.pending_users
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Policy: Anyone can insert registration requests (for public form)
CREATE POLICY "Anyone can submit registration requests"
ON public.pending_users
FOR INSERT
TO anon
WITH CHECK (true);

-- Assign logistics role to the newly registered user
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'logistics'
FROM auth.users
WHERE email = 'tamunamaxaradze@yahoo.com'
ON CONFLICT (user_id, role) DO NOTHING;