-- Drop and recreate the view without SECURITY DEFINER
DROP VIEW IF EXISTS finance_analytics;

CREATE VIEW finance_analytics AS
SELECT 
  user_id,
  DATE_TRUNC('month', date) as month,
  building_block,
  channel,
  COUNT(*) as booking_count,
  SUM(revenue) as total_revenue,
  SUM(nights) as total_nights,
  AVG(revenue) as avg_revenue,
  AVG(CASE WHEN nights > 0 THEN revenue / nights ELSE revenue END) as avg_daily_rate
FROM finance_records
WHERE revenue > 0
GROUP BY user_id, DATE_TRUNC('month', date), building_block, channel;