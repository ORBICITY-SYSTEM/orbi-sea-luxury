-- finance_analytics is a VIEW, not a table
-- Views inherit RLS from their underlying tables
-- Since it's based on finance_records which already has RLS, 
-- we need to make sure the view uses security_invoker mode

-- First, let's check if we need to recreate the view with proper security
-- Drop and recreate the view with security_invoker
DROP VIEW IF EXISTS finance_analytics;

CREATE VIEW finance_analytics 
WITH (security_invoker = true)
AS
SELECT 
  user_id,
  date_trunc('month', date) as month,
  channel,
  building_block,
  SUM(revenue) as total_revenue,
  AVG(revenue) as avg_revenue,
  AVG(adr) as avg_daily_rate,
  COUNT(*) as booking_count,
  SUM(nights) as total_nights
FROM finance_records
GROUP BY user_id, date_trunc('month', date), channel, building_block;

-- Add comment for documentation
COMMENT ON VIEW finance_analytics IS 'Finance analytics view with security_invoker enabled - inherits RLS from finance_records table';

-- Ensure Google tokens table has proper RLS and indexes
CREATE INDEX IF NOT EXISTS idx_google_tokens_user_id ON google_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_google_tokens_expires_at ON google_tokens(expires_at);

-- Add performance indexes on other sensitive tables
CREATE INDEX IF NOT EXISTS idx_finance_records_user_id_date ON finance_records(user_id, date);
CREATE INDEX IF NOT EXISTS idx_guest_reviews_user_id_date ON guest_reviews(user_id, review_date);
CREATE INDEX IF NOT EXISTS idx_google_gmail_messages_user_id ON google_gmail_messages(user_id);

-- Add comment to remind about token encryption best practices
COMMENT ON TABLE google_tokens IS 'OAuth tokens - RLS protected. For production: implement encryption via Supabase Vault';

-- Ensure profiles table only shows user's own data
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
CREATE POLICY "Users can view their own profile"
ON profiles
FOR SELECT
USING (auth.uid() = id);