-- Create tables for AI Director memory system

-- Business knowledge and documents storage
CREATE TABLE IF NOT EXISTS public.gpt_memory_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT,
  tags TEXT[],
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- AI Director conversations
CREATE TABLE IF NOT EXISTS public.ai_director_conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  message TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  module TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Tasks assigned by AI Director
CREATE TABLE IF NOT EXISTS public.ai_director_tasks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  assigned_to TEXT,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled')),
  priority TEXT DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  due_date TIMESTAMPTZ,
  created_by_ai BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Meetings scheduled by AI Director
CREATE TABLE IF NOT EXISTS public.ai_director_meetings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  participants TEXT[],
  scheduled_at TIMESTAMPTZ NOT NULL,
  duration_minutes INTEGER DEFAULT 30,
  module TEXT,
  created_by_ai BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.gpt_memory_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_director_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_director_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_director_meetings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for gpt_memory_documents
CREATE POLICY "Users can manage their own documents"
  ON public.gpt_memory_documents
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for ai_director_conversations
CREATE POLICY "Users can manage their own conversations"
  ON public.ai_director_conversations
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for ai_director_tasks
CREATE POLICY "Users can manage their own tasks"
  ON public.ai_director_tasks
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for ai_director_meetings
CREATE POLICY "Users can manage their own meetings"
  ON public.ai_director_meetings
  FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_gpt_memory_documents_updated_at
  BEFORE UPDATE ON public.gpt_memory_documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_ai_director_tasks_updated_at
  BEFORE UPDATE ON public.ai_director_tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();