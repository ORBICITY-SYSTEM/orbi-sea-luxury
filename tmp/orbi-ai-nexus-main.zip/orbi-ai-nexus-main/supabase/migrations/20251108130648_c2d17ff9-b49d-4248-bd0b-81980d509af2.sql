-- Create table for storing analysis versions
CREATE TABLE public.monthly_analysis_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  upload_id UUID NOT NULL,
  version_number INTEGER NOT NULL,
  ai_summary_ka TEXT,
  ai_recommendations TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID NOT NULL,
  notes TEXT
);

-- Enable RLS
ALTER TABLE public.monthly_analysis_versions ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view versions for their uploads"
ON public.monthly_analysis_versions
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM monthly_analysis_uploads
    WHERE monthly_analysis_uploads.id = monthly_analysis_versions.upload_id
    AND monthly_analysis_uploads.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert versions for their uploads"
ON public.monthly_analysis_versions
FOR INSERT
WITH CHECK (
  auth.uid() = created_by
  AND EXISTS (
    SELECT 1 FROM monthly_analysis_uploads
    WHERE monthly_analysis_uploads.id = monthly_analysis_versions.upload_id
    AND monthly_analysis_uploads.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete versions for their uploads"
ON public.monthly_analysis_versions
FOR DELETE
USING (
  EXISTS (
    SELECT 1 FROM monthly_analysis_uploads
    WHERE monthly_analysis_uploads.id = monthly_analysis_versions.upload_id
    AND monthly_analysis_uploads.user_id = auth.uid()
  )
);

-- Create index for faster queries
CREATE INDEX idx_monthly_analysis_versions_upload_id ON monthly_analysis_versions(upload_id);
CREATE INDEX idx_monthly_analysis_versions_created_at ON monthly_analysis_versions(created_at DESC);