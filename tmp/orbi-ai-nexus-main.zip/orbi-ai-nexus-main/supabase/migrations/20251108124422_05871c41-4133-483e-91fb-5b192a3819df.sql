-- Create table for storing AI analysis instructions/memory
CREATE TABLE IF NOT EXISTS finance_analysis_instructions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  instruction_text TEXT NOT NULL,
  category TEXT DEFAULT 'general',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE finance_analysis_instructions ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own instructions"
  ON finance_analysis_instructions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own instructions"
  ON finance_analysis_instructions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own instructions"
  ON finance_analysis_instructions FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own instructions"
  ON finance_analysis_instructions FOR DELETE
  USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_finance_analysis_instructions_updated_at
  BEFORE UPDATE ON finance_analysis_instructions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();