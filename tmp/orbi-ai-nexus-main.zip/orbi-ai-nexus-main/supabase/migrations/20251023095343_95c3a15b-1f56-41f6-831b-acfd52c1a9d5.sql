-- Create rooms table for 57 studios
CREATE TABLE public.rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_number text NOT NULL UNIQUE,
  user_id uuid NOT NULL,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Create inventory descriptions table
CREATE TABLE public.room_inventory_descriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  description_date timestamp with time zone DEFAULT now() NOT NULL,
  items_missing text,
  items_added text,
  items_removed text,
  change_type text CHECK (change_type IN ('შეცვლა/გატეხვა', 'დაკარგვა', 'ნომრიდან ნომერში გადატანა', 'რეგულარული აღწერა')),
  transfer_from_room text,
  transfer_to_room text,
  notes text,
  created_at timestamp with time zone DEFAULT now() NOT NULL,
  updated_at timestamp with time zone DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_inventory_descriptions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for rooms
CREATE POLICY "Users can view their own rooms"
  ON public.rooms FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own rooms"
  ON public.rooms FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own rooms"
  ON public.rooms FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own rooms"
  ON public.rooms FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for room_inventory_descriptions
CREATE POLICY "Users can view their own room descriptions"
  ON public.room_inventory_descriptions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own room descriptions"
  ON public.room_inventory_descriptions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own room descriptions"
  ON public.room_inventory_descriptions FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own room descriptions"
  ON public.room_inventory_descriptions FOR DELETE
  USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_rooms_user_id ON public.rooms(user_id);
CREATE INDEX idx_rooms_room_number ON public.rooms(room_number);
CREATE INDEX idx_inventory_room_id ON public.room_inventory_descriptions(room_id);
CREATE INDEX idx_inventory_user_id ON public.room_inventory_descriptions(user_id);
CREATE INDEX idx_inventory_date ON public.room_inventory_descriptions(description_date DESC);

-- Triggers for updated_at
CREATE TRIGGER update_rooms_updated_at
  BEFORE UPDATE ON public.rooms
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();

CREATE TRIGGER update_room_inventory_descriptions_updated_at
  BEFORE UPDATE ON public.room_inventory_descriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_updated_at();