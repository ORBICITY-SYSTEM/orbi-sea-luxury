-- Add from_email column to guest_reviews table to store sender information
ALTER TABLE guest_reviews
ADD COLUMN from_email text;

-- Add index for better query performance
CREATE INDEX idx_guest_reviews_from_email ON guest_reviews(from_email);