-- Create table for monthly module file uploads
CREATE TABLE IF NOT EXISTS public.monthly_module_uploads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  upload_id UUID NOT NULL REFERENCES public.monthly_analysis_uploads(id) ON DELETE CASCADE,
  module_type TEXT NOT NULL CHECK (module_type IN ('analytics', 'reporting', 'revenue', 'expenses', 'profit', 'forecast')),
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

-- Enable RLS
ALTER TABLE public.monthly_module_uploads ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own module uploads"
  ON public.monthly_module_uploads
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own module uploads"
  ON public.monthly_module_uploads
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own module uploads"
  ON public.monthly_module_uploads
  FOR DELETE
  USING (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX idx_monthly_module_uploads_user_id ON public.monthly_module_uploads(user_id);
CREATE INDEX idx_monthly_module_uploads_upload_id ON public.monthly_module_uploads(upload_id);
CREATE INDEX idx_monthly_module_uploads_module_type ON public.monthly_module_uploads(module_type);