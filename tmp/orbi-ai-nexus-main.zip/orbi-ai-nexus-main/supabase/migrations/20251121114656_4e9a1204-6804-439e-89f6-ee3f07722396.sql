-- OTA Command Center Database Schema

-- Extend google_tokens to include user profile data
-- (Note: google_tokens already exists, we'll use it as our user store)

-- Bookings table for OTA reservations
CREATE TABLE IF NOT EXISTS public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel TEXT NOT NULL CHECK (channel IN ('Booking.com', 'Airbnb', 'Expedia', 'Agoda', 'Ostrovok', 'Bronevik', 'Tvil', 'Sutochno', 'HRS', 'Other')),
  thread_id TEXT NOT NULL,
  message_id TEXT,
  subject TEXT,
  checkin TIMESTAMPTZ,
  checkout TIMESTAMPTZ,
  nights INTEGER,
  amount NUMERIC,
  currency TEXT DEFAULT 'EUR',
  cancelled BOOLEAN DEFAULT false,
  guest_name TEXT,
  room_number TEXT,
  confirmation_code TEXT,
  email_received_at TIMESTAMPTZ NOT NULL,
  raw_payload JSONB,
  parsed_payload JSONB,
  parsed_by_gpt BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Unique constraint on thread_id per user to prevent duplicates
CREATE UNIQUE INDEX IF NOT EXISTS idx_bookings_user_thread ON public.bookings(user_id, thread_id);

-- Sync logs for tracking Gmail ingestion
CREATE TABLE IF NOT EXISTS public.sync_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ DEFAULT now(),
  finished_at TIMESTAMPTZ,
  new_bookings INTEGER DEFAULT 0,
  updated_bookings INTEGER DEFAULT 0,
  errors JSONB,
  status TEXT DEFAULT 'running' CHECK (status IN ('running', 'completed', 'failed'))
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_bookings_user_created ON public.bookings(user_id, email_received_at DESC);
CREATE INDEX IF NOT EXISTS idx_bookings_channel ON public.bookings(channel);
CREATE INDEX IF NOT EXISTS idx_bookings_checkin ON public.bookings(checkin);
CREATE INDEX IF NOT EXISTS idx_bookings_cancelled ON public.bookings(cancelled);
CREATE INDEX IF NOT EXISTS idx_sync_logs_user ON public.sync_logs(user_id, started_at DESC);

-- Enable RLS
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sync_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for bookings
CREATE POLICY "Users can view their own bookings"
  ON public.bookings FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own bookings"
  ON public.bookings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bookings"
  ON public.bookings FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bookings"
  ON public.bookings FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for sync_logs
CREATE POLICY "Users can view their own sync logs"
  ON public.sync_logs FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own sync logs"
  ON public.sync_logs FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own sync logs"
  ON public.sync_logs FOR UPDATE
  USING (auth.uid() = user_id);

-- Trigger for updated_at
CREATE OR REPLACE FUNCTION update_bookings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER bookings_updated_at
  BEFORE UPDATE ON public.bookings
  FOR EACH ROW
  EXECUTE FUNCTION update_bookings_updated_at();