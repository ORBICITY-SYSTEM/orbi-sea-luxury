# ORBI AI Agents API Documentation

## Overview

The ORBI AI Agents API allows external applications to interact with AI agents programmatically. All requests require authentication via API keys.

**Base URL:** `https://your-domain.com/api/v1`

## Authentication

Include your API key in the request header:

```
X-API-Key: orbi_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Or use Bearer token format:

```
Authorization: Bearer orbi_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Rate Limiting

Default rate limit: **60 requests per minute** per API key.

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Maximum requests per minute
- `X-RateLimit-Remaining`: Remaining requests in current window
- `X-RateLimit-Reset`: Timestamp when the rate limit resets

## Response Format

All API responses follow this structure:

```json
{
  "success": true,
  "data": { ... },
  "error": null,
  "timestamp": "2024-11-29T05:00:00.000Z"
}
```

### Error Response

```json
{
  "success": false,
  "data": null,
  "error": "Error message here",
  "timestamp": "2024-11-29T05:00:00.000Z"
}
```

## Endpoints

### 1. List Departments

Get all available departments.

**Endpoint:** `GET /departments`

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Marketing Operations",
      "slug": "marketing",
      "description": "AI-powered marketing automation and campaign management",
      "icon": "megaphone",
      "color": "blue",
      "created_at": "2024-11-29T05:00:00.000Z",
      "updated_at": "2024-11-29T05:00:00.000Z"
    }
  ]
}
```

### 2. List Agents in Department

Get all agents in a specific department.

**Endpoint:** `GET /departments/:slug/agents`

**Parameters:**
- `slug` (path): Department slug (e.g., "marketing", "finance")

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Corporate Outreach Specialist",
      "slug": "corporate-outreach",
      "type": "marketing",
      "department_id": 1,
      "description": "Manages B2B outreach campaigns...",
      "capabilities": "Email generation, WhatsApp messaging...",
      "status": "active",
      "created_at": "2024-11-29T05:00:00.000Z"
    }
  ]
}
```

### 3. Get Agent Details

Get detailed information about a specific agent.

**Endpoint:** `GET /agents/:slug`

**Parameters:**
- `slug` (path): Agent slug (e.g., "corporate-outreach")

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Corporate Outreach Specialist",
    "slug": "corporate-outreach",
    "type": "marketing",
    "description": "Manages B2B outreach campaigns...",
    "capabilities": "Email generation, WhatsApp messaging...",
    "status": "active",
    "departments": {
      "name": "Marketing Operations",
      "slug": "marketing"
    }
  }
}
```

### 4. Chat with Agent

Send a message to an agent and receive AI-generated response.

**Endpoint:** `POST /agents/:slug/chat`

**Parameters:**
- `slug` (path): Agent slug

**Request Body:**
```json
{
  "message": "Generate a corporate outreach email for a tech company"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "message": "Here's a personalized corporate outreach email...",
    "agent": {
      "name": "Corporate Outreach Specialist",
      "slug": "corporate-outreach"
    }
  }
}
```

### 5. Get Conversation History

Retrieve past conversations with an agent.

**Endpoint:** `GET /agents/:slug/conversations`

**Parameters:**
- `slug` (path): Agent slug

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "agent_id": 1,
      "user_id": "uuid",
      "role": "user",
      "content": "Generate an email",
      "created_at": "2024-11-29T05:00:00.000Z"
    },
    {
      "id": 2,
      "agent_id": 1,
      "user_id": "uuid",
      "role": "assistant",
      "content": "Here's your email...",
      "created_at": "2024-11-29T05:00:01.000Z"
    }
  ]
}
```

### 6. Get Agent Tasks

Retrieve tasks assigned to an agent.

**Endpoint:** `GET /agents/:slug/tasks`

**Parameters:**
- `slug` (path): Agent slug

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "agent_id": 1,
      "title": "Create Q1 marketing campaign",
      "description": "Design and execute marketing campaign",
      "status": "pending",
      "priority": "high",
      "due_date": "2024-12-31T00:00:00.000Z",
      "created_at": "2024-11-29T05:00:00.000Z"
    }
  ]
}
```

### 7. Create Agent Task

Create a new task for an agent.

**Endpoint:** `POST /agents/:slug/tasks`

**Parameters:**
- `slug` (path): Agent slug

**Request Body:**
```json
{
  "title": "Create marketing report",
  "description": "Analyze Q4 marketing performance",
  "priority": "high",
  "due_date": "2024-12-31T00:00:00.000Z"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "agent_id": 1,
    "title": "Create marketing report",
    "status": "pending",
    "created_at": "2024-11-29T05:00:00.000Z"
  }
}
```

### 8. Upload File to Agent

Upload a file for agent processing.

**Endpoint:** `POST /agents/:slug/files`

**Parameters:**
- `slug` (path): Agent slug

**Request:** `multipart/form-data`
- `file`: File to upload

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "agent_id": 1,
    "filename": "document.pdf",
    "file_path": "user-id/agent-id/timestamp_document.pdf",
    "file_size": 102400,
    "mime_type": "application/pdf",
    "created_at": "2024-11-29T05:00:00.000Z"
  }
}
```

## Webhooks

Configure webhooks to receive real-time notifications about events.

### Supported Events

- `agent.message.sent` - When a message is sent to an agent
- `agent.task.created` - When a task is created
- `agent.task.completed` - When a task is completed
- `agent.file.uploaded` - When a file is uploaded

### Webhook Payload

```json
{
  "event": "agent.message.sent",
  "data": {
    "agent_slug": "corporate-outreach",
    "message": "Generate email",
    "timestamp": "2024-11-29T05:00:00.000Z"
  }
}
```

### Webhook Security

Webhooks include a signature header for verification:

```
X-Orbi-Signature: sha256_hash
X-Orbi-Event: agent.message.sent
```

Verify the signature using HMAC-SHA256 with your webhook secret.

## Code Examples

### JavaScript/Node.js

```javascript
const ORBI_API_KEY = 'orbi_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
const BASE_URL = 'https://your-domain.com/api/v1';

// Chat with agent
async function chatWithAgent(agentSlug, message) {
  const response = await fetch(`${BASE_URL}/agents/${agentSlug}/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': ORBI_API_KEY,
    },
    body: JSON.stringify({ message }),
  });
  
  const data = await response.json();
  return data;
}

// Usage
const result = await chatWithAgent('corporate-outreach', 'Generate an email');
console.log(result.data.message);
```

### Python

```python
import requests

ORBI_API_KEY = 'orbi_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
BASE_URL = 'https://your-domain.com/api/v1'

# Chat with agent
def chat_with_agent(agent_slug, message):
    response = requests.post(
        f'{BASE_URL}/agents/{agent_slug}/chat',
        headers={'X-API-Key': ORBI_API_KEY},
        json={'message': message}
    )
    return response.json()

# Usage
result = chat_with_agent('corporate-outreach', 'Generate an email')
print(result['data']['message'])
```

### cURL

```bash
curl -X POST https://your-domain.com/api/v1/agents/corporate-outreach/chat \
  -H "X-API-Key: orbi_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{"message": "Generate an email"}'
```

## Error Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized (Invalid API key) |
| 404 | Not Found |
| 429 | Rate Limit Exceeded |
| 500 | Internal Server Error |

## Support

For API support, contact: support@orbicitybatumi.com
