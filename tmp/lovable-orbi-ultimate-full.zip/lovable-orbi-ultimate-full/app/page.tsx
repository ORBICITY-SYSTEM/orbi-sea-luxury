import dynamic from 'next/dynamic'
import BookingWidget from '../src/components/BookingWidget'
export default function Page(){ return (<div><h1 className="text-3xl font-bold">Orbi City · LOVABLE</h1><p className="mt-2">Unified demo site</p><div className="mt-6"><BookingWidget /></div></div>) }
