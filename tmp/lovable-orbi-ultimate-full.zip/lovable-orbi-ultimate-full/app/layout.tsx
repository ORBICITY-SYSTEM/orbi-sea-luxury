import './globals.css'
import { ReactNode } from 'react'
export const metadata = { title: 'LOVABLE Orbi City', description: 'Golden repo' }
export default function RootLayout({ children }: { children: ReactNode }) {
  return (<html lang="en"><body><header style={{padding:16,background:'#fff',borderBottom:'1px solid #eee'}}><div style={{maxWidth:1100,margin:'0 auto'}}>LOVABLE · Orbi City</div></header><main style={{maxWidth:1100,margin:'24px auto'}}>{children}</main><footer style={{maxWidth:1100,margin:'24px auto',padding:12,color:'#777'}}>© LOVABLE</footer></body></html>)
}
