import { v4 as uuidv4 } from 'uuid'
const store=new Map()
export async function createLocalBooking(payload:any){ const id=uuidv4(); store.set(id,{id,payload,status:'pending',createdAt:new Date().toISOString()}); return id }
export async function updateLocalBooking(id:string,upd:any){ const r=store.get(id); if(!r) return null; Object.assign(r,upd); store.set(id,r); return r }
